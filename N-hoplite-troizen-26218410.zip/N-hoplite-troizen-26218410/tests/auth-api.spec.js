import { test as base, expect } from "@playwright/test";
import { createHash, randomUUID } from "node:crypto";
import { execFileSync } from "node:child_process";
import { statSync } from "node:fs";
import { resolve } from "node:path";
import { DatabaseSync } from "node:sqlite";
import { dashboardModels } from "../src/lib/dashboard-data.ts";
import { cookie } from "../src/lib/server/auth.ts";
import { body, sameOrigin } from "../src/lib/server/http.ts";

const test = base.extend({
  clients: async ({ playwright, baseURL }, use) => {
    const opened = [];
    await use(async (storageState) => {
      const client = await playwright.request.newContext({
        baseURL,
        extraHTTPHeaders: { Origin: new URL(baseURL).origin },
        storageState,
      });
      opened.push(client);
      return client;
    });
    await Promise.all(opened.map((client) => client.dispose()));
  },
});

test.describe.configure({ mode: "serial" });
test.use({ trace: "off" });
test.setTimeout(60_000);

const databasePath = () =>
  resolve(process.env.AIVON_DB_PATH || ".data/aivon.sqlite");
const hash = (value) => createHash("sha256").update(value).digest("hex");
function credentials() {
  return {
    name: "API Security Test",
    email: `auth-${randomUUID()}@workspace.test`,
    password: `Test-${randomUUID()}-only`,
  };
}
async function signup(client, data = credentials()) {
  const response = await client.post("/api/auth/register", { data });
  expect(response.status()).toBe(201);
  return { data, response, state: (await response.json()).state };
}
async function stateOf(client) {
  const response = await client.get("/api/workspace");
  expect(response.status()).toBe(200);
  expect(response.headers()["cache-control"]).toContain("no-store");
  return (await response.json()).state;
}
function withDatabase(operation) {
  const db = new DatabaseSync(databasePath(), { readOnly: true });
  try {
    return operation(db);
  } finally {
    db.close();
  }
}

test("guests have empty workspaces and cannot mutate account data", async ({
  clients,
}) => {
  const guest = await clients();
  const state = await stateOf(guest);
  expect(state.authenticated).toBe(false);
  expect(state.profile.email).toBe("");
  for (const field of ["keys", "notifications", "favorites", "usage"]) {
    expect(state[field]).toEqual([]);
  }
  for (const data of [
    { action: "createKey", name: "Forbidden", limit: 0, expiryDays: 0 },
    { action: "revokeKey", id: randomUUID() },
    { action: "profile", profile: state.profile },
    { action: "favorite", id: dashboardModels[0].id },
    { action: "markRead" },
  ]) {
    expect((await guest.post("/api/workspace", { data })).status()).toBe(401);
  }
});

test("signup, persisted opaque sessions, duplicate registration, login and logout", async ({
  clients,
}) => {
  const owner = await clients();
  const { data, response, state } = await signup(owner);
  expect(state.authenticated).toBe(true);
  expect(state.profile.email).toBe(data.email);
  expect(state.keys).toEqual([]);
  expect(state.usage).toEqual([]);
  const setCookie = response.headers()["set-cookie"];
  expect(setCookie.includes("HttpOnly")).toBe(true);
  expect(setCookie.includes("SameSite=Lax")).toBe(true);
  expect(setCookie.includes("Path=/")).toBe(true);
  const storage = await owner.storageState();
  const session = storage.cookies.find(
    (entry) => entry.name === "aivon_session",
  );
  expect(/^[\w-]{43}$/.test(session.value)).toBe(true);
  expect(session.httpOnly).toBe(true);

  withDatabase((db) => {
    const account = db
      .prepare("SELECT id, password_hash FROM accounts WHERE email = ?")
      .get(data.email);
    expect(account.password_hash.startsWith("scrypt$131072$8$1$")).toBe(true);
    expect(account.password_hash.includes(data.password)).toBe(false);
    const saved = db
      .prepare("SELECT token_hash FROM sessions WHERE account_id = ?")
      .get(account.id);
    expect(saved.token_hash === hash(session.value)).toBe(true);
    expect(saved.token_hash === session.value).toBe(false);
  });
  expect(statSync(databasePath()).mode & 0o777).toBe(0o600);

  const restored = await clients(storage);
  expect((await stateOf(restored)).profile.email).toBe(data.email);
  const anonymous = await clients();
  const duplicate = await anonymous.post("/api/auth/register", {
    data: { ...data, email: data.email.toUpperCase() },
  });
  expect(duplicate.status()).toBe(409);
  expect((await stateOf(anonymous)).authenticated).toBe(false);
  const wrong = await anonymous.post("/api/auth/login", {
    data: { email: data.email, password: "Incorrect-password-only" },
  });
  expect(wrong.status()).toBe(401);
  const unknown = await anonymous.post("/api/auth/login", {
    data: { email: credentials().email, password: "Incorrect-password-only" },
  });
  expect(unknown.status()).toBe(401);
  expect((await wrong.json()).error).toBe((await unknown.json()).error);
  expect((await anonymous.post("/api/auth/login", { data })).status()).toBe(
    200,
  );
  const loggedIn = await anonymous.storageState();
  const freshSession = loggedIn.cookies.find(
    (entry) => entry.name === "aivon_session",
  );
  expect(freshSession.value === session.value).toBe(false);
  const logoutResponse = await anonymous.post("/api/auth/logout");
  expect(logoutResponse.status()).toBe(200);
  expect(logoutResponse.headers()["set-cookie"]).toContain("Max-Age=0");
  expect((await stateOf(anonymous)).authenticated).toBe(false);
  const replay = await clients(loggedIn);
  expect((await stateOf(replay)).authenticated).toBe(false);
  expect((await stateOf(owner)).authenticated).toBe(true);
});

test("expired sessions cannot read or mutate an account", async ({
  clients,
}) => {
  const owner = await clients();
  await signup(owner);
  const storage = await owner.storageState();
  const session = storage.cookies.find(
    (entry) => entry.name === "aivon_session",
  );
  const db = new DatabaseSync(databasePath());
  try {
    db.prepare("UPDATE sessions SET expires_at = ? WHERE token_hash = ?").run(
      Date.now() - 1000,
      hash(session.value),
    );
  } finally {
    db.close();
  }
  expect((await stateOf(owner)).authenticated).toBe(false);
  expect(
    (
      await owner.post("/api/workspace", { data: { action: "markRead" } })
    ).status(),
  ).toBe(401);
});

test("keys and notifications are owner-scoped, hashed and persisted without token replay", async ({
  clients,
}) => {
  const owner = await clients();
  const other = await clients();
  const { data } = await signup(owner);
  await signup(other);
  const response = await owner.post("/api/workspace", {
    data: {
      action: "createKey",
      name: "Private integration",
      limit: 1_000_000,
      expiryDays: 30,
    },
  });
  expect(response.status()).toBe(200);
  const { state, token } = await response.json();
  expect(/^aivon_[A-Za-z0-9_-]{43}$/.test(token)).toBe(true);
  const key = state.keys[0];
  expect(key.suffix === token.slice(-4)).toBe(true);
  expect(key.limit).toBe(1_000_000);
  expect(Date.parse(key.expiresAt) - Date.parse(key.createdAt)).toBe(
    30 * 86400000,
  );
  expect(JSON.stringify(state).includes(token)).toBe(false);
  expect((await stateOf(other)).keys).toEqual([]);
  expect(
    (
      await other.post("/api/workspace", {
        data: { action: "revokeKey", id: key.id },
      })
    ).status(),
  ).toBe(404);
  expect(
    (
      await other.post("/api/workspace", {
        data: { action: "markRead", id: state.notifications[0].id },
      })
    ).status(),
  ).toBe(404);
  expect((await stateOf(owner)).keys[0].status).toBe("active");
  withDatabase((db) => {
    const saved = db
      .prepare("SELECT token_hash FROM api_keys WHERE id = ?")
      .get(key.id);
    expect(saved.token_hash === hash(token)).toBe(true);
    expect(saved.token_hash === token).toBe(false);
  });
  const diskSnapshot = JSON.parse(
    execFileSync(
      process.execPath,
      [
        "--input-type=module",
        "-e",
        `import { DatabaseSync } from 'node:sqlite';
     const db = new DatabaseSync(process.argv[1], { readOnly: true });
     const row = db.prepare('SELECT name, status FROM api_keys WHERE id = ?').get(process.argv[2]);
     process.stdout.write(JSON.stringify(row)); db.close();`,
        databasePath(),
        key.id,
      ],
      { encoding: "utf8" },
    ),
  );
  expect(diskSnapshot).toEqual({
    name: "Private integration",
    status: "active",
  });
  expect(
    (
      await owner.post("/api/workspace", { data: { action: "markRead" } })
    ).status(),
  ).toBe(200);
  expect((await stateOf(owner)).notifications.every((note) => note.read)).toBe(
    true,
  );
  const revoked = await owner.post("/api/workspace", {
    data: { action: "revokeKey", id: key.id },
  });
  expect(revoked.status()).toBe(200);
  expect((await revoked.json()).state.keys[0].status).toBe("revoked");
  await owner.post("/api/auth/logout");
  expect((await owner.post("/api/auth/login", { data })).status()).toBe(200);
  const persisted = await stateOf(owner);
  expect(persisted.keys[0].id).toBe(key.id);
  expect(persisted.keys[0].status).toBe("revoked");
  expect(JSON.stringify(persisted).includes(token)).toBe(false);
  for (const field of ["usage"]) expect(persisted[field]).toEqual([]);
});

test("profiles and favorites persist with validated fields and immutable identity", async ({
  clients,
}) => {
  const owner = await clients();
  const { state, data } = await signup(owner);
  const profile = {
    ...state.profile,
    name: "Renamed Test",
    workspace: "Test workspace",
    timezone: "Europe/London",
    role: "Founder",
    usageAlerts: false,
    productUpdates: true,
  };
  expect(
    (
      await owner.post("/api/workspace", {
        data: { action: "profile", profile },
      })
    ).status(),
  ).toBe(200);
  for (const bad of [
    { ...profile, email: credentials().email },
    { ...profile, name: "x".repeat(65) },
    { ...profile, workspace: "x".repeat(65) },
    { ...profile, timezone: "Not/A_Zone" },
    { ...profile, role: "Administrator" },
    { ...profile, usageAlerts: "true" },
  ]) {
    expect(
      (
        await owner.post("/api/workspace", {
          data: { action: "profile", profile: bad },
        })
      ).status(),
    ).toBe(400);
  }
  expect((await stateOf(owner)).profile).toEqual(profile);
  const modelId = dashboardModels[0].id;
  expect(
    (
      await owner.post("/api/workspace", {
        data: { action: "favorite", id: modelId },
      })
    ).status(),
  ).toBe(200);
  expect(
    (
      await owner.post("/api/workspace", {
        data: { action: "favorite", id: "unknown/model" },
      })
    ).status(),
  ).toBe(400);
  await owner.post("/api/auth/logout");
  await owner.post("/api/auth/login", { data });
  const restored = await stateOf(owner);
  expect(restored.profile).toEqual(profile);
  expect(restored.favorites).toEqual([modelId]);
  await owner.post("/api/workspace", {
    data: { action: "favorite", id: modelId },
  });
  expect((await stateOf(owner)).favorites).toEqual([]);
  for (const bad of [
    { action: "createKey", name: "x".repeat(49), limit: 0, expiryDays: 0 },
    { action: "createKey", name: "Valid", limit: -1, expiryDays: 0 },
    { action: "createKey", name: "Valid", limit: 1.5, expiryDays: 0 },
    { action: "createKey", name: "Valid", limit: 0, expiryDays: 366 },
    { action: "purchase", plan: "anything" },
  ]) {
    expect((await owner.post("/api/workspace", { data: bad })).status()).toBe(
      400,
    );
  }
});

test("cross-origin, absent-origin, invalid and oversized requests cannot change state", async ({
  clients,
  playwright,
  baseURL,
}) => {
  const owner = await clients();
  await signup(owner);
  for (const path of [
    "/api/auth/register",
    "/api/auth/login",
    "/api/auth/logout",
    "/api/workspace",
  ]) {
    const response = await owner.post(path, {
      headers: {
        Origin: "https://attacker.test",
        "X-Forwarded-Host": "attacker.test",
      },
      data: { action: "markRead" },
    });
    expect(response.status()).toBe(403);
  }
  const noOrigin = await playwright.request.newContext({ baseURL });
  try {
    expect(
      (
        await noOrigin.post("/api/auth/register", { data: credentials() })
      ).status(),
    ).toBe(403);
  } finally {
    await noOrigin.dispose();
  }
  expect(
    (
      await owner.post("/api/workspace", {
        data: "{broken",
        headers: { "Content-Type": "application/json" },
      })
    ).status(),
  ).toBe(400);
  expect(
    (
      await owner.post("/api/workspace", {
        data: { action: "markRead", padding: "x".repeat(17 * 1024) },
      })
    ).status(),
  ).toBe(413);
  expect(
    (await owner.post("/api/workspace", { data: "plain text" })).status(),
  ).toBe(415);
  expect((await stateOf(owner)).authenticated).toBe(true);
  const anonymous = await clients();
  expect(
    (
      await anonymous.post("/api/auth/register", {
        data: { ...credentials(), password: "short" },
      })
    ).status(),
  ).toBe(400);
});

test("login abuse limits survive new clients and are recorded durably", async ({
  clients,
}) => {
  const client = await clients();
  const data = credentials();
  for (let attempt = 0; attempt < 10; attempt++) {
    expect((await client.post("/api/auth/login", { data })).status()).toBe(401);
  }
  const fresh = await clients();
  const blocked = await fresh.post("/api/auth/login", { data });
  expect(blocked.status()).toBe(429);
  expect(Number(blocked.headers()["retry-after"])).toBeGreaterThan(0);
  withDatabase((db) => {
    const row = db
      .prepare("SELECT attempts, resets_at FROM rate_limits WHERE bucket = ?")
      .get(`auth:login:${hash(data.email)}`);
    expect(row.attempts).toBe(10);
    expect(row.resets_at).toBeGreaterThan(Date.now());
  });
  const signupData = credentials();
  await signup(client, signupData);
  for (let attempt = 0; attempt < 4; attempt++) {
    expect(
      (await fresh.post("/api/auth/register", { data: signupData })).status(),
    ).toBe(409);
  }
  expect(
    (await fresh.post("/api/auth/register", { data: signupData })).status(),
  ).toBe(429);
});

test("same-origin validation supports HTTPS preview Host, never forwarded-host substitution", async () => {
  const preview = new Request("http://localhost:3000/api/workspace", {
    headers: {
      host: "workspace.preview.usehoplite.com",
      origin: "https://workspace.preview.usehoplite.com",
      "x-forwarded-proto": "https",
    },
  });
  expect(() => sameOrigin(preview)).not.toThrow();
  expect(cookie(preview, "non-secret-test-value").includes("; Secure")).toBe(
    true,
  );
  const spoofed = new Request("http://localhost:3000/api/workspace", {
    headers: {
      host: "workspace.preview.usehoplite.com",
      origin: "https://attacker.test",
      "x-forwarded-proto": "https",
      "x-forwarded-host": "attacker.test",
    },
  });
  expect(() => sameOrigin(spoofed)).toThrow();
  const streamed = new Request("http://localhost:3000/api/workspace", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: new ReadableStream({
      start(controller) {
        controller.enqueue(new Uint8Array(17 * 1024));
        controller.close();
      },
    }),
    duplex: "half",
  });
  await expect(body(streamed)).rejects.toMatchObject({ status: 413 });
});
