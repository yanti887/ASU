import { test, expect } from "@playwright/test";

async function visitDashboard(page, path = "/dashboard") {
  await page.goto(path);
  await expect(page.locator("#dashboard-main")).toBeVisible({
    timeout: 15_000,
  });
  await expect(page.getByText("Preparing your workspace…")).toHaveCount(0);
}

test("landing Explore models opens the dashboard directly", async ({
  page,
}) => {
  await page.goto("/");
  const link = page.getByRole("link", { name: "Explore models" });
  await expect(link).toHaveAttribute("href", "/dashboard");
  await link.click();
  await expect(page).toHaveURL(/\/dashboard$/);
  await expect(
    page.getByRole("heading", { name: "Your workspace starts here." }),
  ).toBeVisible();
});

test("guest dashboard has no generated account, usage, balance, or checkout", async ({
  page,
}) => {
  await visitDashboard(page);
  await expect(page.getByTestId("total-requests")).toHaveText("0");
  await expect(
    page.getByRole("heading", { name: "No usage yet" }),
  ).toBeVisible();
  await expect(
    page.getByRole("link", { name: "Buat akun" }).first(),
  ).toBeVisible();
  await expect(
    page.getByText("Guest workspace", { exact: true }),
  ).toBeVisible();

  await visitDashboard(page, "/dashboard/billing");
  await expect(
    page.getByRole("heading", { name: "Billing, when it is ready." }),
  ).toBeVisible();
  await expect(page.getByText("Tidak ada checkout yang aktif")).toBeVisible();
  await expect(
    page.getByRole("button", { name: /select|activate|purchase/i }),
  ).toHaveCount(0);
});

test("catalog shows separate input/output per 1M values and keeps multiplier independent", async ({
  page,
}) => {
  await visitDashboard(page, "/dashboard/models");
  const first = page.locator(".model-card").first();
  await expect(first.getByText("Input", { exact: true })).toBeVisible();
  await expect(first.getByText("Output", { exact: true })).toBeVisible();
  await expect(first.getByText("USD / 1M tokens").first()).toBeVisible();
  await expect(
    first.getByText("Credit multiplier", { exact: true }),
  ).toBeVisible();
  await expect(first.getByText("Belum ditetapkan").first()).toBeVisible();
  await first.getByRole("button", { name: "Details" }).click();
  const dialog = page.getByRole("dialog");
  await expect(dialog.getByText("Input · USD / 1M tokens")).toBeVisible();
  await expect(dialog.getByText("Output · USD / 1M tokens")).toBeVisible();
  await expect(dialog.getByText("Credit multiplier")).toBeVisible();
  await dialog.getByLabel("Input tokens").fill("1000000");
  await dialog.getByLabel("Output tokens").fill("500000");
  await expect(dialog.getByText("Estimasi kredit")).toBeVisible();
  await expect(dialog.getByText("Belum ditetapkan").last()).toBeVisible();
});

test("guests are invited to authenticate before API-key management", async ({
  page,
}) => {
  await visitDashboard(page, "/dashboard/api-keys");
  await expect(
    page.getByRole("heading", { name: "Sign in to manage API keys" }),
  ).toBeVisible();
  await expect(page.getByRole("link", { name: "Buat akun" })).toHaveAttribute(
    "href",
    "/register?next=%2Fdashboard%2Fapi-keys",
  );
  await expect(page.getByRole("button", { name: "Create key" })).toHaveCount(0);
});

test("usage remains empty until a gateway records requests", async ({
  page,
}) => {
  await visitDashboard(page, "/dashboard/usage");
  await expect(
    page.getByRole("heading", { name: "No requests in this view" }),
  ).toBeVisible();
  await expect(
    page.getByRole("heading", { name: "No request log yet" }),
  ).toBeVisible();
  await expect(page.getByRole("button", { name: "Export CSV" })).toBeDisabled();
  await expect(
    page.getByText(
      "Recorded model requests will appear here after the gateway is connected.",
    ),
  ).toBeVisible();
});

test("global search, theme, and responsive routes remain usable", async ({
  page,
}) => {
  await visitDashboard(page);
  const trigger = page.locator(".db-search-trigger");
  await trigger.focus();
  await page.keyboard.press("Control+K");
  const dialog = page.getByRole("dialog", { name: "Find your next step" });
  await expect(dialog.getByLabel("Search dashboard")).toBeFocused();
  await dialog.getByLabel("Search dashboard").fill("pricing");
  await expect(
    dialog.getByRole("link", { name: /Models & pricing/ }),
  ).toBeVisible();
  await page.keyboard.press("Escape");
  await expect(dialog).toHaveCount(0);
  await expect(trigger).toBeFocused();

  for (const width of [320, 390, 768, 1024, 1440]) {
    await page.setViewportSize({ width, height: 900 });
    for (const route of [
      "/dashboard",
      "/dashboard/usage",
      "/dashboard/api-keys",
      "/dashboard/models",
      "/dashboard/billing",
      "/dashboard/docs",
      "/dashboard/profile",
    ]) {
      await visitDashboard(page, route);
      expect(
        await page.evaluate(
          () => document.documentElement.scrollWidth <= window.innerWidth,
        ),
      ).toBe(true);
    }
  }
});
