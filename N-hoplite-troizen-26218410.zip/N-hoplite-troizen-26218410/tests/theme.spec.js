import { test, expect } from "@playwright/test";

async function ready(page) {
  await page.goto("/");
  await expect(page.locator(".entry")).toHaveCount(0);
  await expect(page.getByRole("switch", { name: "Mode hitam" })).toBeEnabled();
}

test("theme switch works with keyboard and persists both choices", async ({
  page,
}) => {
  const errors = [];
  page.on("pageerror", (error) => errors.push(error.message));
  await page.emulateMedia({ colorScheme: "light" });
  await ready(page);
  const toggle = page.getByRole("switch", { name: "Mode hitam" });
  await expect(toggle).not.toBeChecked();
  await toggle.focus();
  await page.keyboard.press("Space");
  await expect(toggle).toBeChecked();
  await expect(page.locator("body")).toHaveCSS(
    "background-color",
    "rgb(12, 12, 16)",
  );
  expect(await page.evaluate(() => localStorage.getItem("aivon-theme"))).toBe(
    "dark",
  );
  await page.reload();
  await expect(toggle).toBeChecked();
  await expect(page.locator(".entry")).toHaveCount(0);
  await toggle.click();
  await expect(toggle).not.toBeChecked();
  await page.reload();
  await expect(toggle).not.toBeChecked();
  expect(await page.evaluate(() => localStorage.getItem("aivon-theme"))).toBe(
    "light",
  );
  expect(errors).toEqual([]);
});

test("device theme is followed until the user makes a choice", async ({
  page,
}) => {
  await page.emulateMedia({ colorScheme: "dark" });
  await ready(page);
  await expect(page.locator("html")).toHaveAttribute("data-theme", "dark");
  await page.emulateMedia({ colorScheme: "light" });
  await expect(page.locator("html")).toHaveAttribute("data-theme", "light");
  await page.getByRole("switch", { name: "Mode hitam" }).click();
  await page.emulateMedia({ colorScheme: "dark" });
  await page.emulateMedia({ colorScheme: "light" });
  await expect(page.locator("html")).toHaveAttribute("data-theme", "dark");
});

test("saved theme applies before React can hydrate", async ({ page }) => {
  await page.addInitScript(() => localStorage.setItem("aivon-theme", "dark"));
  await page.route("**/_next/**/*.js*", (route) => route.abort());
  await page.goto("/", { waitUntil: "domcontentloaded" });
  await expect(page.locator("html")).toHaveAttribute("data-theme", "dark");
  await expect(page.locator("body")).toHaveCSS(
    "background-color",
    "rgb(12, 12, 16)",
  );
  await expect(page.locator(".theme-toggle")).toBeDisabled();
});

test("blocked storage does not break theme switching", async ({ page }) => {
  await page.addInitScript(() => {
    Object.defineProperty(Storage.prototype, "getItem", {
      value: () => {
        throw new Error("Storage blocked");
      },
    });
    Object.defineProperty(Storage.prototype, "setItem", {
      value: () => {
        throw new Error("Storage blocked");
      },
    });
  });
  await page.emulateMedia({ colorScheme: "light" });
  await ready(page);
  await page.getByRole("switch", { name: "Mode hitam" }).click();
  await expect(page.locator("html")).toHaveAttribute("data-theme", "dark");
  await page.emulateMedia({ colorScheme: "dark" });
  await page.emulateMedia({ colorScheme: "light" });
  await expect(page.locator("html")).toHaveAttribute("data-theme", "dark");
});

test("theme preference syncs between tabs", async ({ page, context }) => {
  await ready(page);
  const other = await context.newPage();
  await ready(other);
  await other.getByRole("switch", { name: "Mode hitam" }).click();
  await expect(page.getByRole("switch", { name: "Mode hitam" })).toBeChecked();
  await other.close();
});

test("particles recolor while paused without restarting motion", async ({
  page,
}) => {
  await ready(page);
  const canvas = page.locator(".network-canvas");
  await expect(canvas).toBeVisible();
  await expect(page.locator("html")).toHaveAttribute("data-motion", "paused");
  const fingerprint = () =>
    canvas.evaluate((el) => {
      const pixels = el
        .getContext("2d")
        .getImageData(0, 0, el.width, el.height).data;
      let hash = 0;
      for (let i = 0; i < pixels.length; i += 17)
        hash = (hash * 31 + pixels[i]) | 0;
      return hash;
    });
  const before = await fingerprint();
  await page.getByRole("switch", { name: "Mode hitam" }).click();
  await expect.poll(fingerprint).not.toBe(before);
  await expect(page.locator("html")).toHaveAttribute("data-motion", "paused");
});

test("dark theme covers cards and routing without overflow on all viewports", async ({
  page,
}) => {
  await ready(page);
  await page.getByRole("switch", { name: "Mode hitam" }).click();
  await expect(page.locator(".model-card").first()).toHaveCSS(
    "background-color",
    "rgb(21, 19, 27)",
  );
  await expect(page.locator(".workbench")).toHaveCSS(
    "background-color",
    "rgb(24, 19, 30)",
  );
  for (const width of [320, 390, 768, 1024, 1440]) {
    await page.setViewportSize({ width, height: 900 });
    await expect(
      page.getByRole("switch", { name: "Mode hitam" }),
    ).toBeVisible();
    expect(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
    ).toBe(true);
  }
});
