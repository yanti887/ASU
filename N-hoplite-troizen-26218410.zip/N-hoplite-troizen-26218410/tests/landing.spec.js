import { test, expect } from "@playwright/test";

test.beforeEach(async ({ page }) => {
  await page.goto("/");
  await expect(page.locator(".entry")).toHaveCount(0);
  await expect(page.locator(".site")).toHaveClass(/has-entered/);
});

test("AIVON branding replaces the old name and no playground remains", async ({
  page,
}) => {
  await expect(page).toHaveTitle(/AIVON/);
  await expect(page.getByRole("heading", { level: 1 })).toHaveText(
    "ONE API.MORE MODELS.LESS FRICTION.",
  );
  await expect(page.locator("body")).not.toContainText(/GERAI|playground/i);
  await expect(page.locator("dialog, textarea")).toHaveCount(0);
  await expect(page.locator(".model-card")).toHaveCount(3);
});

test("search, categories, empty state and catalog expansion", async ({
  page,
}) => {
  await page.getByRole("button", { name: "Explore all 6 models" }).click();
  await expect(page.locator(".model-card")).toHaveCount(6);
  await page.getByRole("searchbox", { name: "Cari model" }).fill("ClAuDe");
  await expect(page.locator(".model-card")).toHaveCount(1);
  await expect(page.locator(".model-card")).toContainText("Claude Sonnet");
  await page.getByRole("button", { name: "Multimodal", exact: true }).click();
  await expect(page.locator(".empty-models")).toBeVisible();
  await page.getByRole("button", { name: "Reset pencarian" }).click();
  await expect(page.locator(".model-card")).toHaveCount(6);
  await page.getByRole("button", { name: "Coding", exact: true }).click();
  await expect(page.locator(".model-card")).toHaveCount(2);
  await page.getByRole("button", { name: "Show featured models" }).click();
  await expect(page.locator(".model-card")).toHaveCount(3);
});

test("model details expand and copy the correct identifier", async ({
  page,
  context,
}) => {
  await context.grantPermissions(["clipboard-read", "clipboard-write"]);
  const card = page.locator('[data-model="anthropic/claude-sonnet-4"]');
  await card.click();
  await expect(card).toHaveAttribute("aria-expanded", "true");
  await expect(page.locator("#model-detail")).toContainText("Claude Sonnet");
  await page.getByRole("button", { name: "Salin model ID" }).click();
  expect(await page.evaluate(() => navigator.clipboard.readText())).toBe(
    "anthropic/claude-sonnet-4",
  );
  await page.getByRole("button", { name: "Tutup detail model" }).click();
  await expect(page.locator("#model-detail")).toHaveCount(0);
  await expect(card).toHaveAttribute("aria-expanded", "false");
});

test("search keyboard shortcut focuses the catalog input", async ({ page }) => {
  await page.keyboard.press("/");
  await expect(
    page.getByRole("searchbox", { name: "Cari model" }),
  ).toBeFocused();
  await page.keyboard.type("Gemini");
  await expect(page.locator(".model-card")).toHaveCount(1);
  await expect(page.locator(".model-card")).toContainText("Gemini Pro");
});

test("content stays visible when JavaScript is unavailable", async ({
  browser,
}) => {
  const context = await browser.newContext({ javaScriptEnabled: false });
  const page = await context.newPage();
  await page.goto("http://127.0.0.1:3000/");
  await expect(page.locator(".entry")).toBeHidden();
  await expect(page.locator("h1 .line").first().locator("span")).toHaveCSS(
    "transform",
    "none",
  );
  await expect(page.locator(".hero-actions")).toHaveCSS("opacity", "1");
  await expect(page.locator(".model-card")).toHaveCount(3);
  await context.close();
});

test("routing explanation switches providers without sending a request", async ({
  page,
}) => {
  const posts = [];
  page.on("request", (request) => {
    if (request.method() === "POST") posts.push(request.url());
  });
  await page.locator(".usecase").nth(2).click();
  await expect(page.locator(".route-destinations")).toContainText("Google");
  await expect(page.locator(".route-destinations")).toContainText("Meta");
  await expect(page.locator(".request-node")).toContainText("Multimodal input");
  await page.locator(".usecase").nth(1).click();
  await expect(page.locator(".route-destinations")).toContainText("DeepSeek");
  expect(posts).toEqual([]);
});

test("code language and clipboard match the chosen language", async ({
  page,
  context,
}) => {
  await context.grantPermissions(["clipboard-read", "clipboard-write"]);
  await page.getByRole("button", { name: "Python", exact: true }).click();
  await expect(page.locator("pre")).toContainText("from openai import OpenAI");
  await expect(page.locator(".code-header")).toContainText("hello-aivon.py");
  await page.getByRole("button", { name: "Salin contoh kode" }).click();
  await expect(page.locator(".toast")).toContainText("Python code copied");
  const clipboard = await page.evaluate(() => navigator.clipboard.readText());
  expect(clipboard).toContain('os.environ["AIVON_API_KEY"]');
  expect(clipboard).not.toContain("const aivon");
});

test("FAQ and integration notes expand", async ({ page }) => {
  await page.locator(".faq-list summary").first().click();
  await expect(page.locator(".faq-list details").first()).toHaveAttribute(
    "open",
    "",
  );
  await page.locator("#integration-guide summary").click();
  await expect(page.locator("#integration-guide")).toHaveAttribute("open", "");
  await expect(page.locator("#integration-guide")).toContainText(
    "Jangan letakkan API key di browser",
  );
});

test("particle scene draws without WebGL and respects reduced motion", async ({
  page,
}) => {
  await expect(page.locator("canvas.network-canvas")).toBeVisible();
  await expect(page.locator("html")).toHaveAttribute("data-motion", "paused");
  const painted = await page
    .locator("canvas.network-canvas")
    .evaluate((canvas) => {
      const pixels = canvas
        .getContext("2d")
        .getImageData(0, 0, canvas.width, canvas.height).data;
      return pixels.some((value, index) => index % 4 === 3 && value > 0);
    });
  expect(painted).toBe(true);
  await page.emulateMedia({ reducedMotion: "no-preference" });
  await expect(page.locator("html")).toHaveAttribute("data-motion", "active");
  await page.getByRole("button", { name: "Jeda animasi", exact: true }).click();
  await expect(page.locator("html")).toHaveAttribute("data-motion", "paused");
  await expect(page.locator(".signal").first()).toHaveCSS(
    "animation-play-state",
    "paused",
  );
});

for (const width of [320, 390, 768, 1024, 1440]) {
  test(`no page overflow or cut-off headline at ${width}px`, async ({
    page,
  }) => {
    await page.setViewportSize({ width, height: 900 });
    await page.evaluate(() => document.fonts.ready);
    expect(
      await page.evaluate(
        () => document.documentElement.scrollWidth > innerWidth,
      ),
    ).toBe(false);
    const headlineFits = await page.locator("h1 .line").evaluateAll((lines) =>
      lines.every((line) => {
        const range = document.createRange();
        range.selectNodeContents(line);
        return (
          range.getBoundingClientRect().right <=
          line.getBoundingClientRect().right + 1
        );
      }),
    );
    expect(headlineFits).toBe(true);
    if (width < 540) {
      await page.getByRole("button", { name: "Buka menu" }).click();
      await expect(page.locator("#main-nav")).toBeVisible();
      await page.locator('#main-nav a[href="#models"]').click();
      await expect(page.locator("#main-nav")).not.toBeVisible();
      await expect(page).toHaveURL(/#models$/);
    }
  });
}

test("sword intro is brief and skippable with motion enabled", async ({
  page,
}) => {
  const errors = [];
  page.on("pageerror", (error) => errors.push(error.message));
  await page.emulateMedia({ reducedMotion: "no-preference" });
  await page.reload();
  await expect(page.locator(".entry")).toBeVisible();
  await expect(page.locator(".entry-sword svg")).toBeVisible();
  await page.getByRole("button", { name: "Skip intro" }).click();
  await expect(page.locator(".entry")).toHaveCount(0);
  await expect(page.locator(".site")).toHaveClass(/has-entered/);
  expect(errors).toEqual([]);
});

test("floating provider shortcuts filter the catalog", async ({ page }) => {
  await page.locator(".provider-beacon").filter({ hasText: "Claude" }).click();
  await expect(page).toHaveURL(/#models$/);
  await expect(page.getByRole("searchbox", { name: "Cari model" })).toHaveValue(
    "Anthropic",
  );
  await expect(page.locator(".model-card")).toHaveCount(1);
  await expect(page.locator(".model-card")).toContainText("Claude Sonnet");
});

test("motion dock freezes CSS and canvas, then resumes both", async ({
  page,
}) => {
  await page.emulateMedia({ reducedMotion: "no-preference" });
  const canvas = page.locator(".network-canvas");
  await expect(canvas).toBeVisible();
  await expect(page.locator("html")).toHaveAttribute("data-motion", "active");
  await page.locator(".motion-dock").click();
  await expect(page.locator("html")).toHaveAttribute("data-motion", "paused");
  await expect(page.locator(".provider-beacon").first()).toHaveCSS(
    "animation-play-state",
    "paused",
  );
  await expect(page.locator(".provider-track")).toHaveCSS(
    "animation-play-state",
    "paused",
  );
  const frozen = await canvas.evaluate((el) => el.toDataURL());
  await page.waitForTimeout(250);
  expect(await canvas.evaluate((el) => el.toDataURL())).toBe(frozen);
  await page.locator(".motion-dock").click();
  await expect(page.locator("html")).toHaveAttribute("data-motion", "active");
  await expect
    .poll(() => canvas.evaluate((el) => el.toDataURL()))
    .not.toBe(frozen);
});

test("reduced motion keeps cards visible and cannot be overridden accidentally", async ({
  page,
}) => {
  await expect(page.locator(".motion-dock")).toBeDisabled();
  await expect(page.locator(".model-card").first()).toHaveCSS("opacity", "1");
  await expect(page.locator(".provider-beacon").first()).toHaveCSS(
    "animation-name",
    "none",
  );
  await page
    .locator(".category-tabs")
    .getByRole("button", { name: "Coding", exact: true })
    .click();
  await expect(page.locator(".model-card").first()).toHaveCSS("opacity", "1");
});

test("routing motion sleeps offscreen and wakes when visible", async ({
  page,
}) => {
  await page.emulateMedia({ reducedMotion: "no-preference" });
  await expect(page.locator(".workbench")).toHaveAttribute(
    "data-motion-visible",
    "false",
  );
  await expect(page.locator(".packet-primary")).toHaveCSS(
    "animation-play-state",
    "paused",
  );
  await page.locator(".workbench").scrollIntoViewIfNeeded();
  await expect(page.locator(".workbench")).toHaveAttribute(
    "data-motion-visible",
    "true",
  );
  await expect(page.locator(".packet-primary")).toHaveCSS(
    "animation-play-state",
    "running",
  );
  await expect(page.locator(".request-cycle")).toContainText("MATCH");
  await page.locator(".usecase").nth(1).click();
  await expect(page.locator(".route-destinations")).toContainText("DeepSeek");
  await page.locator(".usecase").nth(2).click();
  await expect(page.locator(".route-destinations")).toContainText("Google");
  await expect(page.locator(".route-destinations")).toContainText("Meta");
  await page.locator(".motion-dock").click();
  await expect(page.locator(".packet-primary")).toHaveCSS(
    "animation-play-state",
    "paused",
  );
});

test("animated marquee and floating badges do not overflow on mobile", async ({
  page,
}) => {
  await page.emulateMedia({ reducedMotion: "no-preference" });
  for (const width of [320, 390, 768, 1024, 1440]) {
    await page.setViewportSize({ width, height: 900 });
    expect(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
    ).toBe(true);
  }
});
