import { test, expect } from "@playwright/test";
import {
  calculateCredits,
  calculateModelCost,
  csvCell,
  dailyUsage,
  dashboardModels,
  formatTokens,
  usageSummary,
} from "../src/lib/dashboard-data.ts";

test("model pricing keeps input, output, and credit multiplier as separate values", () => {
  expect(dashboardModels).toHaveLength(6);
  for (const model of dashboardModels) {
    expect(model).toHaveProperty("inputPricePerMillion");
    expect(model).toHaveProperty("outputPricePerMillion");
    expect(model).toHaveProperty("multiplier");
    expect(model.multiplier).toBeGreaterThan(0);
  }
  const priced = {
    ...dashboardModels[0],
    inputPricePerMillion: 3,
    outputPricePerMillion: 9,
    multiplier: 2.5,
  };
  expect(calculateModelCost(priced, 1_000_000, 500_000)).toBe(7.5);
  expect(calculateCredits(priced, 1_000_000, 500_000)).toBe(3_750_000);
  expect(
    calculateModelCost(dashboardModels[0], 1_000_000, 1_000_000),
  ).toBeNull();
  expect(() => calculateCredits(priced, -1, 0)).toThrow(RangeError);
  expect(() => calculateModelCost(priced, 1_000_000_001, 0)).toThrow(
    RangeError,
  );
});

test("usage summaries and chart buckets handle empty and recorded data", () => {
  expect(usageSummary([])).toEqual({
    requests: 0,
    tokens: 0,
    input: 0,
    output: 0,
    success: 0,
    latency: 0,
  });
  const now = new Date().toISOString();
  const records = [
    {
      id: "req-1",
      timestamp: now,
      modelId: dashboardModels[0].id,
      keyId: "key-1",
      input: 100,
      output: 25,
      billed: 313,
      latency: 121,
      status: "success",
    },
    {
      id: "req-2",
      timestamp: now,
      modelId: dashboardModels[0].id,
      keyId: "key-1",
      input: 0,
      output: 0,
      billed: 0,
      latency: 0,
      status: "error",
    },
  ];
  const summary = usageSummary(records);
  expect(summary).toMatchObject({
    requests: 2,
    tokens: 313,
    input: 100,
    output: 25,
    success: 50,
    latency: 121,
  });
  const chart = dailyUsage(1, records);
  expect(chart[0]).toMatchObject({ requests: 2, tokens: 313 });
  expect(
    dailyUsage(7, []).every(
      (point) => point.requests === 0 && point.tokens === 0,
    ),
  ).toBe(true);
});

test("CSV cells escape formulas and token formatter remains stable", () => {
  expect(csvCell('Builder "personal"')).toBe('"Builder ""personal"""');
  expect(csvCell("=SUM(1,2)")).toBe('"\'=SUM(1,2)"');
  expect(csvCell("+123")).toBe('"\'+123"');
  expect(csvCell(1500)).toBe('"1500"');
  expect(formatTokens(1_000_000)).toBe("1M");
  expect(formatTokens(0)).toBe("0");
});
