import { randomUUID } from "node:crypto";
import { test, expect } from "@playwright/test";

const password = "Aivon-test-passphrase-2026";

async function fillRegistration(page, email) {
  await page
    .getByLabel("Nama lengkap", { exact: true })
    .fill("Aivon Test Builder");
  await page.getByLabel("Email", { exact: true }).fill(email);
  await page.getByLabel("Kata sandi", { exact: true }).fill(password);
  await page.getByLabel("Ulangi kata sandi", { exact: true }).fill(password);
}

test("guest profile invites authentication before account fields are available", async ({
  page,
}) => {
  await page.goto("/dashboard/profile");
  await expect(
    page.getByRole("heading", { name: "Mulai dengan akunmu sendiri." }),
  ).toBeVisible();
  await expect(
    page.getByRole("link", { name: "Buat akun", exact: true }),
  ).toHaveAttribute("href", "/register?next=%2Fdashboard%2Fprofile");
  await expect(page.getByLabel("Nama tampilan", { exact: true })).toHaveCount(
    0,
  );
});

test("registration progressively validates and accessibly reveals both passwords", async ({
  page,
}) => {
  let requests = 0;
  page.on("request", (request) => {
    if (request.url().endsWith("/api/auth/register")) requests += 1;
  });
  await page.goto("/register");
  await expect(page.getByText("Nama perlu berisi 2–64 karakter.")).toHaveCount(
    0,
  );
  await page.getByLabel("Nama lengkap", { exact: true }).fill("A");
  await page.getByLabel("Email", { exact: true }).focus();
  await expect(
    page.getByText("Nama perlu berisi 2–64 karakter."),
  ).toBeVisible();
  await page.getByRole("button", { name: "Buat akun", exact: true }).click();
  await expect(page.getByLabel("Nama lengkap", { exact: true })).toBeFocused();
  await expect(page.getByLabel("Email", { exact: true })).toHaveAttribute(
    "aria-invalid",
    "true",
  );

  await fillRegistration(page, "validation@example.com");
  const input = page.getByLabel("Kata sandi", { exact: true });
  await expect(input).toHaveAttribute("minlength", "12");
  await expect(input).toHaveAttribute("maxlength", "128");
  await expect(input).toHaveAttribute("autocomplete", "new-password");
  const reveal = page.getByRole("button", {
    name: "Tampilkan kata sandi",
    exact: true,
  });
  await reveal.focus();
  await page.keyboard.press("Space");
  await expect(input).toHaveAttribute("type", "text");
  await expect(
    page.getByRole("button", { name: "Sembunyikan kata sandi", exact: true }),
  ).toHaveAttribute("aria-pressed", "true");
  await page
    .getByRole("button", { name: "Sembunyikan kata sandi", exact: true })
    .click();
  await expect(input).toHaveAttribute("type", "password");

  await page
    .getByRole("button", { name: "Tampilkan ulangan kata sandi", exact: true })
    .click();
  await expect(
    page.getByLabel("Ulangi kata sandi", { exact: true }),
  ).toHaveAttribute("type", "text");
  await page
    .getByLabel("Ulangi kata sandi", { exact: true })
    .fill("A-different-passphrase");
  await page.getByRole("button", { name: "Buat akun", exact: true }).click();
  await expect(page.getByText("Kedua kata sandi belum cocok.")).toBeVisible();
  await expect(
    page.getByLabel("Ulangi kata sandi", { exact: true }),
  ).toBeFocused();
  expect(requests).toBe(0);
});

test("pending and failed signup stays on the form without creating an account", async ({
  page,
}) => {
  let release;
  const responseGate = new Promise((resolve) => {
    release = resolve;
  });
  await page.route("**/api/auth/register", async (route) => {
    await responseGate;
    await route.fulfill({
      status: 503,
      contentType: "application/json",
      body: JSON.stringify({ error: "Service unavailable" }),
    });
  });
  await page.goto("/register");
  await fillRegistration(page, "failure@example.com");
  await page.getByRole("button", { name: "Buat akun", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Membuat akun…", exact: true }),
  ).toBeDisabled();
  await expect(page.getByLabel("Email", { exact: true })).toBeDisabled();
  release();
  await expect(page.getByText("Akun belum dapat diproses.")).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Buat akun", exact: true }),
  ).toBeEnabled();
  await expect(page).toHaveURL(/\/register$/);
  expect(await page.evaluate(() => JSON.stringify(localStorage))).not.toContain(
    password,
  );
});

test("next accepts dashboard destinations only and preserves them between forms", async ({
  page,
}) => {
  for (const next of [
    "https://example.com/",
    "//example.com/",
    "/dashboard-elsewhere",
    "/dashboard/../../login",
    "/dashboard/%2f..%2flogin",
    "/dashboard\\..\\login",
  ]) {
    await page.goto(`/login?next=${encodeURIComponent(next)}`);
    await expect(
      page.getByRole("link", { name: "Daftar sekarang" }),
    ).toHaveAttribute("href", "/register?next=%2Fdashboard");
  }
  const next = "/dashboard/models?category=Reasoning#catalog";
  await page.goto(`/login?next=${encodeURIComponent(next)}`);
  await expect(
    page.getByRole("link", { name: "Daftar sekarang" }),
  ).toHaveAttribute("href", `/register?next=${encodeURIComponent(next)}`);
  await page.getByRole("link", { name: "Daftar sekarang" }).click();
  await expect(
    page.getByRole("link", { name: "Masuk", exact: true }),
  ).toHaveAttribute("href", `/login?next=${encodeURIComponent(next)}`);
});

test("real signup, persisted profile, logout and login use the server account", async ({
  page,
  context,
}) => {
  const email = `auth-ui-${randomUUID()}@example.com`;
  await page.goto("/register?next=%2Fdashboard%2Fprofile");
  await fillRegistration(page, email);
  await page.getByRole("button", { name: "Buat akun", exact: true }).click();
  await expect(page).toHaveURL(/\/dashboard\/profile$/);
  await expect(page.getByLabel("Email akun", { exact: true })).toHaveValue(
    email,
  );
  await expect(page.getByLabel("Email akun", { exact: true })).toHaveAttribute(
    "readonly",
    "",
  );
  const cookies = await context.cookies();
  expect(
    cookies.some(
      (cookie) =>
        cookie.httpOnly && ["Lax", "Strict"].includes(cookie.sameSite),
    ),
  ).toBe(true);
  const workspace = await page.request.get("/api/workspace");
  expect(workspace.ok()).toBe(true);
  const account = await workspace.json();
  expect(account.state.authenticated).toBe(true);
  expect(account.state.profile.email).toBe(email);

  await page
    .getByLabel("Nama tampilan", { exact: true })
    .fill("Updated Test Builder");
  await page
    .getByLabel("Nama workspace", { exact: true })
    .fill("Persisted Test Workspace");
  await page
    .getByLabel("Zona waktu", { exact: true })
    .selectOption("Asia/Tokyo");
  await page.getByLabel("Peran", { exact: true }).selectOption("Designer");
  await page
    .getByRole("button", { name: "Simpan profil", exact: true })
    .click();
  await expect(
    page.getByText("Profil berhasil disimpan.", { exact: true }),
  ).toBeVisible();
  await page.reload();
  await expect(page.getByLabel("Nama tampilan", { exact: true })).toHaveValue(
    "Updated Test Builder",
  );
  await expect(page.getByLabel("Nama workspace", { exact: true })).toHaveValue(
    "Persisted Test Workspace",
  );
  await expect(page.getByLabel("Zona waktu", { exact: true })).toHaveValue(
    "Asia/Tokyo",
  );
  await expect(page.getByLabel("Peran", { exact: true })).toHaveValue(
    "Designer",
  );
  expect(await page.evaluate(() => JSON.stringify(localStorage))).not.toContain(
    password,
  );

  await page
    .getByRole("button", { name: "Keluar dari akun", exact: true })
    .click();
  await expect(page).toHaveURL(/\/login$/);
  const guest = await (await page.request.get("/api/workspace")).json();
  expect(guest.state.authenticated).toBe(false);
  await page.goto("/login?next=%2Fdashboard%2Fprofile");
  await expect(page.getByLabel("Kata sandi", { exact: true })).toHaveAttribute(
    "autocomplete",
    "current-password",
  );
  await page.getByLabel("Email", { exact: true }).fill(email);
  await page
    .getByLabel("Kata sandi", { exact: true })
    .fill("An-incorrect-passphrase");
  await page.getByRole("button", { name: "Masuk", exact: true }).click();
  await expect(
    page.getByText("Email atau kata sandi tidak cocok."),
  ).toBeVisible();
  await page.getByLabel("Kata sandi", { exact: true }).fill(password);
  await page.getByRole("button", { name: "Masuk", exact: true }).click();
  await expect(page).toHaveURL(/\/dashboard\/profile$/);
  await expect(page.getByLabel("Nama tampilan", { exact: true })).toHaveValue(
    "Updated Test Builder",
  );
  await expect(page.getByLabel("Email akun", { exact: true })).toHaveValue(
    email,
  );
});

test("auth remains responsive and honors shared theme and reduced motion", async ({
  page,
}) => {
  await page.emulateMedia({ colorScheme: "dark", reducedMotion: "reduce" });
  for (const route of ["/register", "/login"]) {
    await page.goto(route);
    await expect(page.locator("html")).toHaveAttribute("data-theme", "dark");
    await expect(page.locator("html")).toHaveAttribute("data-motion", "paused");
    await expect(
      page.getByRole("button", { name: "Aktifkan animasi", exact: true }),
    ).toBeDisabled();
    for (const width of [320, 390, 768, 1440]) {
      await page.setViewportSize({ width, height: 900 });
      await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
      await expect(page.getByLabel("Email", { exact: true })).toBeVisible();
      expect(
        await page.evaluate(
          () => document.documentElement.scrollWidth <= innerWidth,
        ),
      ).toBe(true);
    }
  }
});
