const nextConfig = {
  devIndicators: false,
  allowedDevOrigins: [
    "127.0.0.1",
    "*.preview.usehoplite.com",
    "*.w.modal.host",
  ],
};

export default nextConfig;
