# AIVON®

AIVON adalah antarmuka gateway AI berbasis Next.js App Router, React, TypeScript, dan Tailwind CSS v4. Landing, autentikasi, dan dashboard memakai tipografi Manrope/IBM Plex Mono, aksen violet, tema terang/gelap, serta animasi yang menghormati pengaturan reduced motion.

## Menjalankan secara lokal

```sh
npm ci
npm run dev
```

Server pengembangan berjalan di port `3000`. Runtime memerlukan Node.js 24 atau lebih baru karena penyimpanan akun memakai `node:sqlite`.

```sh
npm run check   # TypeScript
npm run build   # build produksi
npm run format  # format source dan test
npm test        # browser dan API checks
```

Untuk menjalankan browser checks pertama kali:

```sh
npx playwright install chromium
```

## Akun dan workspace

- `/register` dan `/login` menyediakan alur akun AIVON dengan validasi progresif, konfirmasi kata sandi, show/hide password, redirect internal yang tervalidasi, serta visual orbit yang konsisten dengan landing.
- Kata sandi di-hash menggunakan `scrypt`; session memakai cookie `HttpOnly`, `SameSite=Lax`, dan token sesi opaque yang disimpan sebagai hash.
- Dashboard membaca workspace dari endpoint server, bukan dari `localStorage`. Profil, pilihan model, notifikasi, dan metadata API key tersimpan di SQLite.
- API key baru dikembalikan sekali saat dibuat. Server hanya menyimpan hash key dan suffix untuk pengelolaan berikutnya. Pembuatan, pencabutan, dan pembatasan key memerlukan session akun yang sah.
- Database default berada di `.data/aivon.sqlite`. Pada deployment, set `AIVON_DB_PATH` ke volume persisten yang dapat ditulis dan dibagikan oleh seluruh instance aplikasi. Instance tanpa penyimpanan persisten tidak boleh digunakan untuk akun atau API key.

## Dashboard

Landing CTA **Explore models** langsung menuju `/dashboard`. Pengunjung dapat melihat katalog sebagai tamu; tindakan yang menyimpan data meminta login atau pendaftaran.

- **Overview dan Usage:** menampilkan empty state sampai gateway benar-benar mengirim catatan request. Inference belum dikonfigurasi, sehingga belum ada endpoint yang mencatat penggunaan.
- **API keys:** kelola key yang tersimpan di akun. Key belum dapat dipakai untuk inferensi sampai gateway dan validasi key dikonfigurasi.
- **Models & pricing:** setiap model menampilkan **Input — USD per 1M token**, **Output — USD per 1M token**, dan **Credit multiplier** secara terpisah. Tarif AIVON yang belum ditetapkan tampil sebagai **Belum ditetapkan**; nilai tersebut tidak berarti gratis. Kredit dihitung dari `(input + output) × multiplier`, sedangkan biaya USD menggunakan tarif input dan output tanpa multiplier.
- **Billing:** checkout, metode pembayaran, paket token, saldo, dan riwayat pembayaran belum dikonfigurasi.
- **Profile:** profil dan preferensi akun disimpan melalui server; email sign-in tidak dapat diubah dari halaman profil.

## Batasan layanan saat ini

Katalog dan pengelolaan akun tersedia, tetapi gateway inference, ingestion usage, tarif komersial, dan integrasi pembayaran belum dikonfigurasi. Jangan menganggap model dapat dipanggil, harga telah aktif, atau API key telah memberi akses ke provider sebelum layanan tersebut disambungkan dan diverifikasi.

Contoh integrasi memakai `AIVON_BASE_URL` dan `AIVON_API_KEY` hanya pada lingkungan server. Jangan pernah menaruh API key pada variabel `NEXT_PUBLIC_` atau kode klien.
