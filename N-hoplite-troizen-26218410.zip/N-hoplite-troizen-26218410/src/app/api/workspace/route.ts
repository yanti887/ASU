import { accountId } from "@/lib/server/auth";
import { ApiError, body, json, respond, sameOrigin } from "@/lib/server/http";
import { mutateWorkspace, workspace } from "@/lib/server/workspace";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  return respond(() => json({ state: workspace(accountId(request)) }));
}

export async function POST(request: Request) {
  return respond(async () => {
    sameOrigin(request);
    const data = await body(request);
    const id = accountId(request, true);
    if (!id) throw new ApiError(401, "Sign in to manage your workspace.");
    return json(mutateWorkspace(id, data));
  });
}
