import { cookie, logout } from "@/lib/server/auth";
import { json, respond, sameOrigin } from "@/lib/server/http";
import { workspace } from "@/lib/server/workspace";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  return respond(async () => {
    sameOrigin(request);
    logout(request);
    return json({ state: workspace(null) }, 200, {
      "Set-Cookie": cookie(request, "", true),
    });
  });
}
