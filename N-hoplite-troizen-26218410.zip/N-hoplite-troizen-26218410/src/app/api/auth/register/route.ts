import { cookie, register } from "@/lib/server/auth";
import { body, json, respond, sameOrigin } from "@/lib/server/http";
import { workspace } from "@/lib/server/workspace";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  return respond(async () => {
    sameOrigin(request);
    const result = await register(await body(request), request);
    return json({ state: workspace(result.id) }, 201, {
      "Set-Cookie": cookie(request, result.token),
    });
  });
}
