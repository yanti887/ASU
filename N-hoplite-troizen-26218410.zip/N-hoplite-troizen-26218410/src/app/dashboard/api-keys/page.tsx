import KeysPage from "@/components/dashboard/keys-page";
export default function Page() {
  return <KeysPage />;
}
