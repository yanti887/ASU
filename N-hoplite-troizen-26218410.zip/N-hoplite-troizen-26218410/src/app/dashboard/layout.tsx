import type { Metadata } from "next";
import { DashboardProvider } from "@/components/dashboard/store";
import DashboardShell from "@/components/dashboard/shell";
import "./dashboard.css";
import "@/components/dashboard/workspace-pages.css";
import "@/components/dashboard/keys-billing.css";

export const metadata: Metadata = {
  title: "Dashboard — AIVON",
  robots: { index: false, follow: false },
};
export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <DashboardProvider>
      <DashboardShell>{children}</DashboardShell>
    </DashboardProvider>
  );
}
