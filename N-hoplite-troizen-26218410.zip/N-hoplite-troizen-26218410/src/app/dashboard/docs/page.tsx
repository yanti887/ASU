import DocsPage from "@/components/dashboard/docs-page";
export default function Page() {
  return <DocsPage />;
}
