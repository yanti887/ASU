import { Suspense } from "react";
import ModelsPage from "@/components/dashboard/models-page";
export default function Page() {
  return (
    <Suspense fallback={<p className="db-muted">Loading models…</p>}>
      <ModelsPage />
    </Suspense>
  );
}
