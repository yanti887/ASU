import type { Metadata } from "next";
import "@fontsource/manrope/latin-400.css";
import "@fontsource/manrope/latin-500.css";
import "@fontsource/manrope/latin-600.css";
import "@fontsource/manrope/latin-700.css";
import "@fontsource/ibm-plex-mono/latin-400.css";
import "./globals.css";
import "./motion.css";
import "./theme.css";
import { themeBootScript } from "@/lib/theme";

export const metadata: Metadata = {
  title: "AIVON — One API. More models. Less friction.",
  description:
    "Your independent AI gateway. Akses berbagai keluarga model melalui satu integrasi. Lebih sedikit kerumitan, lebih banyak ruang untuk membangun.",
  icons: { icon: "/favicon.svg" },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="id" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeBootScript }} />
      </head>
      <body>
        <noscript>
          <style>{`.entry{display:none}.hero-copy h1 .line>span{transform:none}.hero-value-lines,.hero-actions,.hero-caption,[data-reveal]{opacity:1;transform:none}`}</style>
        </noscript>
        {children}
      </body>
    </html>
  );
}
