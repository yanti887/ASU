import type { Metadata } from "next";
import AuthForm from "@/components/auth/auth-form";
import { safeDashboardNext } from "@/components/auth/redirect";

export const metadata: Metadata = {
  title: "Daftar — AIVON",
  description: "Buat akun AIVON untuk menyimpan profil dan pilihan modelmu.",
  robots: { index: false, follow: false },
};

export default async function RegisterPage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string | string[] }>;
}) {
  const { next } = await searchParams;
  return <AuthForm mode="register" next={safeDashboardNext(next)} />;
}
