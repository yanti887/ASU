import type { Metadata } from "next";
import AuthForm from "@/components/auth/auth-form";
import { safeDashboardNext } from "@/components/auth/redirect";

export const metadata: Metadata = {
  title: "Masuk — AIVON",
  description: "Masuk ke akun AIVON dan lanjutkan membangun di workspace-mu.",
  robots: { index: false, follow: false },
};

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string | string[] }>;
}) {
  const { next } = await searchParams;
  return <AuthForm mode="login" next={safeDashboardNext(next)} />;
}
