import type { SVGProps } from "react";

type IconProps = SVGProps<SVGSVGElement>;

export function Mark(props: IconProps) {
  return (
    <svg viewBox="0 0 32 32" fill="none" aria-hidden="true" {...props}>
      <path d="M16 2 30 28H21L16 18 11 28H2L16 2Z" fill="currentColor" />
      <path d="m16 11 4 8h-8l4-8Z" fill="var(--mark-cutout, #f2f0e9)" />
    </svg>
  );
}

export function Arrow({
  diagonal = false,
  ...props
}: IconProps & { diagonal?: boolean }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      aria-hidden="true"
      {...props}
    >
      {diagonal ? (
        <path d="M6 18 18 6M6 6h12v12" />
      ) : (
        <path d="M4 12h15m-6-6 6 6-6 6" />
      )}
    </svg>
  );
}

export function CopyIcon(props: IconProps) {
  return (
    <svg
      viewBox="0 0 20 20"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.3"
      aria-hidden="true"
      {...props}
    >
      <rect x="7" y="7" width="10" height="10" rx="1.5" />
      <path d="M13 4V3H3v10h1" />
    </svg>
  );
}

export function ProviderIcon({
  provider,
  ...props
}: IconProps & { provider: string }) {
  return (
    <svg viewBox="0 0 36 36" fill="none" aria-hidden="true" {...props}>
      {provider === "OpenAI" && (
        <g stroke="currentColor" strokeWidth="1.6">
          {Array.from({ length: 6 }, (_, i) => (
            <path
              key={i}
              d="M18 6c-7-4-14 5-9 11l9 6 9-5V9L18 4"
              transform={`rotate(${i * 60} 18 18)`}
            />
          ))}
        </g>
      )}
      {provider === "Anthropic" && (
        <g stroke="currentColor" strokeWidth="2.1">
          {Array.from({ length: 12 }, (_, i) => (
            <path
              key={i}
              d="m18 4-1 10"
              transform={`rotate(${i * 30} 18 18)`}
            />
          ))}
        </g>
      )}
      {provider === "Google" && (
        <path
          d="M18 2C20 12 24 16 34 18 24 20 20 24 18 34 16 24 12 20 2 18 12 16 16 12 18 2Z"
          fill="currentColor"
        />
      )}
      {provider === "DeepSeek" && (
        <path
          d="M4 17c5-4 10 5 17 1 2-2 3-6 6-6l5 2-4 3c-1 8-9 12-16 7-4-3-6-6-8-7Zm21-9 2 4-5 1"
          stroke="currentColor"
          strokeWidth="1.7"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      )}
      {provider === "Mistral" && (
        <path
          d="M4 7h7v7h7V7h7v7h7v15h-7v-8h-7v8h-7V14H4V7Z"
          fill="currentColor"
        />
      )}
      {provider === "Meta" && (
        <path
          d="M3 23C3 4 11 4 18 18s15 15 15 3C33 4 25 6 18 18S3 33 3 23Z"
          stroke="currentColor"
          strokeWidth="2.5"
          strokeLinecap="round"
        />
      )}
    </svg>
  );
}

export function SwordGlyph(props: IconProps) {
  return (
    <svg viewBox="0 0 100 220" fill="none" aria-hidden="true" {...props}>
      <path d="m39 61 11-7 11 7-3 105-8 27-8-27-3-105Z" fill="#d4dbc9" />
      <path d="M50 56v135l8-25 3-105-11-5Z" fill="#7c8977" />
      <path d="M19 53 39 61H61l20-8-2 14-18 5H39l-18-5-2-14Z" fill="#c3a56d" />
      <path d="M44 22h12v36H44V22Z" fill="#57644b" />
      <path
        d="m44 27 12 6m-12 2 12 6m-12 2 12 6"
        stroke="#ad976f"
        strokeWidth="3"
      />
      <path d="m50 9 10 10-4 9H44l-4-9L50 9Z" fill="#d2b885" />
      <path d="m50 13 5 6-5 5-5-5 5-6Z" fill="#ed7041" />
    </svg>
  );
}
