"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { ProviderIcon } from "@/components/icons";
import {
  calculateCredits,
  calculateModelCost,
  dashboardModels,
  formatNumber,
  type DashboardModel,
} from "@/lib/dashboard-data";
import { useDashboard } from "./store";
import { DIcon, EmptyState, Modal, PageHeading } from "./ui";

type Sort = "name" | "input" | "output" | "multiplier" | "context";
const maxTokens = 1_000_000_000;
const usd = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  currencyDisplay: "code",
  minimumFractionDigits: 2,
  maximumFractionDigits: 6,
});

function formatPrice(price: number | null) {
  return price === null ? "Belum ditetapkan" : usd.format(price);
}

function comparePrice(a: number | null, b: number | null) {
  if (a === null) return b === null ? 0 : 1;
  if (b === null) return -1;
  return a - b;
}

function contextInThousands(context: string) {
  const value = Number.parseFloat(context);
  return context.endsWith("M") ? value * 1000 : value;
}

export default function ModelsPage() {
  const { state, toggleFavorite, copy } = useDashboard();
  const searchParams = useSearchParams();
  const queryFromUrl = searchParams.get("q") ?? "";
  const [query, setQuery] = useState(queryFromUrl);
  const [provider, setProvider] = useState("All providers");
  const [category, setCategory] = useState("All categories");
  const [sort, setSort] = useState<Sort>("name");
  const [selected, setSelected] = useState<DashboardModel | null>(null);
  const [pendingFavorites, setPendingFavorites] = useState<string[]>([]);
  const providers = [
    ...new Set(dashboardModels.map((model) => model.provider)),
  ];
  const categories = [
    ...new Set(dashboardModels.map((model) => model.category)),
  ];
  useEffect(() => {
    setQuery(queryFromUrl);
  }, [queryFromUrl]);
  const models = useMemo(
    () =>
      dashboardModels
        .filter(
          (model) =>
            (provider === "All providers" || model.provider === provider) &&
            (category === "All categories" || model.category === category),
        )
        .filter((model) =>
          `${model.name} ${model.provider} ${model.id}`
            .toLowerCase()
            .includes(query.trim().toLowerCase()),
        )
        .sort((a, b) => {
          let comparison = 0;
          if (sort === "input")
            comparison = comparePrice(
              a.inputPricePerMillion,
              b.inputPricePerMillion,
            );
          if (sort === "output")
            comparison = comparePrice(
              a.outputPricePerMillion,
              b.outputPricePerMillion,
            );
          if (sort === "multiplier") comparison = a.multiplier - b.multiplier;
          if (sort === "context")
            comparison =
              contextInThousands(b.context) - contextInThousands(a.context);
          return comparison || a.name.localeCompare(b.name);
        }),
    [query, provider, category, sort],
  );

  async function saveFavorite(id: string) {
    setPendingFavorites((previous) => [...previous, id]);
    try {
      await toggleFavorite(id);
    } catch {
      // The store reports request failures through its toast.
    } finally {
      setPendingFavorites((previous) => previous.filter((item) => item !== id));
    }
  }

  return (
    <>
      <PageHeading
        eyebrow="MODEL CATALOG"
        title="Choose the right intelligence"
        description="Bandingkan harga input dan output per 1M token, context window, dan multiplier kredit."
        action={
          !state.authenticated && (
            <Link
              className="db-btn db-btn-ghost"
              href="/login?next=/dashboard/models"
            >
              Login untuk simpan favorit <DIcon name="arrow" />
            </Link>
          )
        }
      />
      <div className="db-notice model-pricing-notice">
        <DIcon name="bolt" />
        <span>
          <strong>Gateway inference belum dikonfigurasi.</strong> Harga AIVON
          dalam USD belum ditetapkan. Multiplier hanya diterapkan sekali pada
          total token input + output untuk menghitung kredit, bukan pengali
          harga USD.
        </span>
      </div>
      <div className="db-toolbar">
        <label className="db-model-search">
          <DIcon name="search" />
          <input
            className="db-input"
            aria-label="Search models"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search models or IDs"
          />
        </label>
        <select
          className="db-select"
          value={provider}
          onChange={(event) => setProvider(event.target.value)}
          aria-label="Filter by provider"
        >
          <option>All providers</option>
          {providers.map((item) => (
            <option key={item}>{item}</option>
          ))}
        </select>
        <select
          className="db-select"
          value={category}
          onChange={(event) => setCategory(event.target.value)}
          aria-label="Filter by category"
        >
          <option>All categories</option>
          {categories.map((item) => (
            <option key={item}>{item}</option>
          ))}
        </select>
        <select
          className="db-select"
          aria-label="Sort models"
          value={sort}
          onChange={(event) => setSort(event.target.value as Sort)}
        >
          <option value="name">Name: A–Z</option>
          <option value="input">Lowest input price</option>
          <option value="output">Lowest output price</option>
          <option value="multiplier">Lowest multiplier</option>
          <option value="context">Largest context</option>
        </select>
      </div>
      {models.length === 0 ? (
        <EmptyState
          title="No models found"
          description="Try a different search or clear one of the catalog filters."
        >
          <button
            className="db-btn db-btn-ghost"
            onClick={() => {
              setQuery("");
              setProvider("All providers");
              setCategory("All categories");
            }}
          >
            Clear filters
          </button>
        </EmptyState>
      ) : (
        <div className="db-grid-3">
          {models.map((model) => {
            const favorite = state.favorites.includes(model.id);
            return (
              <article className="db-card model-card" key={model.id}>
                <div className="db-card-header">
                  <div className="model-provider">
                    <ProviderIcon provider={model.provider} />
                    <span>{model.provider}</span>
                  </div>
                  {state.authenticated ? (
                    <button
                      className={`db-icon-button ${favorite ? "is-favorite" : ""}`}
                      type="button"
                      aria-label={`${favorite ? "Remove" : "Add"} ${model.name} ${favorite ? "from" : "to"} favorites`}
                      aria-pressed={favorite}
                      disabled={pendingFavorites.includes(model.id)}
                      onClick={() => void saveFavorite(model.id)}
                    >
                      <DIcon name="star" />
                    </button>
                  ) : (
                    <Link
                      className="db-icon-button"
                      href="/login?next=/dashboard/models"
                      aria-label={`Login untuk menyimpan ${model.name} ke favorit`}
                    >
                      <DIcon name="star" />
                    </Link>
                  )}
                </div>
                <h2>{model.name}</h2>
                <p className="db-muted">{model.description}</p>
                <div className="model-metrics">
                  <span>
                    <small>Context</small>
                    <b>{model.context}</b>
                  </span>
                  <span>
                    <small>Credit multiplier</small>
                    <b>×{model.multiplier}</b>
                  </span>
                </div>
                <dl className="model-prices">
                  <div>
                    <dt>
                      <span>Input</span> <small>USD / 1M tokens</small>
                    </dt>
                    <dd>{formatPrice(model.inputPricePerMillion)}</dd>
                  </div>
                  <div>
                    <dt>
                      <span>Output</span> <small>USD / 1M tokens</small>
                    </dt>
                    <dd>{formatPrice(model.outputPricePerMillion)}</dd>
                  </div>
                </dl>
                <code className="model-id">{model.id}</code>
                <div className="model-actions">
                  <button
                    className="db-btn db-btn-ghost"
                    type="button"
                    onClick={() => copy(model.id, "Model ID copied")}
                  >
                    <DIcon name="copy" /> Copy ID
                  </button>
                  <button
                    className="db-btn db-btn-primary"
                    type="button"
                    onClick={() => setSelected(model)}
                  >
                    Details <DIcon name="arrow" />
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      )}
      {selected && (
        <ModelDetails model={selected} onClose={() => setSelected(null)} />
      )}
    </>
  );
}

function ModelDetails({
  model,
  onClose,
}: {
  model: DashboardModel;
  onClose: () => void;
}) {
  const { copy } = useDashboard();
  const [input, setInput] = useState(0);
  const [output, setOutput] = useState(0);
  const normalize = (value: string, set: (value: number) => void) =>
    set(
      Math.min(
        maxTokens,
        Math.max(
          0,
          Number.isFinite(Number(value)) ? Math.floor(Number(value)) : 0,
        ),
      ),
    );
  const total = input + output;
  const cost = calculateModelCost(model, input, output);
  const credits = calculateCredits(model, input, output);
  return (
    <Modal
      title={model.name}
      description={`${model.provider} · ${model.category}`}
      onClose={onClose}
    >
      <div className="db-dialog-body model-detail">
        <div className="db-notice model-detail-notice">
          <ProviderIcon provider={model.provider} />
          <span>{model.detail}</span>
        </div>
        <dl className="model-detail-list">
          <div>
            <dt>Model ID</dt>
            <dd>
              <code>{model.id}</code>
              <button
                className="db-icon-button"
                type="button"
                aria-label="Copy model ID"
                onClick={() => copy(model.id, "Model ID copied")}
              >
                <DIcon name="copy" />
              </button>
            </dd>
          </div>
          <div>
            <dt>Context window</dt>
            <dd>{model.context}</dd>
          </div>
          <div>
            <dt>Input · USD / 1M tokens</dt>
            <dd>{formatPrice(model.inputPricePerMillion)}</dd>
          </div>
          <div>
            <dt>Output · USD / 1M tokens</dt>
            <dd>{formatPrice(model.outputPricePerMillion)}</dd>
          </div>
          <div>
            <dt>Credit multiplier</dt>
            <dd>×{model.multiplier}</dd>
          </div>
          <div>
            <dt>Good for</dt>
            <dd>{model.category}, product workflows, and prototyping</dd>
          </div>
        </dl>
        <section
          className="credit-calculator"
          aria-labelledby="calculator-title"
        >
          <div>
            <span className="db-eyebrow">COST & CREDIT CALCULATOR</span>
            <h3 id="calculator-title">Hitung token input & output</h3>
          </div>
          <div className="db-form-grid">
            <label className="db-field">
              Input tokens
              <input
                className="db-input"
                type="number"
                min="0"
                max={maxTokens}
                step="1"
                aria-describedby="calculator-limits"
                value={input}
                onChange={(event) => normalize(event.target.value, setInput)}
              />
            </label>
            <label className="db-field">
              Output tokens
              <input
                className="db-input"
                type="number"
                min="0"
                max={maxTokens}
                step="1"
                aria-describedby="calculator-limits"
                value={output}
                onChange={(event) => normalize(event.target.value, setOutput)}
              />
            </label>
          </div>
          <p className="calculator-hint" id="calculator-limits">
            Maksimum 1 miliar token per kolom. Nilai dibulatkan ke bawah dan
            dibatasi ke rentang 0–1 miliar.
          </p>
          <dl
            className="calculator-totals"
            aria-live="polite"
            aria-atomic="true"
          >
            <div>
              <dt>Estimasi biaya USD</dt>
              <dd>{formatPrice(cost)}</dd>
            </div>
            <div>
              <dt>Estimasi kredit</dt>
              <dd>{formatNumber(credits)} credits</dd>
            </div>
          </dl>
          <p className="calculator-result">
            {formatNumber(total)} token × {model.multiplier}, dibulatkan ke atas
            menjadi kredit. Biaya USD dihitung dari tarif input dan output
            masing-masing per 1M token, tanpa multiplier kredit.
          </p>
        </section>
      </div>
      <div className="db-dialog-footer">
        <button className="db-btn db-btn-ghost" type="button" onClick={onClose}>
          Close
        </button>
        <button
          className="db-btn db-btn-primary"
          type="button"
          onClick={() => copy(model.id, "Model ID copied")}
        >
          Copy model ID <DIcon name="copy" />
        </button>
      </div>
    </Modal>
  );
}
