"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import {
  emptyWorkspace,
  type WorkspaceState,
  type Profile,
} from "@/lib/dashboard-data";

type Context = {
  state: WorkspaceState;
  ready: boolean;
  error: string;
  refresh: () => Promise<void>;
  toast: (message: string) => void;
  copy: (text: string, message?: string) => Promise<void>;
  createKey: (
    name: string,
    limit: number,
    expiryDays: number,
  ) => Promise<string>;
  revokeKey: (id: string) => Promise<void>;
  saveProfile: (profile: Profile) => Promise<void>;
  markRead: (id?: string) => Promise<void>;
  toggleFavorite: (id: string) => Promise<void>;
  logout: () => Promise<void>;
};
const DashboardContext = createContext<Context | null>(null);

async function request(path: string, body?: object) {
  const response = await fetch(path, {
    method: body ? "POST" : "GET",
    credentials: "same-origin",
    cache: "no-store",
    ...(body
      ? {
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        }
      : {}),
  });
  const result = await response.json();
  if (!response.ok)
    throw new Error(result.error || "Permintaan gagal. Coba lagi.");
  return result as { state: WorkspaceState; token?: string };
}

export function DashboardProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<WorkspaceState>(emptyWorkspace);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const revision = useRef(0);
  const refresh = useCallback(async () => {
    const current = ++revision.current;
    try {
      const result = await request("/api/workspace");
      if (current !== revision.current) return;
      setState(result.state);
      setError("");
    } catch {
      if (current === revision.current)
        setError(
          "Workspace tidak dapat dimuat. Periksa koneksi lalu coba lagi.",
        );
    } finally {
      if (current === revision.current) setReady(true);
    }
  }, []);
  useEffect(() => {
    void refresh();
    const onFocus = () => {
      void refresh();
    };
    window.addEventListener("focus", onFocus);
    return () => {
      window.removeEventListener("focus", onFocus);
      revision.current++;
    };
  }, [refresh]);
  useEffect(
    () => () => {
      if (timer.current) clearTimeout(timer.current);
    },
    [],
  );

  function toast(text: string) {
    setMessage(text);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setMessage(""), 4000);
  }
  async function copy(text: string, success = "Copied to clipboard") {
    try {
      await navigator.clipboard.writeText(text);
      toast(success);
    } catch {
      toast(
        "Clipboard unavailable. Select and copy the visible text manually.",
      );
    }
  }
  async function mutate(body: object) {
    // Older background reads cannot overwrite a completed account mutation.
    ++revision.current;
    const result = await request("/api/workspace", body);
    ++revision.current;
    setState(result.state);
    setError("");
    return result;
  }
  async function createKey(name: string, limit: number, expiryDays: number) {
    const result = await mutate({
      action: "createKey",
      name,
      limit,
      expiryDays,
    });
    if (!result.token)
      throw new Error(
        "Token tidak diterima. Muat ulang daftar key sebelum mencoba lagi.",
      );
    toast("Key created. Copy it before closing.");
    return result.token;
  }
  async function revokeKey(id: string) {
    await mutate({ action: "revokeKey", id });
    toast("API key revoked");
  }
  async function saveProfile(profile: Profile) {
    await mutate({ action: "profile", profile });
    toast("Profile saved");
  }
  async function markRead(id?: string) {
    try {
      await mutate({ action: "markRead", id });
    } catch (cause) {
      toast(
        cause instanceof Error
          ? cause.message
          : "Notifications could not be updated.",
      );
    }
  }
  async function toggleFavorite(id: string) {
    try {
      await mutate({ action: "favorite", id });
    } catch (cause) {
      toast(
        cause instanceof Error ? cause.message : "Favorite could not be saved.",
      );
    }
  }
  async function logout() {
    await request("/api/auth/logout", {});
    ++revision.current;
    setState(emptyWorkspace());
    setError("");
    toast("Signed out");
  }
  return (
    <DashboardContext.Provider
      value={{
        state,
        ready,
        error,
        refresh,
        toast,
        copy,
        createKey,
        revokeKey,
        saveProfile,
        markRead,
        toggleFavorite,
        logout,
      }}
    >
      {children}
      <div
        className={`db-toast ${message ? "db-toast-visible" : ""}`}
        role="status"
      >
        {message}
      </div>
    </DashboardContext.Provider>
  );
}
export function useDashboard() {
  const value = useContext(DashboardContext);
  if (!value) throw new Error("DashboardProvider is required");
  return value;
}
