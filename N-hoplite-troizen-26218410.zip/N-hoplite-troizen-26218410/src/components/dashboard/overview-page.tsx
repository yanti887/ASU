"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { Mark, ProviderIcon } from "../icons";
import { useDashboard } from "./store";
import { DIcon, EmptyState, PageHeading } from "./ui";
import { UsageChart } from "./usage-chart";
import {
  dashboardModels,
  formatDate,
  formatNumber,
  formatTokens,
  modelById,
  usageSummary,
} from "@/lib/dashboard-data";

export function OverviewPage() {
  const { state } = useDashboard();
  const [days, setDays] = useState<7 | 30>(7);
  const [metric, setMetric] = useState<"tokens" | "requests">("tokens");
  const rows = useMemo(() => {
    const since = Date.now() - days * 86400000;
    return state.usage.filter(
      (record) => Date.parse(record.timestamp) >= since,
    );
  }, [days, state.usage]);
  const summary = usageSummary(rows);
  const recent = [...state.usage]
    .sort((a, b) => b.timestamp.localeCompare(a.timestamp))
    .slice(0, 3);
  const hasUsage = rows.length > 0;
  const hasAccount = state.authenticated;

  return (
    <>
      <PageHeading
        eyebrow="A CLEARER VIEW OF WHAT'S NEXT"
        title={
          hasAccount
            ? `Good to see you, ${state.profile.name.split(" ").at(-1)}.`
            : "Your workspace starts here."
        }
        description={
          hasAccount
            ? "Your account, API keys, and model choices in one place."
            : "Explore the model catalog, then create an account when you are ready to save your workspace."
        }
        action={
          <div className="db-segmented" aria-label="Overview period">
            {([7, 30] as const).map((value) => (
              <button
                key={value}
                className={days === value ? "active" : ""}
                aria-pressed={days === value}
                onClick={() => setDays(value)}
              >
                Last {value} days
              </button>
            ))}
          </div>
        }
      />
      <section className="db-welcome-banner">
        <div>
          <span className="db-welcome-label">
            <i /> LESS FRICTION. MORE BUILDING.
          </span>
          <h2>Ready for your next big idea?</h2>
          <p>
            {hasAccount
              ? "Manage the foundation of your workspace, then connect a gateway when it is configured."
              : "Start with the catalog. Register to keep profile and model preferences in your own workspace."}
          </p>
          <Link
            className="db-btn db-btn-primary"
            href={
              hasAccount ? "/dashboard/api-keys" : "/register?next=%2Fdashboard"
            }
          >
            {hasAccount ? "Manage API keys" : "Buat akun"}{" "}
            <DIcon name="arrow" />
          </Link>
          <Link className="db-welcome-docs" href="/dashboard/models">
            Explore models <DIcon name="arrow" />
          </Link>
        </div>
        <div className="db-welcome-art" aria-hidden="true">
          <div className="db-orbit orbit-one" />
          <div className="db-orbit orbit-two" />
          <div className="db-orbit orbit-three" />
          <div className="db-art-core">
            <Mark />
          </div>
          <span className="db-orbit-point point-one" />
          <span className="db-orbit-point point-two" />
          <span className="db-orbit-point point-three" />
          <span className="db-art-caption">
            ONE CONNECTION → ∞ POSSIBILITIES
          </span>
        </div>
      </section>
      <div className="db-stat-grid">
        <div className="db-stat-card">
          <div>
            <span>API keys</span>
            <DIcon name="key" />
          </div>
          <strong>
            {formatNumber(
              state.keys.filter((key) => key.status === "active").length,
            )}
          </strong>
          <div className="db-stat-foot">
            <span>
              {hasAccount ? "Active keys" : "Sign in to create a key"}
            </span>
            <Link
              href={
                hasAccount
                  ? "/dashboard/api-keys"
                  : "/login?next=%2Fdashboard%2Fapi-keys"
              }
            >
              {hasAccount ? "Manage" : "Sign in"} <DIcon name="arrow" />
            </Link>
          </div>
        </div>
        <div className="db-stat-card">
          <div>
            <span>Total requests</span>
            <DIcon name="globe" />
          </div>
          <strong data-testid="total-requests">
            {formatNumber(summary.requests)}
          </strong>
          <div className="db-stat-foot">
            <span>Recorded requests in the selected period</span>
          </div>
        </div>
        <div className="db-stat-card">
          <div>
            <span>Billable tokens</span>
            <DIcon name="usage" />
          </div>
          <strong>{formatTokens(summary.tokens)}</strong>
          <div className="db-stat-foot">
            <span>
              {formatTokens(summary.input)} input ·{" "}
              {formatTokens(summary.output)} output
            </span>
          </div>
          <span className="db-stat-caption">After model multiplier</span>
        </div>
        <div className="db-stat-card">
          <div>
            <span>Success rate</span>
            <DIcon name="shield" />
          </div>
          <strong>
            {summary.success.toFixed(1)}
            <small>%</small>
          </strong>
          <div className="db-stat-foot">
            <span>
              {summary.latency
                ? `${summary.latency} ms avg. latency`
                : "No requests recorded"}
            </span>
          </div>
        </div>
      </div>
      <div className="db-overview-charts">
        <section className="db-card db-usage-chart-card">
          <div className="db-card-header">
            <div>
              <h2>Usage over time</h2>
              <p>
                Actual request data appears here after a gateway is connected.
              </p>
            </div>
            <div className="db-segmented db-segmented-small">
              <button
                className={metric === "tokens" ? "active" : ""}
                onClick={() => setMetric("tokens")}
              >
                Tokens
              </button>
              <button
                className={metric === "requests" ? "active" : ""}
                onClick={() => setMetric("requests")}
              >
                Requests
              </button>
            </div>
          </div>
          {hasUsage ? (
            <>
              <div className="db-chart-total">
                <strong>
                  {metric === "tokens"
                    ? formatTokens(summary.tokens)
                    : formatNumber(summary.requests)}
                </strong>
                <span>
                  {metric === "tokens" ? "billable tokens" : "requests"} in the
                  last {days} days
                </span>
              </div>
              <UsageChart days={days} records={rows} metric={metric} />
            </>
          ) : (
            <EmptyState
              title="No usage yet"
              description="There are no recorded model requests for this period."
            >
              <Link className="db-btn db-btn-ghost" href="/dashboard/docs">
                Read integration notes <DIcon name="arrow" />
              </Link>
            </EmptyState>
          )}
        </section>
        <section className="db-card db-top-models">
          <div className="db-card-header">
            <div>
              <h2>Top models</h2>
              <p>Ranked from actual token usage.</p>
            </div>
            <Link
              href="/dashboard/models"
              className="db-icon-link"
              aria-label="Explore all models"
            >
              <DIcon name="arrow" />
            </Link>
          </div>
          {hasUsage ? (
            dashboardModels
              .map((model) => ({
                ...model,
                tokens: usageSummary(
                  rows.filter((record) => record.modelId === model.id),
                ).tokens,
              }))
              .filter((model) => model.tokens > 0)
              .sort((a, b) => b.tokens - a.tokens)
              .slice(0, 4)
              .map((model) => (
                <div className="db-top-model-row" key={model.id}>
                  <div className="db-top-model-identity">
                    <span
                      className="db-provider-symbol"
                      style={{ color: model.color }}
                    >
                      <ProviderIcon provider={model.provider} />
                    </span>
                    <div>
                      <strong>{model.name}</strong>
                      <small>{model.provider}</small>
                    </div>
                    <span>{formatTokens(model.tokens)}</span>
                  </div>
                </div>
              ))
          ) : (
            <EmptyState
              title="No model rankings yet"
              description="Model activity will appear here after requests are recorded."
            />
          )}
          <Link className="db-top-model-link" href="/dashboard/models">
            Find your next model <DIcon name="arrow" />
          </Link>
        </section>
      </div>
      <div className="db-grid-2 db-overview-bottom">
        <section className="db-card">
          <div className="db-card-header">
            <div>
              <h2>Recent activity</h2>
              <p>The latest from your workspace.</p>
            </div>
            <Link
              href="/dashboard/usage"
              className="db-icon-link"
              aria-label="View all usage"
            >
              <DIcon name="arrow" />
            </Link>
          </div>
          {recent.length ? (
            recent.map((record) => {
              const model = modelById(record.modelId);
              return (
                <div className="db-activity" key={record.id}>
                  <span
                    className={`db-activity-icon ${record.status === "error" ? "error" : ""}`}
                  >
                    <DIcon
                      name={record.status === "error" ? "close" : "check"}
                    />
                  </span>
                  <div>
                    <strong>
                      {record.status === "error"
                        ? "Request failed"
                        : "Request completed"}
                    </strong>
                    <small>
                      {model.name} · {formatTokens(record.billed)} tokens
                    </small>
                  </div>
                  <time>{formatDate(record.timestamp, true)}</time>
                </div>
              );
            })
          ) : (
            <EmptyState
              title="No recent activity"
              description="Requests will appear here once the gateway records activity."
            />
          )}
        </section>
        <section className="db-card db-quickstart-card">
          <span className="db-quickstart-icon">
            <DIcon name="docs" />
          </span>
          <h2>Prepare the next connection.</h2>
          <p>
            Review the setup notes for account, key handling, and a future
            OpenAI-compatible gateway connection.
          </p>
          <Link href="/dashboard/docs" className="db-btn">
            Open the documentation <DIcon name="arrow" />
          </Link>
          <span className="db-quickstart-code" aria-hidden="true">
            model: “your-next-big-idea”
          </span>
        </section>
      </div>
    </>
  );
}
