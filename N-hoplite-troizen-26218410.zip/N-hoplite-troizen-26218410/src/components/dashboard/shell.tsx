"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { Mark, ProviderIcon } from "../icons";
import ThemeToggle from "../theme-toggle";
import { dashboardModels } from "@/lib/dashboard-data";
import { DIcon, Modal, type IconName } from "./ui";
import { useDashboard } from "./store";
import { useMotionPreference } from "@/lib/use-motion-preference";

export const dashboardNavigation: {
  label: string;
  href: string;
  icon: IconName;
  group: string;
}[] = [
  {
    label: "Overview",
    href: "/dashboard",
    icon: "overview",
    group: "WORKSPACE",
  },
  {
    label: "Usage",
    href: "/dashboard/usage",
    icon: "usage",
    group: "WORKSPACE",
  },
  {
    label: "API keys",
    href: "/dashboard/api-keys",
    icon: "key",
    group: "WORKSPACE",
  },
  {
    label: "Models & pricing",
    href: "/dashboard/models",
    icon: "models",
    group: "WORKSPACE",
  },
  {
    label: "Billing & plans",
    href: "/dashboard/billing",
    icon: "billing",
    group: "MANAGE",
  },
  {
    label: "Documentation",
    href: "/dashboard/docs",
    icon: "docs",
    group: "MANAGE",
  },
  {
    label: "Profile & settings",
    href: "/dashboard/profile",
    icon: "profile",
    group: "MANAGE",
  },
];

export default function DashboardShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const { state, ready, error, refresh, markRead } = useDashboard();
  const [menu, setMenu] = useState(false),
    [notifications, setNotifications] = useState(false),
    [profile, setProfile] = useState(false),
    [search, setSearch] = useState(false),
    [query, setQuery] = useState("");
  const { paused, reduced, setPaused } = useMotionPreference();
  const [narrow, setNarrow] = useState(false);
  const popovers = useRef<HTMLDivElement>(null);
  const current =
    dashboardNavigation.find((item) => item.href === pathname) ??
    dashboardNavigation[0];
  const visibleNotifications = state.notifications;
  const unread = visibleNotifications.filter((note) => !note.read).length;
  const initials = state.authenticated
    ? state.profile.name
        .split(/\s+/)
        .map((word) => word[0])
        .slice(0, 2)
        .join("")
        .toUpperCase()
    : "—";
  useEffect(() => {
    setMenu(false);
    setNotifications(false);
    setProfile(false);
    setSearch(false);
  }, [pathname]);
  useEffect(() => {
    const media = matchMedia("(max-width: 760px)");
    const sync = () => {
      setNarrow(media.matches);
      if (!media.matches) setMenu(false);
    };
    sync();
    media.addEventListener("change", sync);
    return () => media.removeEventListener("change", sync);
  }, []);
  useEffect(() => {
    if (!ready) return;
    const observer = new IntersectionObserver((entries) =>
      entries.forEach((entry) => {
        (entry.target as HTMLElement).dataset.motionVisible = String(
          entry.isIntersecting,
        );
      }),
    );
    document
      .querySelectorAll(".db-welcome-art, .db-chart")
      .forEach((element) => observer.observe(element));
    return () => observer.disconnect();
  }, [pathname, ready]);
  useEffect(() => {
    if (!menu || !narrow) return;
    const previous = document.activeElement as HTMLElement | null;
    const sidebar = document.getElementById("dashboard-navigation");
    const links = sidebar?.querySelectorAll<HTMLElement>(
      "a[href], button:not(:disabled)",
    );
    links?.[0]?.focus();
    function trap(event: KeyboardEvent) {
      if (event.key !== "Tab" || !links?.length) return;
      const first = links[0],
        last = links[links.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }
    document.addEventListener("keydown", trap);
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", trap);
      document.body.style.overflow = overflow;
      previous?.focus();
    };
  }, [menu, narrow]);
  useEffect(() => {
    function key(event: KeyboardEvent) {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setQuery("");
        setSearch((value) => !value);
      }
      if (event.key === "Escape") {
        setMenu(false);
        setNotifications(false);
        setProfile(false);
      }
    }
    function outside(event: PointerEvent) {
      if (
        event.target instanceof Node &&
        !popovers.current?.contains(event.target)
      ) {
        setNotifications(false);
        setProfile(false);
      }
    }
    document.addEventListener("keydown", key);
    document.addEventListener("pointerdown", outside);
    return () => {
      document.removeEventListener("keydown", key);
      document.removeEventListener("pointerdown", outside);
    };
  }, []);
  function closeSearch() {
    setSearch(false);
    setQuery("");
  }
  const searchLinks = dashboardNavigation.filter((item) =>
    item.label.toLowerCase().includes(query.toLowerCase()),
  );
  const searchModels = query.trim()
    ? dashboardModels.filter((model) =>
        `${model.name} ${model.provider}`
          .toLowerCase()
          .includes(query.toLowerCase()),
      )
    : [];
  return (
    <div className={`dashboard ${paused || reduced ? "db-paused" : ""}`}>
      <a href="#dashboard-main" className="skip-link">
        Lewati ke dashboard
      </a>
      {menu && (
        <button
          className="db-sidebar-backdrop"
          aria-label="Close navigation"
          onClick={() => setMenu(false)}
        />
      )}
      <aside
        id="dashboard-navigation"
        className={`db-sidebar ${menu ? "db-sidebar-open" : ""}`}
        aria-label="Dashboard navigation"
        inert={narrow && !menu}
      >
        <button
          className="db-icon-button db-sidebar-close"
          aria-label="Close sidebar"
          onClick={() => setMenu(false)}
        >
          <DIcon name="close" />
        </button>
        <Link href="/" className="db-brand" aria-label="AIVON home">
          <Mark />
          <span>aivon</span>
          <sup>®</sup>
        </Link>
        <div className="db-workspace">
          <span className="db-workspace-avatar">{initials}</span>
          <div>
            <strong>
              {state.authenticated
                ? state.profile.workspace
                : "Guest workspace"}
            </strong>
            <small>
              {state.authenticated
                ? "Personal workspace"
                : "Create an account to save changes"}
            </small>
          </div>
          <DIcon name="chevron" />
        </div>
        <nav>
          {["WORKSPACE", "MANAGE"].map((group) => (
            <div className="db-nav-group" key={group}>
              <span>{group}</span>
              {dashboardNavigation
                .filter((item) => item.group === group)
                .map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={pathname === item.href ? "active" : ""}
                    aria-current={pathname === item.href ? "page" : undefined}
                    onClick={() => setMenu(false)}
                  >
                    <DIcon name={item.icon} />
                    {item.label}
                    {item.label === "API keys" && (
                      <small>
                        {
                          state.keys.filter((key) => key.status === "active")
                            .length
                        }
                      </small>
                    )}
                  </Link>
                ))}
            </div>
          ))}
        </nav>
        <div className="db-sidebar-bottom">
          <div className="db-balance-mini">
            <div>
              <span>WORKSPACE ACCESS</span>
              <DIcon name="profile" />
            </div>
            <strong>{state.authenticated ? "Signed in" : "Guest"}</strong>
            <span>
              {state.authenticated
                ? `${state.keys.filter((key) => key.status === "active").length} active API keys`
                : "Sign in to save your workspace"}
            </span>
            <Link
              href={
                state.authenticated
                  ? "/dashboard/profile"
                  : "/register?next=%2Fdashboard"
              }
            >
              {state.authenticated ? "Open profile" : "Create account"}{" "}
              <DIcon name="arrow" />
            </Link>
          </div>
          <Link href="/" className="db-back-site">
            <DIcon name="globe" /> Back to website <DIcon name="arrow" />
          </Link>
          <button
            className="db-motion-button"
            onClick={() => setPaused(!paused)}
            disabled={reduced}
            aria-pressed={paused || reduced}
          >
            <i />
            {reduced
              ? "Reduced motion"
              : paused
                ? "Animations paused"
                : "Animations on"}
            <span>{paused || reduced ? "▷" : "Ⅱ"}</span>
          </button>
          <span className="db-sidebar-foot">
            INDEPENDENT MINDS. ONE GATEWAY.
          </span>
        </div>
      </aside>
      <div className="db-main-wrap" inert={narrow && menu}>
        <header className="db-topbar">
          <div className="db-breadcrumb">
            <button
              className="db-icon-button db-menu-toggle"
              onClick={() => setMenu(!menu)}
              aria-label="Open navigation"
              aria-expanded={menu}
              aria-controls="dashboard-navigation"
            >
              <DIcon name="menu" />
            </button>
            <span>Workspace</span>
            <span>/</span>
            <strong>{current.label}</strong>
          </div>
          <div className="db-topbar-actions" ref={popovers}>
            <button
              className="db-search-trigger"
              onClick={() => {
                setQuery("");
                setSearch(true);
              }}
            >
              <DIcon name="search" />
              <span>Search anything...</span>
              <kbd>⌘ K</kbd>
            </button>
            <ThemeToggle />
            <div className="db-popover-anchor">
              <button
                className={`db-icon-button db-notifications-button ${notifications ? "active" : ""}`}
                aria-label={`Notifications${unread ? `, ${unread} unread` : ""}`}
                aria-expanded={notifications}
                onClick={() => {
                  setNotifications(!notifications);
                  setProfile(false);
                }}
              >
                <DIcon name="bell" />
                {unread > 0 && <i />}
              </button>
              {notifications && (
                <div className="db-popover db-notification-panel">
                  <div className="db-popover-heading">
                    <strong>
                      Notifications <span>{unread}</span>
                    </strong>
                    <button onClick={() => markRead()}>Mark all read</button>
                  </div>
                  {visibleNotifications.length ? (
                    visibleNotifications.map((note) => (
                      <Link
                        href={note.href}
                        key={note.id}
                        className={`db-notification ${note.read ? "read" : ""}`}
                        onClick={() => {
                          markRead(note.id);
                          setNotifications(false);
                        }}
                      >
                        <span className="db-notification-icon">
                          <DIcon name="bolt" />
                        </span>
                        <div>
                          <strong>{note.title}</strong>
                          <p>{note.body}</p>
                          <small>Workspace notification</small>
                        </div>
                        {!note.read && <i />}
                      </Link>
                    ))
                  ) : (
                    <p className="db-muted">You’re all caught up.</p>
                  )}
                  <p className="db-popover-foot">You are all caught up.</p>
                </div>
              )}
            </div>
            <div className="db-topbar-divider" />
            <div className="db-popover-anchor">
              <button
                className="db-profile-trigger"
                aria-label="Open profile menu"
                aria-expanded={profile}
                onClick={() => {
                  setProfile(!profile);
                  setNotifications(false);
                }}
              >
                <span className="db-avatar">
                  {state.authenticated ? initials || "A" : "G"}
                </span>
                <span className="db-profile-name">
                  <strong>
                    {state.authenticated ? state.profile.name : "Guest"}
                  </strong>
                  <small>
                    {state.authenticated
                      ? "Personal account"
                      : "Browse the catalog"}
                  </small>
                </span>
                <DIcon name="chevron" />
              </button>
              {profile && (
                <div className="db-popover db-profile-panel">
                  <strong>
                    {state.authenticated
                      ? state.profile.name
                      : "Guest workspace"}
                  </strong>
                  <span>
                    {state.authenticated
                      ? state.profile.email
                      : "Create an account to save your preferences."}
                  </span>
                  {state.authenticated ? (
                    <>
                      <Link
                        href="/dashboard/profile"
                        onClick={() => setProfile(false)}
                      >
                        <DIcon name="profile" />
                        Profile & settings
                      </Link>
                      <Link
                        href="/dashboard/billing"
                        onClick={() => setProfile(false)}
                      >
                        <DIcon name="billing" />
                        Billing status
                      </Link>
                    </>
                  ) : (
                    <>
                      <Link
                        href="/register?next=%2Fdashboard"
                        onClick={() => setProfile(false)}
                      >
                        <DIcon name="profile" />
                        Buat akun
                      </Link>
                      <Link
                        href="/login?next=%2Fdashboard"
                        onClick={() => setProfile(false)}
                      >
                        <DIcon name="key" />
                        Masuk
                      </Link>
                    </>
                  )}
                  <Link href="/">
                    <DIcon name="logout" />
                    Back to website
                  </Link>
                </div>
              )}
            </div>
          </div>
        </header>
        <main id="dashboard-main" className="db-main" tabIndex={-1}>
          {error && (
            <div className="db-notice amber" role="status">
              <DIcon name="close" />
              <span>{error}</span>
              <button
                className="db-btn db-btn-ghost"
                type="button"
                onClick={() => void refresh()}
              >
                Coba lagi
              </button>
            </div>
          )}
          {ready ? (
            <div className="db-page-enter" key={pathname}>
              {children}
            </div>
          ) : (
            <div className="db-loading" role="status">
              <div />
              <div />
              <div />
              <span>Preparing your workspace…</span>
            </div>
          )}
          <footer className="db-footer">
            <span>
              © 2026 AIVON <i /> Built for what’s next.
            </span>
            <span>
              <i className="db-status-dot" /> Account & catalog{" "}
              <Link href="/dashboard/docs">
                Documentation <DIcon name="arrow" />
              </Link>
            </span>
          </footer>
        </main>
      </div>
      {search && (
        <Modal
          title="Find your next step"
          description="Jump to a page or find a model. Ctrl / ⌘ K"
          onClose={closeSearch}
        >
          <div className="db-dialog-body">
            <label className="db-command-search">
              <DIcon name="search" />
              <input
                className="db-input"
                autoFocus
                placeholder="Search pages and models..."
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                aria-label="Search dashboard"
              />
            </label>
            <div className="db-command-results">
              {searchLinks.map((item) => (
                <Link key={item.href} href={item.href} onClick={closeSearch}>
                  <DIcon name={item.icon} />
                  <span>{item.label}</span>
                  <DIcon name="arrow" />
                </Link>
              ))}
              {searchModels.map((model) => (
                <Link
                  key={model.id}
                  href={`/dashboard/models?q=${encodeURIComponent(model.name)}`}
                  onClick={closeSearch}
                >
                  <ProviderIcon provider={model.provider} />
                  <span>
                    {model.name}
                    <small>{model.provider}</small>
                  </span>
                  <DIcon name="arrow" />
                </Link>
              ))}
              {!searchLinks.length && !searchModels.length && (
                <p className="db-muted">
                  No matches. Try “keys”, “billing”, or “Claude”.
                </p>
              )}
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
