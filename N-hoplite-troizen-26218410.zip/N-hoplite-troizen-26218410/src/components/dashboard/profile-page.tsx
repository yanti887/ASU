"use client";

import Link from "next/link";
import { useEffect, useRef, useState, type FormEvent } from "react";
import type { Profile } from "@/lib/dashboard-data";
import { Mark } from "@/components/icons";
import styles from "@/components/auth/profile-account.module.css";
import { useDashboard } from "./store";
import { DIcon, PageHeading } from "./ui";

const timezones = [
  "Asia/Jakarta",
  "Asia/Singapore",
  "Asia/Tokyo",
  "Europe/London",
  "America/Los_Angeles",
];

export default function ProfilePage() {
  const { state, ready, saveProfile, logout } = useDashboard();
  const [form, setForm] = useState<Profile>(state.profile);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [pending, setPending] = useState<"save" | "logout" | null>(null);
  const [requestError, setRequestError] = useState("");
  const [saved, setSaved] = useState(false);
  const busy = useRef(false);
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (ready) setForm(state.profile);
  }, [ready, state.profile]);

  function update<K extends keyof Profile>(key: K, value: Profile[K]) {
    setForm((previous) => ({ ...previous, [key]: value }));
    setErrors((previous) => ({ ...previous, [key]: "" }));
    setRequestError("");
    setSaved(false);
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy.current) return;
    const next: Record<string, string> = {};
    if (form.name.trim().length < 2 || form.name.trim().length > 64)
      next.name = "Gunakan 2–64 karakter.";
    if (form.workspace.trim().length < 2 || form.workspace.trim().length > 64)
      next.workspace = "Gunakan 2–64 karakter.";
    setErrors(next);
    setSaved(false);
    setRequestError("");
    const invalid = Object.keys(next)[0];
    if (invalid) {
      const input = formRef.current?.elements.namedItem(invalid);
      if (input instanceof HTMLElement) input.focus();
      return;
    }
    busy.current = true;
    setPending("save");
    try {
      await saveProfile({
        ...form,
        name: form.name.trim(),
        email: state.profile.email,
        workspace: form.workspace.trim(),
      });
      setSaved(true);
    } catch (error) {
      setRequestError(
        error instanceof Error
          ? error.message
          : "Profil belum tersimpan. Coba lagi.",
      );
    } finally {
      busy.current = false;
      setPending(null);
    }
  }

  async function signOut() {
    if (busy.current) return;
    busy.current = true;
    setPending("logout");
    setRequestError("");
    try {
      await logout();
      window.location.assign("/login");
    } catch (error) {
      setRequestError(
        error instanceof Error
          ? error.message
          : "Belum dapat keluar. Coba lagi.",
      );
      busy.current = false;
      setPending(null);
    }
  }

  if (!ready) {
    return (
      <>
        <PageHeading
          eyebrow="YOUR ACCOUNT"
          title="Profil akun"
          description="Satu tempat untuk profil dan workspace-mu."
        />
        <div
          className={`db-card ${styles.loading}`}
          role="status"
          aria-busy="true"
        >
          Memuat akunmu…
        </div>
      </>
    );
  }

  if (!state.authenticated) {
    return (
      <>
        <PageHeading
          eyebrow="YOUR NEXT CHAPTER"
          title="Ruang untuk ide berikutnya."
          description="Buat akun untuk menyimpan profil dan pilihan model di workspace-mu."
        />
        <section className={`db-card ${styles.guest}`}>
          <div className={styles.guestArt} aria-hidden="true">
            <span />
            <span />
            <span />
            <div>
              <Mark />
            </div>
          </div>
          <div className={styles.guestCopy}>
            <span className="db-eyebrow">LESS FRICTION. MORE BUILDING.</span>
            <h2>Mulai dengan akunmu sendiri.</h2>
            <p className="db-muted">
              Kamu sedang menjelajah sebagai tamu. Daftar atau masuk untuk
              mengelola profil dan menyimpan pilihan model ke akunmu.
            </p>
            <div className={styles.actions}>
              <Link
                className="db-btn db-btn-primary"
                href="/register?next=%2Fdashboard%2Fprofile"
              >
                Buat akun <DIcon name="arrow" />
              </Link>
              <Link
                className="db-btn db-btn-ghost"
                href="/login?next=%2Fdashboard%2Fprofile"
              >
                Masuk
              </Link>
            </div>
            <Link className={styles.catalogLink} href="/dashboard/models">
              Lihat katalog model <DIcon name="arrow" />
            </Link>
          </div>
        </section>
      </>
    );
  }

  const initials = state.profile.name
    .trim()
    .split(/\s+/)
    .map((part) => part[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
  return (
    <>
      <PageHeading
        eyebrow="YOUR ACCOUNT"
        title="Profil & workspace"
        description="Detail akunmu, tersimpan untuk sesi berikutnya."
      />
      <div className={`profile-hero db-card ${styles.hero}`}>
        <div className={`avatar ${styles.avatar}`} aria-hidden="true">
          {initials}
        </div>
        <div className={styles.identity}>
          <h2>{state.profile.name}</h2>
          <p className="db-muted">{state.profile.email}</p>
        </div>
        <span className="db-badge violet">Akun pribadi</span>
      </div>

      {requestError && (
        <p className={styles.error} role="alert">
          {requestError}
        </p>
      )}

      <form
        ref={formRef}
        className="db-card profile-form"
        onSubmit={submit}
        noValidate
        aria-busy={pending === "save"}
      >
        <div className="db-card-header">
          <div>
            <h2>Detail profil</h2>
            <p className="db-muted">
              Perubahan disimpan ke akunmu, bukan hanya di perangkat ini.
            </p>
          </div>
        </div>
        <fieldset
          className={`db-form-grid ${styles.fields}`}
          disabled={pending !== null}
        >
          <Field
            name="name"
            label="Nama tampilan"
            value={form.name}
            autoComplete="name"
            error={errors.name}
            onChange={(value) => update("name", value)}
          />
          <div className="db-field">
            <span id="profile-email-label">Email akun</span>
            <input
              id="profile-email"
              name="email"
              className={`db-input ${styles.readOnly}`}
              type="email"
              value={state.profile.email}
              autoComplete="email"
              readOnly
              aria-labelledby="profile-email-label"
              aria-describedby="profile-email-note"
            />
            <small id="profile-email-note" className={styles.fieldNote}>
              Email untuk masuk tidak dapat diubah di sini.
            </small>
          </div>
          <Field
            name="workspace"
            label="Nama workspace"
            value={form.workspace}
            autoComplete="organization"
            error={errors.workspace}
            onChange={(value) => update("workspace", value)}
          />
          <div className="db-field">
            <span id="profile-timezone-label">Zona waktu</span>
            <select
              id="profile-timezone"
              className="db-select"
              value={form.timezone}
              aria-labelledby="profile-timezone-label"
              onChange={(event) => update("timezone", event.target.value)}
            >
              {timezones.map((zone) => (
                <option key={zone}>{zone}</option>
              ))}
            </select>
          </div>
          <div className="db-field">
            <span id="profile-role-label">Peran</span>
            <select
              id="profile-role"
              className="db-select"
              value={form.role}
              aria-labelledby="profile-role-label"
              onChange={(event) => update("role", event.target.value)}
            >
              <option>Developer</option>
              <option>Designer</option>
              <option>Founder</option>
              <option>Viewer</option>
            </select>
            <small className={styles.fieldNote}>
              Deskripsi peranmu, bukan pengaturan izin akses.
            </small>
          </div>
        </fieldset>
        <div className={`db-dialog-footer ${styles.saveFooter}`}>
          <span role="status" className={styles.saved}>
            {saved
              ? "Profil berhasil disimpan."
              : pending === "save"
                ? "Menyimpan ke akunmu…"
                : ""}
          </span>
          <button
            type="submit"
            className="db-btn db-btn-primary"
            disabled={pending !== null}
          >
            {pending === "save" ? "Menyimpan…" : "Simpan profil"}{" "}
            <DIcon name="check" />
          </button>
        </div>
      </form>

      <section className={`db-card ${styles.session}`}>
        <div className={styles.sessionCopy}>
          <span className="db-eyebrow">AKUN & SESI</span>
          <h2>Selesai untuk sekarang?</h2>
          <p className="db-muted">
            Keluar mengakhiri sesi di browser ini. Profil dan pilihan model
            tetap tersimpan di akunmu.
          </p>
        </div>
        <button
          className="db-btn db-btn-ghost"
          type="button"
          onClick={signOut}
          disabled={pending !== null}
        >
          {pending === "logout" ? "Keluar…" : "Keluar dari akun"}{" "}
          <DIcon name="logout" />
        </button>
      </section>
    </>
  );
}

function Field({
  name,
  label,
  value,
  autoComplete,
  error,
  onChange,
}: {
  name: string;
  label: string;
  value: string;
  autoComplete: string;
  error?: string;
  onChange: (value: string) => void;
}) {
  const id = `profile-${name}`;
  return (
    <label className="db-field" htmlFor={id}>
      {label}
      <input
        id={id}
        name={name}
        className="db-input"
        type="text"
        minLength={2}
        maxLength={64}
        required
        autoComplete={autoComplete}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        aria-invalid={!!error}
        aria-describedby={error ? `${id}-error` : undefined}
      />
      {error && (
        <small id={`${id}-error`} className="field-error">
          {error}
        </small>
      )}
    </label>
  );
}
