"use client";

import { useId, useState } from "react";
import {
  dailyUsage,
  formatTokens,
  formatNumber,
  type UsageRecord,
} from "@/lib/dashboard-data";

export function UsageChart({
  days,
  records,
  metric = "tokens",
}: {
  days: number;
  records?: UsageRecord[];
  metric?: "tokens" | "requests";
}) {
  const gradient = useId().replaceAll(":", "");
  const [active, setActive] = useState<number | null>(null);
  const data = dailyUsage(days, records);
  const max = Math.max(...data.map((point) => point[metric]), 1) * 1.25;
  const x = (index: number) =>
    54 + (index / Math.max(data.length - 1, 1)) * 700;
  const y = (value: number) => 210 - (value / max) * 165;
  const points = data.map((point, index) => `${x(index)},${y(point[metric])}`);
  const curve = `M${points.join(" L")}`;
  const selected = active === null ? null : data[active];
  return (
    <div className="db-chart">
      <svg
        viewBox="0 0 800 252"
        role="img"
        aria-label={`${days}-day ${metric} chart from recorded usage data`}
      >
        <defs>
          <linearGradient id={gradient} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#9856f5" stopOpacity=".22" />
            <stop offset="100%" stopColor="#9856f5" stopOpacity="0" />
          </linearGradient>
        </defs>
        {[0, 1, 2, 3].map((index) => (
          <g key={index}>
            <line
              x1="54"
              x2="754"
              y1={45 + index * 55}
              y2={45 + index * 55}
              className="db-chart-grid"
            />
            <text
              x="40"
              y={49 + index * 55}
              textAnchor="end"
              className="db-chart-axis"
            >
              {metric === "tokens"
                ? formatTokens(Math.round((max * (3 - index)) / 3))
                : Math.round((max * (3 - index)) / 3)}
            </text>
          </g>
        ))}
        <path d={`${curve} L754,210 L54,210 Z`} fill={`url(#${gradient})`} />
        <path
          className="db-chart-line"
          d={curve}
          fill="none"
          stroke="#9356ec"
          strokeWidth="2.6"
          strokeLinejoin="round"
          strokeLinecap="round"
          pathLength="1"
        />
        {data.map((point, index) => (
          <g key={point.dayAgo}>
            {(days <= 7 || index % 5 === 0 || index === days - 1) && (
              <text
                className="db-chart-axis"
                x={x(index)}
                y="238"
                textAnchor="middle"
              >
                {point.label}
              </text>
            )}
            <circle
              className="db-chart-point"
              cx={x(index)}
              cy={y(point[metric])}
              r={active === index ? 5 : 3}
              fill="var(--db-surface)"
              stroke="#9356ec"
              strokeWidth="2"
            />
            <rect
              x={x(index) - 350 / days}
              y="35"
              width={700 / days}
              height="180"
              fill="transparent"
              tabIndex={0}
              role="button"
              aria-label={`${point.label}: ${point[metric]} ${metric}`}
              onMouseEnter={() => setActive(index)}
              onMouseLeave={() => setActive(null)}
              onFocus={() => setActive(index)}
              onBlur={() => setActive(null)}
              onClick={() => setActive(index)}
              onKeyDown={(event) => {
                if (event.key === "Enter" || event.key === " ") {
                  event.preventDefault();
                  setActive(index);
                }
              }}
            />
          </g>
        ))}
        {selected && active !== null && (
          <line
            x1={x(active)}
            x2={x(active)}
            y1="35"
            y2="210"
            stroke="#a781d9"
            strokeDasharray="4 4"
            pointerEvents="none"
          />
        )}
      </svg>
      {selected && active !== null && (
        <div
          className="db-chart-tooltip"
          style={{ left: `${Math.max(14, Math.min(83, x(active) / 8))}%` }}
        >
          <span>{selected.label}</span>
          <strong>
            {metric === "tokens"
              ? formatTokens(selected.tokens)
              : formatNumber(selected.requests)}{" "}
            {metric}
          </strong>
        </div>
      )}
    </div>
  );
}
