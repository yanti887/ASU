"use client";

import { useState } from "react";
import { dashboardModels } from "@/lib/dashboard-data";
import { useDashboard } from "./store";
import { DIcon, PageHeading } from "./ui";

type Language = "curl" | "JavaScript" | "Python";
const requestTemplate = `{
  "model": "MODEL_ID",
  "messages": [{ "role": "user", "content": "Write a friendly greeting." }]
}`;
function snippet(language: Language, modelId: string) {
  if (language === "curl")
    return `curl "$AIVON_BASE_URL/chat/completions" \\\n  -H "Authorization: Bearer $AIVON_API_KEY" \\\n  -H "Content-Type: application/json" \\\n  -d '${requestTemplate.replace("MODEL_ID", modelId)}'`;
  if (language === "Python")
    return `import os\nfrom openai import OpenAI\n\nclient = OpenAI(base_url=os.environ["AIVON_BASE_URL"], api_key=os.environ["AIVON_API_KEY"])\nresponse = client.chat.completions.create(\n    model="${modelId}",\n    messages=[{"role": "user", "content": "Write a friendly greeting."}],\n)`;
  return `import OpenAI from "openai";\n\nconst client = new OpenAI({\n  baseURL: process.env.AIVON_BASE_URL,\n  apiKey: process.env.AIVON_API_KEY,\n});\n\nconst response = await client.chat.completions.create({\n  model: "${modelId}",\n  messages: [{ role: "user", content: "Write a friendly greeting." }],\n});`;
}

export default function DocsPage() {
  const { copy } = useDashboard();
  const [language, setLanguage] = useState<Language>("curl");
  const [modelId, setModelId] = useState(dashboardModels[0].id);
  const [tab, setTab] = useState("Quickstart");
  const code = snippet(language, modelId);
  return (
    <>
      <PageHeading
        eyebrow="DEVELOPER DOCS"
        title="Build with your own keys"
        description="Kelola akun dan API key, pahami perhitungan token, lalu siapkan integrasi server."
        action={
          <a className="db-btn db-btn-ghost" href="/dashboard/api-keys">
            Manage API keys <DIcon name="arrow" />
          </a>
        }
      />
      <div className="db-notice docs-gateway-notice" id="gateway-status">
        <DIcon name="shield" />
        <span>
          <strong>Gateway inference belum dikonfigurasi.</strong> Registrasi
          akun dan pengelolaan API key tersedia, tetapi inference dan pembayaran
          belum terhubung. Contoh kode di bawah baru dapat dijalankan setelah
          endpoint gateway dikonfigurasi. Halaman ini tidak mengirim request
          model.
        </span>
      </div>
      <div className="docs-layout">
        <aside
          className="db-tabs docs-tabs"
          aria-label="Documentation sections"
        >
          {["Quickstart", "API reference", "Errors & limits"].map((item) => (
            <button
              key={item}
              type="button"
              className={tab === item ? "active" : ""}
              aria-pressed={tab === item}
              onClick={() => setTab(item)}
            >
              {item}
            </button>
          ))}
        </aside>
        <section className="docs-content">
          {tab === "Quickstart" && (
            <>
              <span className="db-eyebrow">QUICKSTART</span>
              <h2>Prepare your integration</h2>
              <div className="quickstart-steps">
                <div>
                  <b>01</b>
                  <h3>Buat akun & API key</h3>
                  <p>
                    <a href="/register">Daftar</a> atau{" "}
                    <a href="/login">login</a>, lalu buka{" "}
                    <a href="/dashboard/api-keys">API keys</a>. Simpan key baru
                    di server; jangan masukkan ke kode browser.
                  </p>
                </div>
                <div>
                  <b>02</b>
                  <h3>Siapkan environment server</h3>
                  <pre>
                    <code>{`AIVON_BASE_URL=https://your-gateway.example/v1\nAIVON_API_KEY=replace-with-your-server-key`}</code>
                  </pre>
                  <p>Base URL ini placeholder, bukan endpoint AIVON aktif.</p>
                </div>
                <div>
                  <b>03</b>
                  <h3>Periksa konfigurasi model</h3>
                  <p>
                    Temukan ID di <a href="/dashboard/models">Models</a>.
                    Jalankan request hanya setelah gateway dan dukungan model
                    tersebut dikonfirmasi.
                  </p>
                </div>
              </div>
            </>
          )}
          {tab === "API reference" && (
            <>
              <span className="db-eyebrow">API REFERENCE</span>
              <h2>Chat completions example</h2>
              <p className="db-muted">
                Format request untuk gateway yang mendukung chat completions.
                Ini bukan endpoint inference yang sudah aktif di AIVON.
              </p>
              <pre className="docs-snippet">
                <code>{requestTemplate.replace("MODEL_ID", modelId)}</code>
              </pre>
            </>
          )}
          {tab === "Errors & limits" && (
            <>
              <span className="db-eyebrow">ERRORS & LIMITS</span>
              <h2>Build for clear failures</h2>
              <p className="db-muted">
                Setelah gateway tersedia, tangani status respons sesuai
                dokumentasi endpoint yang dikonfigurasi.
              </p>
              <div className="db-card docs-errors-card">
                <ul className="docs-list">
                  <li>
                    <b>401</b>
                    <span>
                      Check that <code>AIVON_API_KEY</code> is present on the
                      server.
                    </span>
                  </li>
                  <li>
                    <b>429</b>
                    <span>
                      Back off and retry within the limits of your configured
                      gateway.
                    </span>
                  </li>
                  <li>
                    <b>400</b>
                    <span>
                      Verify the model ID and request payload before retrying.
                    </span>
                  </li>
                </ul>
                <p className="db-muted">
                  Batas request dan ketersediaan provider belum ditetapkan.
                  Jangan menganggap request berhasil tanpa respons gateway.
                </p>
              </div>
            </>
          )}
        </section>
      </div>
      <section
        className="db-card docs-pricing-card"
        aria-labelledby="docs-pricing-title"
      >
        <span className="db-eyebrow">TOKENS & PRICING</span>
        <h2 id="docs-pricing-title">Dua tarif USD. Satu multiplier kredit.</h2>
        <div className="docs-pricing-grid">
          <div>
            <h3>Input · USD / 1M tokens</h3>
            <p>Token yang dikirim ke model dihitung menggunakan tarif input.</p>
          </div>
          <div>
            <h3>Output · USD / 1M tokens</h3>
            <p>
              Token yang dihasilkan model dihitung menggunakan tarif output.
            </p>
          </div>
          <div>
            <h3>Credit multiplier</h3>
            <p>
              Kredit = pembulatan ke atas dari (input + output) × multiplier.
              Pengali ini diterapkan sekali, terpisah dari perhitungan USD.
            </p>
          </div>
        </div>
        <p className="db-muted">
          Biaya USD = (token input × tarif input + token output × tarif output)
          / 1.000.000. Harga AIVON yang belum ditetapkan ditampilkan sebagai
          “Belum ditetapkan”, bukan gratis. Lihat{" "}
          <a href="/dashboard/models">Models & pricing</a> untuk kalkulator.
        </p>
      </section>
      <section className="db-card code-card">
        <div className="db-card-header">
          <div>
            <span className="db-eyebrow">SERVER-SIDE EXAMPLE</span>
            <h2>Siapkan request server-side</h2>
          </div>
          <button
            className="db-btn db-btn-ghost"
            type="button"
            onClick={() => copy(code, `${language} snippet copied`)}
          >
            <DIcon name="copy" /> Copy code
          </button>
        </div>
        <div className="code-controls">
          <div className="db-segmented" aria-label="Code language">
            {(["curl", "JavaScript", "Python"] as Language[]).map((item) => (
              <button
                key={item}
                type="button"
                className={language === item ? "active" : ""}
                aria-pressed={language === item}
                onClick={() => setLanguage(item)}
              >
                {item}
              </button>
            ))}
          </div>
          <label className="db-field">
            Model
            <select
              className="db-select"
              value={modelId}
              onChange={(event) => setModelId(event.target.value)}
            >
              {dashboardModels.map((model) => (
                <option key={model.id} value={model.id}>
                  {model.name} — {model.id}
                </option>
              ))}
            </select>
          </label>
        </div>
        <pre
          className="docs-code"
          tabIndex={0}
          aria-label={`${language} code snippet`}
        >
          <code>{code}</code>
        </pre>
      </section>
    </>
  );
}
