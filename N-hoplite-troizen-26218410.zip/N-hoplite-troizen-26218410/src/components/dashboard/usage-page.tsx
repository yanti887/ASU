"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { ProviderIcon } from "../icons";
import {
  csvCell,
  dashboardModels,
  downloadText,
  formatDate,
  formatNumber,
  formatTokens,
  modelById,
  usageSummary,
} from "@/lib/dashboard-data";
import { useDashboard } from "./store";
import { DIcon, EmptyState, PageHeading } from "./ui";
import { UsageChart } from "./usage-chart";

export function UsagePage() {
  const { state, toast } = useDashboard();
  const [days, setDays] = useState(7);
  const [model, setModel] = useState("all");
  const [status, setStatus] = useState("all");
  const [key, setKey] = useState("all");
  const [page, setPage] = useState(1);
  const filtered = useMemo(() => {
    const since = Date.now() - days * 86400000;
    return state.usage
      .filter((record) => Date.parse(record.timestamp) >= since)
      .filter((record) => model === "all" || record.modelId === model)
      .filter((record) => status === "all" || record.status === status)
      .filter((record) => key === "all" || record.keyId === key)
      .sort((a, b) => b.timestamp.localeCompare(a.timestamp));
  }, [days, key, model, state.usage, status]);
  const summary = usageSummary(filtered);
  const pages = Math.max(1, Math.ceil(filtered.length / 10));
  const current = Math.min(page, pages);
  const shown = filtered.slice((current - 1) * 10, current * 10);
  const resetFilters = () => {
    setModel("all");
    setKey("all");
    setStatus("all");
    setPage(1);
  };
  function exportCSV() {
    const header = [
      "Request ID",
      "UTC time",
      "Model",
      "API key",
      "Status",
      "Input tokens",
      "Output tokens",
      "Billable tokens",
      "Latency ms",
    ];
    const rows = filtered.map((record) => [
      record.id,
      record.timestamp,
      modelById(record.modelId).name,
      state.keys.find((item) => item.id === record.keyId)?.name ??
        "Deleted key",
      record.status,
      record.input,
      record.output,
      record.billed,
      record.latency,
    ]);
    downloadText(
      "aivon-usage.csv",
      [header, ...rows].map((row) => row.map(csvCell).join(",")).join("\r\n"),
      "text/csv;charset=utf-8",
    );
    toast("Filtered usage exported");
  }
  return (
    <>
      <PageHeading
        eyebrow="EVERY TOKEN, IN PERSPECTIVE"
        title="Usage analytics"
        description="Know where your tokens go once model requests are connected."
        action={
          <button
            className="db-btn"
            onClick={exportCSV}
            disabled={!filtered.length}
          >
            <DIcon name="download" /> Export CSV
          </button>
        }
      />
      <div className="db-toolbar db-usage-filters">
        <label className="db-field">
          Period
          <select
            className="db-select"
            aria-label="Usage period"
            value={days}
            onChange={(event) => {
              setDays(Number(event.target.value));
              setPage(1);
            }}
          >
            <option value={7}>Last 7 days</option>
            <option value={30}>Last 30 days</option>
          </select>
        </label>
        <label className="db-field">
          Model
          <select
            className="db-select"
            aria-label="Filter usage model"
            value={model}
            onChange={(event) => {
              setModel(event.target.value);
              setPage(1);
            }}
          >
            <option value="all">All models</option>
            {dashboardModels.map((item) => (
              <option key={item.id} value={item.id}>
                {item.name}
              </option>
            ))}
          </select>
        </label>
        <label className="db-field">
          API key
          <select
            className="db-select"
            aria-label="Filter usage key"
            value={key}
            onChange={(event) => {
              setKey(event.target.value);
              setPage(1);
            }}
          >
            <option value="all">All API keys</option>
            {state.keys.map((item) => (
              <option key={item.id} value={item.id}>
                {item.name}
              </option>
            ))}
          </select>
        </label>
        <label className="db-field">
          Status
          <select
            className="db-select"
            aria-label="Filter usage status"
            value={status}
            onChange={(event) => {
              setStatus(event.target.value);
              setPage(1);
            }}
          >
            <option value="all">All statuses</option>
            <option value="success">Success</option>
            <option value="error">Error</option>
          </select>
        </label>
      </div>
      <div className="db-stat-grid">
        <div className="db-stat-card">
          <div>
            <span>Requests</span>
            <DIcon name="globe" />
          </div>
          <strong>{formatNumber(summary.requests)}</strong>
          <small className="db-muted">Matching current filters</small>
        </div>
        <div className="db-stat-card">
          <div>
            <span>Billable tokens</span>
            <DIcon name="bolt" />
          </div>
          <strong>{formatTokens(summary.tokens)}</strong>
          <small className="db-muted">After model multipliers</small>
        </div>
        <div className="db-stat-card">
          <div>
            <span>Input / output</span>
            <DIcon name="usage" />
          </div>
          <strong className="db-stat-smaller">
            {formatTokens(summary.input)}{" "}
            <small>/ {formatTokens(summary.output)}</small>
          </strong>
          <small className="db-muted">Raw model tokens</small>
        </div>
        <div className="db-stat-card">
          <div>
            <span>Success rate</span>
            <DIcon name="shield" />
          </div>
          <strong>
            {summary.success.toFixed(1)}
            <small>%</small>
          </strong>
          <small className="db-muted">
            {summary.latency
              ? `${summary.latency} ms average latency`
              : "No matching requests"}
          </small>
        </div>
      </div>
      {filtered.length ? (
        <section className="db-card">
          <div className="db-card-header">
            <div>
              <h2>Token consumption</h2>
              <p>Daily billable tokens for your current filters.</p>
            </div>
            <span className="db-badge violet">Last {days} days</span>
          </div>
          <UsageChart days={days} records={filtered} />
        </section>
      ) : (
        <section className="db-card">
          <EmptyState
            title="No requests in this view"
            description="There are no recorded requests that match the current filters."
          >
            <div className="db-empty-actions">
              <button className="db-btn db-btn-ghost" onClick={resetFilters}>
                Reset filters
              </button>
              <Link className="db-btn db-btn-primary" href="/dashboard/docs">
                Read integration notes <DIcon name="arrow" />
              </Link>
            </div>
          </EmptyState>
        </section>
      )}
      <section className="db-card db-usage-log">
        <div className="db-card-header">
          <div>
            <h2>Request log</h2>
            <p>
              {formatNumber(filtered.length)} recorded requests · timestamps in
              UTC
            </p>
          </div>
        </div>
        {shown.length ? (
          <>
            <div className="db-table-wrap">
              <table className="db-table">
                <thead>
                  <tr>
                    <th>Request / time</th>
                    <th>Model</th>
                    <th>API key</th>
                    <th>Status</th>
                    <th>Input</th>
                    <th>Output</th>
                    <th>Billable</th>
                    <th>Latency</th>
                  </tr>
                </thead>
                <tbody>
                  {shown.map((record) => {
                    const item = modelById(record.modelId);
                    return (
                      <tr key={record.id}>
                        <td>
                          <span className="db-request-id">
                            <code>{record.id}</code>
                            <small>{formatDate(record.timestamp, true)}</small>
                          </span>
                        </td>
                        <td>
                          <span className="db-table-model">
                            <ProviderIcon provider={item.provider} />
                            {item.name}
                          </span>
                        </td>
                        <td>
                          {state.keys.find((item) => item.id === record.keyId)
                            ?.name ?? "Deleted key"}
                        </td>
                        <td>
                          <span
                            className={`db-badge ${record.status === "success" ? "green" : "danger"}`}
                          >
                            {record.status === "success" ? "Success" : "Error"}
                          </span>
                        </td>
                        <td>{formatNumber(record.input)}</td>
                        <td>{formatNumber(record.output)}</td>
                        <td>{formatNumber(record.billed)}</td>
                        <td>{record.latency} ms</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <div className="db-pagination">
              <span>
                Showing {(current - 1) * 10 + 1}–
                {Math.min(current * 10, filtered.length)} of {filtered.length}
              </span>
              <div>
                <button
                  className="db-btn"
                  disabled={current === 1}
                  onClick={() => setPage(current - 1)}
                >
                  Previous
                </button>
                <span>
                  {current} / {pages}
                </span>
                <button
                  className="db-btn"
                  disabled={current === pages}
                  onClick={() => setPage(current + 1)}
                >
                  Next
                </button>
              </div>
            </div>
          </>
        ) : (
          <EmptyState
            title="No request log yet"
            description="Recorded model requests will appear here after the gateway is connected."
          />
        )}
      </section>
      <p className="db-fineprint">
        Billable tokens are raw input plus output tokens after the selected
        model multiplier is applied.
      </p>
    </>
  );
}
