"use client";

import Link from "next/link";
import { useMemo, useState, type FormEvent } from "react";
import { formatDate, formatTokens, type ApiKey } from "@/lib/dashboard-data";
import { useDashboard } from "./store";
import { DIcon, EmptyState, Modal, PageHeading } from "./ui";

type Filter = "all" | "active" | "revoked" | "expired";

function isExpired(key: ApiKey) {
  return (
    key.status === "active" &&
    !!key.expiresAt &&
    Date.parse(key.expiresAt) <= Date.now()
  );
}
function keyState(key: ApiKey) {
  return key.status === "revoked"
    ? "revoked"
    : isExpired(key)
      ? "expired"
      : "active";
}
function maskKey(key: ApiKey) {
  return `aivon_••••••••${key.suffix}`;
}

export default function KeysPage() {
  const { state, createKey, revokeKey, copy } = useDashboard();
  const [filter, setFilter] = useState<Filter>("all");
  const [query, setQuery] = useState("");
  const [createOpen, setCreateOpen] = useState(false);
  const [revokeTarget, setRevokeTarget] = useState<ApiKey | null>(null);
  const [newToken, setNewToken] = useState<string | null>(null);
  const [form, setForm] = useState({
    name: "",
    limit: "1000000",
    expiry: "30",
  });
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);
  const keys = useMemo(
    () =>
      state.keys.filter((key) => {
        const stateName = keyState(key);
        return (
          (filter === "all" || stateName === filter) &&
          (key.name.toLowerCase().includes(query.toLowerCase()) ||
            key.suffix.includes(query.toLowerCase()))
        );
      }),
    [filter, query, state.keys],
  );
  const lastUsed = (key: ApiKey) => {
    const record = state.usage
      .filter((item) => item.keyId === key.id)
      .sort((a, b) => b.timestamp.localeCompare(a.timestamp))[0];
    return record ? formatDate(record.timestamp, true) : "Never";
  };
  function closeCreate() {
    if (pending) return;
    setCreateOpen(false);
    setNewToken(null);
    setError("");
    setForm({ name: "", limit: "1000000", expiry: "30" });
  }
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const limit = Number(form.limit);
    if (!form.name.trim()) return setError("A key name is required.");
    if (form.name.trim().length > 48)
      return setError("Key names can be up to 48 characters.");
    if (!Number.isInteger(limit) || limit < 0 || limit > 1_000_000_000)
      return setError("Token limit must be a whole number from 0 to 1B.");
    setPending(true);
    setError("");
    try {
      setNewToken(
        await createKey(form.name.trim(), limit, Number(form.expiry)),
      );
    } catch (cause) {
      setError(
        cause instanceof Error
          ? cause.message
          : "Key could not be created. Try again.",
      );
    } finally {
      setPending(false);
    }
  }
  async function revoke() {
    if (!revokeTarget || pending) return;
    setPending(true);
    setError("");
    try {
      await revokeKey(revokeTarget.id);
      setRevokeTarget(null);
    } catch (cause) {
      setError(
        cause instanceof Error
          ? cause.message
          : "Key could not be revoked. Try again.",
      );
    } finally {
      setPending(false);
    }
  }
  if (!state.authenticated) {
    return (
      <section className="db-keys-page">
        <PageHeading
          eyebrow="DEVELOPER ACCESS"
          title="API keys"
          description="Create an account to manage persistent API keys for your workspace."
        />
        <section className="db-card">
          <EmptyState
            title="Sign in to manage API keys"
            description="Keys are attached to an AIVON account and shown only once when created."
          >
            <div className="db-empty-actions">
              <Link
                className="db-btn db-btn-primary"
                href="/register?next=%2Fdashboard%2Fapi-keys"
              >
                Buat akun <DIcon name="arrow" />
              </Link>
              <Link
                className="db-btn db-btn-ghost"
                href="/login?next=%2Fdashboard%2Fapi-keys"
              >
                Masuk
              </Link>
            </div>
          </EmptyState>
        </section>
      </section>
    );
  }
  return (
    <section className="db-keys-page">
      <PageHeading
        eyebrow="DEVELOPER ACCESS"
        title="API keys"
        description="Create and revoke persistent keys for each environment."
        action={
          <button
            className="db-btn db-btn-primary"
            type="button"
            onClick={() => setCreateOpen(true)}
          >
            <DIcon name="plus" /> Create key
          </button>
        }
      />
      <div className="db-notice">
        <DIcon name="shield" />
        <div>
          <strong>Keep keys private</strong>
          <span>
            Tokens are stored only as cryptographic hashes and are shown once.
            Gateway inference is not configured yet, so a key does not currently
            authorize model requests.
          </span>
        </div>
      </div>
      <div className="db-card db-keys-card">
        <div className="db-card-header">
          <div>
            <h2>Your keys</h2>
            <p className="db-muted">
              {state.keys.length} key{state.keys.length === 1 ? "" : "s"} in
              this workspace
            </p>
          </div>
        </div>
        <div className="db-toolbar">
          <label className="sr-only" htmlFor="key-search">
            Search keys
          </label>
          <div className="db-keys-search">
            <DIcon name="search" />
            <input
              id="key-search"
              className="db-input"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search by name or suffix"
            />
          </div>
          <label className="sr-only" htmlFor="key-filter">
            Filter keys
          </label>
          <select
            id="key-filter"
            className="db-select"
            value={filter}
            onChange={(event) => setFilter(event.target.value as Filter)}
          >
            <option value="all">All states</option>
            <option value="active">Active</option>
            <option value="revoked">Revoked</option>
            <option value="expired">Expired</option>
          </select>
        </div>
        {keys.length ? (
          <div className="db-table-wrap">
            <table className="db-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Key</th>
                  <th>Status</th>
                  <th>Created</th>
                  <th>Last used</th>
                  <th>Limit</th>
                  <th>Expires</th>
                  <th>
                    <span className="sr-only">Actions</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {keys.map((key) => {
                  const status = keyState(key);
                  return (
                    <tr key={key.id}>
                      <td>
                        <strong>{key.name}</strong>
                      </td>
                      <td>
                        <button
                          type="button"
                          className="db-btn-ghost font-mono text-xs"
                          onClick={() =>
                            copy(maskKey(key), "Masked key copied")
                          }
                        >
                          {maskKey(key)}
                        </button>
                      </td>
                      <td>
                        <span
                          className={`db-badge ${status === "active" ? "green" : status === "revoked" ? "danger" : "amber"}`}
                        >
                          {status}
                        </span>
                      </td>
                      <td>{formatDate(key.createdAt)}</td>
                      <td className="db-muted">{lastUsed(key)}</td>
                      <td>
                        <strong>
                          {key.limit ? formatTokens(key.limit) : "No limit"}
                        </strong>
                        <span className="db-keys-limit-caption">per key</span>
                      </td>
                      <td>
                        {key.expiresAt ? formatDate(key.expiresAt) : "Never"}
                      </td>
                      <td>
                        {status === "active" && (
                          <button
                            type="button"
                            className="db-btn db-btn-danger db-btn-small"
                            onClick={() => {
                              setError("");
                              setRevokeTarget(key);
                            }}
                          >
                            Revoke
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            title={
              query || filter !== "all" ? "No matching keys" : "No API keys yet"
            }
            description={
              query || filter !== "all"
                ? "Try another search or filter."
                : "Create a key for a server environment. It will be shown only once."
            }
          >
            {!query && filter === "all" && (
              <button
                type="button"
                className="db-btn db-btn-primary"
                onClick={() => setCreateOpen(true)}
              >
                Create key <DIcon name="plus" />
              </button>
            )}
          </EmptyState>
        )}
      </div>
      {createOpen && (
        <Modal
          title={newToken ? "Copy your API key" : "Create API key"}
          description={
            newToken
              ? "Copy this token now. It cannot be viewed again after this dialog closes."
              : "Set a name, a token limit, and an expiry for this key."
          }
          onClose={closeCreate}
        >
          <div className="db-dialog-body">
            {newToken ? (
              <div className="db-created-key">
                <label htmlFor="new-api-key">Your new API key</label>
                <div>
                  <input
                    id="new-api-key"
                    className="db-input font-mono"
                    readOnly
                    value={newToken}
                    aria-label="Your new API key"
                  />
                  <button
                    className="db-btn db-btn-primary"
                    type="button"
                    onClick={() => copy(newToken, "API key copied")}
                  >
                    Copy key <DIcon name="copy" />
                  </button>
                </div>
                <p className="db-muted">
                  Store it in your server environment. It will not be saved in
                  the browser.
                </p>
              </div>
            ) : (
              <form id="create-key-form" onSubmit={submit}>
                <div className="db-form-grid">
                  <label className="db-field" htmlFor="key-name">
                    Key name
                    <input
                      id="key-name"
                      className="db-input"
                      autoFocus
                      maxLength={48}
                      value={form.name}
                      onChange={(event) =>
                        setForm({ ...form, name: event.target.value })
                      }
                      placeholder="Production API"
                      required
                      disabled={pending}
                    />
                  </label>
                  <label className="db-field" htmlFor="key-limit">
                    Token limit
                    <input
                      id="key-limit"
                      className="db-input"
                      type="number"
                      min="0"
                      max="1000000000"
                      step="1"
                      inputMode="numeric"
                      value={form.limit}
                      onChange={(event) =>
                        setForm({ ...form, limit: event.target.value })
                      }
                      required
                      disabled={pending}
                    />
                    <span className="db-muted">
                      0 means no limit · maximum 1B tokens
                    </span>
                  </label>
                  <label className="db-field" htmlFor="key-expiry">
                    Expiration
                    <select
                      id="key-expiry"
                      className="db-select"
                      value={form.expiry}
                      onChange={(event) =>
                        setForm({ ...form, expiry: event.target.value })
                      }
                      disabled={pending}
                    >
                      <option value="7">7 days</option>
                      <option value="30">30 days</option>
                      <option value="0">No expiry</option>
                    </select>
                  </label>
                </div>
                {error && (
                  <p className="text-sm text-red-600" role="alert">
                    {error}
                  </p>
                )}
              </form>
            )}
          </div>
          <div className="db-dialog-footer">
            <button
              className="db-btn"
              type="button"
              onClick={closeCreate}
              disabled={pending}
            >
              {newToken ? "Done" : "Cancel"}
            </button>
            {!newToken && (
              <button
                className="db-btn db-btn-primary"
                type="submit"
                form="create-key-form"
                disabled={pending}
              >
                {pending ? "Creating…" : "Create key"}
              </button>
            )}
          </div>
        </Modal>
      )}
      {revokeTarget && (
        <Modal
          title="Revoke API key?"
          description="This action immediately invalidates the key and cannot be undone."
          onClose={() => !pending && setRevokeTarget(null)}
        >
          <div className="db-dialog-body">
            <p>
              Revoke <strong>{revokeTarget.name}</strong>? Existing records
              remain visible, but this token can no longer be used.
            </p>
            {error && (
              <p className="text-sm text-red-600" role="alert">
                {error}
              </p>
            )}
          </div>
          <div className="db-dialog-footer">
            <button
              className="db-btn"
              type="button"
              onClick={() => setRevokeTarget(null)}
              disabled={pending}
            >
              Cancel
            </button>
            <button
              className="db-btn db-btn-danger"
              type="button"
              onClick={revoke}
              disabled={pending}
            >
              {pending ? "Revoking…" : "Revoke key"}
            </button>
          </div>
        </Modal>
      )}
    </section>
  );
}
