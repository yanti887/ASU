"use client";

import Link from "next/link";
import { DIcon, PageHeading } from "./ui";

export default function BillingPage() {
  return (
    <section className="db-billing-page">
      <PageHeading
        eyebrow="BILLING"
        title="Billing, when it is ready."
        description="Paket token, checkout, dan riwayat pembayaran belum tersedia di AIVON."
      />
      <div className="db-notice">
        <DIcon name="shield" />
        <div>
          <strong>Tidak ada checkout yang aktif</strong>
          <span>
            AIVON belum menerima pembayaran atau menerbitkan saldo token dari
            halaman ini. Tidak ada transaksi maupun tagihan yang dibuat.
          </span>
        </div>
      </div>
      <div className="db-grid-3 db-billing-metrics">
        <article className="db-card">
          <span className="db-muted">Token balance</span>
          <strong>—</strong>
          <span className="db-muted">Belum tersedia</span>
        </article>
        <article className="db-card">
          <span className="db-muted">Payment methods</span>
          <strong>—</strong>
          <span className="db-muted">Belum tersedia</span>
        </article>
        <article className="db-card">
          <span className="db-muted">Invoices</span>
          <strong>—</strong>
          <span className="db-muted">Belum tersedia</span>
        </article>
      </div>
      <section className="db-card db-billing-section">
        <div className="db-card-header">
          <div>
            <h2>Pricing will appear here</h2>
            <p className="db-muted">
              Tarif paket dan metode pembayaran akan ditampilkan hanya setelah
              sistem billing terhubung. Halaman ini tidak menggunakan contoh
              harga atau saldo buatan.
            </p>
          </div>
          <DIcon name="billing" />
        </div>
        <div className="db-empty-inline">
          <span className="db-empty-icon">
            <DIcon name="bolt" />
          </span>
          <div>
            <strong>Belum ada paket token aktif.</strong>
            <p className="db-muted">
              Sementara ini, bandingkan model dan struktur tarif input/output di
              katalog.
            </p>
          </div>
          <Link className="db-btn db-btn-primary" href="/dashboard/models">
            Lihat model <DIcon name="arrow" />
          </Link>
        </div>
      </section>
    </section>
  );
}
