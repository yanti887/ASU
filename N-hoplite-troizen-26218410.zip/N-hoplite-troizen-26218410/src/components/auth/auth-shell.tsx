"use client";

import Link from "next/link";
import type { ReactNode } from "react";
import { Arrow, Mark } from "@/components/icons";
import ThemeToggle from "@/components/theme-toggle";
import { useMotionPreference } from "@/lib/use-motion-preference";
import styles from "./auth.module.css";

export default function AuthShell({ children }: { children: ReactNode }) {
  const { paused, reduced, setPaused } = useMotionPreference();

  return (
    <div className={styles.page} data-paused={paused}>
      <a className={styles.skipLink} href="#auth-main">
        Langsung ke formulir
      </a>
      <header className={styles.header}>
        <Link href="/" className="wordmark" aria-label="AIVON — beranda">
          <Mark />
          <span>aivon</span>
          <sup>®</sup>
        </Link>
        <div className={styles.headerActions}>
          <Link href="/dashboard" className={styles.exploreLink}>
            Jelajahi dashboard <Arrow diagonal />
          </Link>
          <ThemeToggle />
        </div>
      </header>

      <div className={styles.layout}>
        <aside className={styles.story} aria-label="Tentang workspace AIVON">
          <span className={styles.eyebrow}>AIVON / YOUR NEXT CHAPTER</span>
          <h2>
            More room.
            <br />
            <em>More possibility.</em>
          </h2>
          <p>
            Satu tempat untuk pilihan model dan ide berikutnya.
            <br />
            Lebih sedikit kerumitan. Lebih banyak ruang membangun.
          </p>
          <div className={styles.orbit} aria-hidden="true">
            <div className={styles.orbitGlow} />
            <svg viewBox="0 0 440 340" fill="none">
              <path
                className={styles.orbitGuide}
                d="M0 170h440M220 0v340"
                stroke="currentColor"
                strokeDasharray="3 7"
              />
              <g className={styles.orbitRings} stroke="currentColor">
                <ellipse cx="220" cy="170" rx="190" ry="72" />
                <ellipse
                  cx="220"
                  cy="170"
                  rx="190"
                  ry="72"
                  transform="rotate(60 220 170)"
                />
                <ellipse
                  cx="220"
                  cy="170"
                  rx="190"
                  ry="72"
                  transform="rotate(120 220 170)"
                />
              </g>
              <circle
                className={styles.orbitBoundary}
                cx="220"
                cy="170"
                r="126"
                stroke="currentColor"
                strokeDasharray="2 8"
              />
              <g className={styles.orbitSatellite}>
                <circle
                  cx="220"
                  cy="44"
                  r="11"
                  fill="currentColor"
                  opacity=".1"
                />
                <circle cx="220" cy="44" r="4" fill="currentColor" />
                <circle
                  cx="220"
                  cy="296"
                  r="5"
                  fill="currentColor"
                  opacity=".6"
                />
              </g>
            </svg>
            <div className={styles.orbitCore}>
              <Mark />
            </div>
            <span className={`${styles.orbitLabel} ${styles.orbitLabelTop}`}>
              INDEPENDENT MINDS
            </span>
            <span className={`${styles.orbitLabel} ${styles.orbitLabelBottom}`}>
              ONE COMMON GROUND
            </span>
          </div>
          <div className={styles.storyFoot}>
            <span>01 / A PLACE TO BEGIN</span>
            <Arrow diagonal />
          </div>
        </aside>

        <main id="auth-main" className={styles.formPanel}>
          {children}
        </main>
      </div>

      <footer className={styles.footer}>
        <span>LESS FRICTION. MORE BUILDING.</span>
        <button
          type="button"
          onClick={() => setPaused(!paused)}
          disabled={reduced}
          aria-pressed={paused}
          aria-label={paused ? "Aktifkan animasi" : "Jeda animasi"}
          title={reduced ? "Mengikuti pengaturan gerakan perangkat" : undefined}
        >
          <span aria-hidden="true">{paused ? "▷" : "Ⅱ"}</span>
          {reduced ? "REDUCED MOTION" : paused ? "MOTION OFF" : "MOTION ON"}
        </button>
      </footer>
    </div>
  );
}
