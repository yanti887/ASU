"use client";

import Link from "next/link";
import { useRef, useState, type FormEvent } from "react";
import { Arrow } from "@/components/icons";
import styles from "./auth.module.css";

type Fields = {
  name: string;
  email: string;
  password: string;
  confirmation: string;
};
type FieldName = keyof Fields;
type Errors = Partial<Record<FieldName, string>>;

function validate(values: Fields, registering: boolean): Errors {
  const errors: Errors = {};
  if (
    registering &&
    (values.name.trim().length < 2 || values.name.trim().length > 64)
  )
    errors.name = "Nama perlu berisi 2–64 karakter.";
  if (
    values.email.trim().length > 254 ||
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email.trim())
  )
    errors.email = "Masukkan alamat email yang valid.";
  if (values.password.length < 12 || values.password.length > 128)
    errors.password = "Gunakan kata sandi sepanjang 12–128 karakter.";
  if (registering && !values.confirmation)
    errors.confirmation = "Ulangi kata sandimu untuk melanjutkan.";
  else if (registering && values.confirmation !== values.password)
    errors.confirmation = "Kedua kata sandi belum cocok.";
  return errors;
}

function requestError(status: number) {
  if (status === 401) return "Email atau kata sandi tidak cocok. Coba lagi.";
  if (status === 409) return "Email ini sudah terdaftar. Masuk dengan akunmu.";
  if (status === 429)
    return "Terlalu banyak percobaan. Tunggu sebentar, lalu coba lagi.";
  if (status === 400) return "Periksa kembali data formulir, lalu coba lagi.";
  return "Akun belum dapat diproses. Silakan coba lagi sebentar.";
}

export default function AuthForm({
  mode,
  next,
}: {
  mode: "login" | "register";
  next: string;
}) {
  const registering = mode === "register";
  const [values, setValues] = useState<Fields>({
    name: "",
    email: "",
    password: "",
    confirmation: "",
  });
  const [touched, setTouched] = useState<Partial<Record<FieldName, boolean>>>(
    {},
  );
  const [status, setStatus] = useState<"idle" | "pending" | "success">("idle");
  const [error, setError] = useState("");
  const submitting = useRef(false);
  const form = useRef<HTMLFormElement>(null);
  const errors = validate(values, registering);
  const busy = status !== "idle";
  const alternative = `${registering ? "/login" : "/register"}?next=${encodeURIComponent(next)}`;

  function update(field: FieldName, value: string) {
    setValues((previous) => ({ ...previous, [field]: value }));
    setError("");
  }

  function blur(field: FieldName) {
    setTouched((previous) => ({ ...previous, [field]: true }));
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (submitting.current) return;
    setTouched({ name: true, email: true, password: true, confirmation: true });
    setError("");
    const firstInvalid = Object.keys(errors)[0];
    if (firstInvalid) {
      const input = form.current?.elements.namedItem(firstInvalid);
      if (input instanceof HTMLElement) input.focus();
      return;
    }

    submitting.current = true;
    setStatus("pending");
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 20_000);
    try {
      const response = await fetch(`/api/auth/${mode}`, {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...(registering ? { name: values.name.trim() } : {}),
          email: values.email.trim(),
          password: values.password,
        }),
        signal: controller.signal,
      });
      if (!response.ok) {
        setError(requestError(response.status));
        setStatus("idle");
        submitting.current = false;
        return;
      }
      setValues((previous) => ({
        ...previous,
        password: "",
        confirmation: "",
      }));
      setTouched({});
      setStatus("success");
      window.location.assign(next);
    } catch {
      setError(
        controller.signal.aborted
          ? "Koneksi terlalu lama. Coba lagi; jika akun sudah dibuat, masuk dengan email yang sama."
          : "Tidak dapat terhubung. Periksa koneksi internetmu, lalu coba lagi.",
      );
      setStatus("idle");
      submitting.current = false;
    } finally {
      window.clearTimeout(timeout);
    }
  }

  return (
    <div className={styles.formContent}>
      <span className={styles.eyebrow}>
        {registering ? "LET’S BUILD SOMETHING" : "PICK UP WHERE YOU LEFT OFF"}
      </span>
      <h1>{registering ? "Mulai dari sini." : "Selamat datang kembali."}</h1>
      <p className={styles.intro}>
        {registering
          ? "Buat akunmu. Simpan pilihanmu. Beri ruang untuk ide berikutnya."
          : "Masuk ke akunmu dan lanjutkan dari workspace yang kamu tinggalkan."}
      </p>

      <form
        ref={form}
        className={styles.form}
        onSubmit={submit}
        noValidate
        aria-busy={busy}
      >
        {registering && (
          <TextField
            name="name"
            label="Nama lengkap"
            placeholder="Nama yang ingin kamu gunakan"
            autoComplete="name"
            maxLength={64}
            value={values.name}
            error={touched.name ? errors.name : undefined}
            disabled={busy}
            onChange={(value) => update("name", value)}
            onBlur={() => blur("name")}
          />
        )}
        <TextField
          name="email"
          label="Email"
          type="email"
          placeholder="kamu@perusahaan.com"
          autoComplete="email"
          maxLength={254}
          value={values.email}
          error={touched.email ? errors.email : undefined}
          disabled={busy}
          onChange={(value) => update("email", value)}
          onBlur={() => blur("email")}
        />
        <PasswordField
          name="password"
          label="Kata sandi"
          autoComplete={registering ? "new-password" : "current-password"}
          value={values.password}
          error={touched.password ? errors.password : undefined}
          hint={
            registering
              ? "12–128 karakter. Gunakan kata sandi yang unik."
              : undefined
          }
          disabled={busy}
          onChange={(value) => update("password", value)}
          onBlur={() => blur("password")}
        />
        {registering && (
          <PasswordField
            name="confirmation"
            label="Ulangi kata sandi"
            autoComplete="new-password"
            value={values.confirmation}
            error={touched.confirmation ? errors.confirmation : undefined}
            disabled={busy}
            onChange={(value) => update("confirmation", value)}
            onBlur={() => blur("confirmation")}
          />
        )}
        {error && (
          <p className={styles.requestError} role="alert">
            {error}
          </p>
        )}
        <button className={styles.submit} type="submit" disabled={busy}>
          <span>
            {status === "success"
              ? "Membuka dashboard…"
              : status === "pending"
                ? registering
                  ? "Membuat akun…"
                  : "Sedang masuk…"
                : registering
                  ? "Buat akun"
                  : "Masuk"}
          </span>
          {status === "pending" ? (
            <span className={styles.spinner} aria-hidden="true" />
          ) : (
            <Arrow />
          )}
        </button>
        <p className={styles.status} role="status">
          {status === "success"
            ? registering
              ? "Akun berhasil dibuat. Mengarahkan ke workspace-mu."
              : "Berhasil masuk. Mengarahkan ke workspace-mu."
            : status === "pending"
              ? "Menghubungkan ke akunmu…"
              : ""}
        </p>
      </form>
      <p className={styles.alternative}>
        {registering ? "Sudah punya akun?" : "Belum punya akun?"}{" "}
        <Link href={alternative}>
          {registering ? "Masuk" : "Daftar sekarang"} <Arrow diagonal />
        </Link>
      </p>
      <p className={styles.formNote}>
        Profil dan pilihan model disimpan di akunmu.
        <br />
        Kamu juga bisa{" "}
        <Link href="/dashboard/models">melihat katalog model</Link> sebelum
        mendaftar.
      </p>
    </div>
  );
}

type FieldProps = {
  name: FieldName;
  label: string;
  value: string;
  autoComplete: string;
  error?: string;
  disabled: boolean;
  onChange: (value: string) => void;
  onBlur: () => void;
};

function TextField({
  name,
  label,
  value,
  autoComplete,
  error,
  disabled,
  onChange,
  onBlur,
  type = "text",
  placeholder,
  maxLength,
}: FieldProps & {
  type?: "text" | "email";
  placeholder: string;
  maxLength: number;
}) {
  const id = `auth-${name}`;
  return (
    <div className={styles.field}>
      <label htmlFor={id}>{label}</label>
      <input
        id={id}
        name={name}
        type={type}
        value={value}
        placeholder={placeholder}
        autoComplete={autoComplete}
        autoCapitalize={type === "email" ? "none" : "words"}
        spellCheck={false}
        maxLength={maxLength}
        required
        disabled={disabled}
        onChange={(event) => onChange(event.target.value)}
        onBlur={onBlur}
        aria-invalid={!!error}
        aria-describedby={error ? `${id}-error` : undefined}
      />
      {error && (
        <small id={`${id}-error`} className={styles.fieldError}>
          {error}
        </small>
      )}
    </div>
  );
}

function PasswordField({
  name,
  label,
  value,
  autoComplete,
  error,
  disabled,
  onChange,
  onBlur,
  hint,
}: FieldProps & { hint?: string }) {
  const [visible, setVisible] = useState(false);
  const id = `auth-${name}`;
  const description = [hint ? `${id}-hint` : "", error ? `${id}-error` : ""]
    .filter(Boolean)
    .join(" ");
  return (
    <div className={styles.field}>
      <label htmlFor={id}>{label}</label>
      <div className={styles.password}>
        <input
          id={id}
          name={name}
          type={visible ? "text" : "password"}
          value={value}
          autoComplete={autoComplete}
          autoCapitalize="none"
          spellCheck={false}
          minLength={12}
          maxLength={128}
          required
          disabled={disabled}
          onChange={(event) => onChange(event.target.value)}
          onBlur={onBlur}
          aria-invalid={!!error}
          aria-describedby={description || undefined}
        />
        <button
          type="button"
          className={styles.revealPassword}
          onClick={() => setVisible(!visible)}
          disabled={disabled}
          aria-label={`${visible ? "Sembunyikan" : "Tampilkan"} ${name === "confirmation" ? "ulangan kata sandi" : "kata sandi"}`}
          aria-pressed={visible}
          aria-controls={id}
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.5"
            aria-hidden="true"
          >
            <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z" />
            <circle cx="12" cy="12" r="3" />
            {visible && <path d="m3 3 18 18" />}
          </svg>
        </button>
      </div>
      {hint && (
        <small id={`${id}-hint`} className={styles.hint}>
          {hint}
        </small>
      )}
      {error && (
        <small id={`${id}-error`} className={styles.fieldError}>
          {error}
        </small>
      )}
    </div>
  );
}
