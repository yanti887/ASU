const fallback = "/dashboard";
const internalOrigin = "https://aivon.invalid";

export function safeDashboardNext(value: string | string[] | undefined) {
  if (
    typeof value !== "string" ||
    !value.startsWith("/dashboard") ||
    /[\\\u0000-\u001f\u007f]/.test(value)
  )
    return fallback;

  try {
    const url = new URL(value, internalOrigin);
    // Reject encoded path separators and traversal rather than interpreting them twice.
    if (
      url.origin !== internalOrigin ||
      url.pathname.includes("%") ||
      (url.pathname !== fallback && !url.pathname.startsWith(`${fallback}/`))
    )
      return fallback;
    return `${url.pathname}${url.search}${url.hash}`;
  } catch {
    return fallback;
  }
}
