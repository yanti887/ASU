"use client";

import dynamic from "next/dynamic";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { Arrow, CopyIcon, Mark, ProviderIcon, SwordGlyph } from "./icons";
import { models, snippets, type Model } from "@/lib/models";
import { ScrollProgress, useCardSpotlight } from "./motion-effects";
import ThemeToggle from "./theme-toggle";
import { useMotionPreference } from "@/lib/use-motion-preference";

const NetworkScene = dynamic(() => import("./network-scene"), { ssr: false });
const categories = ["All models", "Coding", "Reasoning", "Multimodal"] as const;
const routes = [
  {
    title: "Write something that works.",
    subtitle: "FOR THE BUILDERS",
    description:
      "Dari prototipe pertama sampai pull request terakhir. Pilih partner coding yang cocok dengan cara kamu bekerja.",
    primary: "Anthropic",
    secondary: "OpenAI",
    use: "Code generation",
    symbol: "</>",
  },
  {
    title: "Make the complex, clear.",
    subtitle: "FOR THE THINKERS",
    description:
      "Pecah persoalan rumit menjadi langkah yang masuk akal. Pilih model penalaran tanpa merombak integrasimu.",
    primary: "OpenAI",
    secondary: "DeepSeek",
    use: "Deep reasoning",
    symbol: "x²",
  },
  {
    title: "See the bigger picture.",
    subtitle: "FOR THE EXPLORERS",
    description:
      "Teks bukan satu-satunya cara memahami dunia. Eksplorasi model multimodal untuk perspektif yang lebih luas.",
    primary: "Google",
    secondary: "Meta",
    use: "Multimodal input",
    symbol: "◫",
  },
];

function Entry({ done, reduced }: { done: () => void; reduced: boolean }) {
  const [leaving, setLeaving] = useState(false);
  const callback = useRef(done);
  const holding = useRef(false);
  const exitRequested = useRef(false);
  useEffect(() => {
    callback.current = done;
  }, [done]);
  useEffect(() => {
    const timer = setTimeout(
      () => {
        exitRequested.current = true;
        if (!holding.current) setLeaving(true);
      },
      reduced ? 0 : 1550,
    );
    const finish = setTimeout(
      () => {
        if (!holding.current) callback.current();
      },
      reduced ? 20 : 2350,
    );
    return () => {
      clearTimeout(timer);
      clearTimeout(finish);
    };
  }, [reduced]);
  return (
    <div
      className={`entry ${leaving ? "entry-leaving" : ""}`}
      aria-label="Memasuki AIVON"
      role="status"
    >
      <div className="entry-panel entry-left" />
      <div className="entry-panel entry-right" />
      <div className="entry-content">
        <span className="entry-top mono">AIVON / CONNECTING POSSIBILITIES</span>
        <div className="entry-sword">
          <SwordGlyph />
          <div className="entry-sword-line" />
        </div>
        <div className="entry-word">
          AIVON<span>®</span>
        </div>
        <div className="entry-track">
          <i />
        </div>
        <span className="mono entry-bottom">LESS FRICTION. MORE BUILDING.</span>
      </div>
      <button
        className="entry-skip mono"
        onPointerEnter={() => {
          holding.current = true;
        }}
        onFocus={() => {
          holding.current = true;
        }}
        onPointerLeave={() => {
          holding.current = false;
          if (exitRequested.current) callback.current();
        }}
        onBlur={() => {
          holding.current = false;
          if (exitRequested.current) callback.current();
        }}
        onClick={() => {
          setLeaving(true);
          callback.current();
        }}
      >
        Skip intro <Arrow />
      </button>
    </div>
  );
}

function ModelCard({
  model,
  index,
  selected,
  onSelect,
}: {
  model: Model;
  index: number;
  selected: boolean;
  onSelect: () => void;
}) {
  return (
    <button
      className={`model-card group ${selected ? "is-selected" : ""}`}
      onClick={onSelect}
      aria-expanded={selected}
      aria-controls="model-detail"
      data-model={model.id}
    >
      <div className="flex items-center justify-between">
        <span className="mono text-[9px] tracking-widest text-stone-500">
          0{index + 1} / {model.label}
        </span>
        <Arrow diagonal className="model-card-arrow size-4" />
      </div>
      <div className="model-identity">
        <ProviderIcon
          provider={model.provider}
          style={{ color: model.color }}
          className="size-10"
        />
        <div>
          <span className="model-provider">{model.provider}</span>
          <h3>{model.name}</h3>
        </div>
      </div>
      <p>{model.description}</p>
      <div className="model-card-bottom">
        <span>{model.category}</span>
        <span>
          View model <span className="plus">+</span>
        </span>
      </div>
    </button>
  );
}

export default function Landing() {
  const [entered, setEntered] = useState(false);
  const { paused, reduced, setPaused } = useMotionPreference();
  const [menu, setMenu] = useState(false);
  const [category, setCategory] = useState<string>("All models");
  const [query, setQuery] = useState("");
  const [expanded, setExpanded] = useState(false);
  const [selected, setSelected] = useState<Model | null>(null);
  const [route, setRoute] = useState(0);
  const [language, setLanguage] = useState<keyof typeof snippets>("JavaScript");
  const [toast, setToast] = useState("");
  const toastTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const detail = useRef<HTMLDivElement>(null);
  const searchInput = useRef<HTMLInputElement>(null);
  useCardSpotlight(paused || reduced);

  useEffect(() => {
    function handleKey(event: KeyboardEvent) {
      if (event.key === "Escape") setMenu(false);
      const target = event.target;
      if (event.key !== "/" || event.ctrlKey || event.metaKey || event.altKey)
        return;
      if (
        target instanceof HTMLElement &&
        (target.isContentEditable || target.closest("input, textarea, select"))
      )
        return;
      event.preventDefault();
      searchInput.current?.focus();
    }
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) =>
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.setAttribute("data-visible", "true");
            observer.unobserve(entry.target);
          }
        }),
      { threshold: 0.1 },
    );
    document
      .querySelectorAll("[data-reveal]")
      .forEach((element) => observer.observe(element));
    return () => observer.disconnect();
  }, []);
  useEffect(
    () => () => {
      if (toastTimeout.current) clearTimeout(toastTimeout.current);
    },
    [],
  );

  async function copy(text: string, success: string) {
    try {
      await navigator.clipboard.writeText(text);
      setToast(success);
    } catch {
      setToast("Clipboard tidak tersedia. Pilih dan salin teks secara manual.");
    }
    if (toastTimeout.current) clearTimeout(toastTimeout.current);
    toastTimeout.current = setTimeout(() => setToast(""), 3500);
  }
  function selectModel(model: Model) {
    setSelected((previous) => (previous?.id === model.id ? null : model));
  }
  const visibleModels = models
    .filter(
      (model) =>
        (category === "All models" || model.category === category) &&
        `${model.name} ${model.provider}`
          .toLowerCase()
          .includes(query.trim().toLowerCase()),
    )
    .slice(0, expanded || query || category !== "All models" ? 6 : 3);
  const activeRoute = routes[route];

  return (
    <div className={`site ${entered ? "has-entered" : ""}`}>
      <ScrollProgress />
      {!entered && <Entry done={() => setEntered(true)} reduced={reduced} />}
      <a href="#main" className="skip-link">
        Lewati ke konten
      </a>
      <div className="announcement mono">
        <span /> ONE CONNECTION. A WORLD OF POSSIBILITIES.{" "}
        <Link href="/dashboard">
          EXPLORE AIVON <Arrow diagonal />
        </Link>
      </div>
      <header className="site-header page-shell">
        <a href="#" aria-label="AIVON beranda" className="wordmark">
          <Mark />
          <span>aivon</span>
          <sup>®</sup>
        </a>
        <nav
          className={`main-nav ${menu ? "nav-open" : ""}`}
          id="main-nav"
          aria-label="Navigasi utama"
          onClick={() => setMenu(false)}
        >
          <a href="#models">
            Models <span className="nav-count">06</span>
          </a>
          <a href="#why-aivon">Smart routing</a>
          <a href="#developers">
            Developers <Arrow diagonal />
          </a>
          <Link href="/login">Login</Link>
          <Link href="/register" className="mobile-dashboard-link">
            Daftar <Arrow diagonal />
          </Link>
          <Link href="/dashboard" className="mobile-dashboard-link">
            Dashboard <Arrow diagonal />
          </Link>
        </nav>
        <div className="flex items-center gap-5">
          <ThemeToggle />
          <button
            className="motion-control"
            disabled={reduced}
            onClick={() => setPaused(!paused)}
            aria-label={paused ? "Aktifkan animasi" : "Jeda animasi"}
            aria-pressed={paused}
          >
            <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
              <circle
                cx="10"
                cy="10"
                r="8"
                stroke="currentColor"
                strokeWidth="1"
              />
              {paused ? (
                <path d="m8 6 6 4-6 4V6Z" fill="currentColor" />
              ) : (
                <path d="M7 6h2v8H7zm4 0h2v8h-2z" fill="currentColor" />
              )}
            </svg>
          </button>
          <Link href="/register" className="nav-cta">
            Daftar <Arrow diagonal />
          </Link>
          <button
            className={`menu-button ${menu ? "menu-open" : ""}`}
            aria-label={menu ? "Tutup menu" : "Buka menu"}
            aria-expanded={menu}
            aria-controls="main-nav"
            onClick={() => setMenu(!menu)}
          >
            <i />
            <i />
          </button>
        </div>
      </header>

      <main id="main">
        <section className="hero" aria-labelledby="hero-title">
          <div className="hero-inner">
            <NetworkScene paused={paused || reduced || !entered} />
            <div className="hero-fade" />
            <div className="hero-topline">
              <span>
                <i className="signal" /> THE GATEWAY FOR YOUR NEXT BIG THING
              </span>
              <span>
                INDEPENDENT AI INFRASTRUCTURE <Arrow diagonal />
              </span>
            </div>
            <div className="hero-layout">
              <div className="hero-beacons" aria-label="Akses cepat provider">
                {["OpenAI", "Anthropic", "Google"].map((provider, index) => (
                  <a
                    key={provider}
                    className={`provider-beacon beacon-${index}`}
                    href="#models"
                    onClick={() => {
                      setCategory("All models");
                      setQuery(provider);
                      setSelected(null);
                    }}
                  >
                    <ProviderIcon provider={provider} />
                    <span>
                      {provider === "OpenAI"
                        ? "GPT"
                        : provider === "Anthropic"
                          ? "Claude"
                          : "Gemini"}
                    </span>
                    <i />
                  </a>
                ))}
              </div>
              <div className="hero-copy">
                <h1 id="hero-title">
                  <span className="line">
                    <span>ONE API.</span>
                  </span>
                  <span className="line">
                    <span>MORE MODELS.</span>
                  </span>
                  <span className="line">
                    <span>
                      LESS <em>FRICTION.</em>
                    </span>
                  </span>
                </h1>
                <div className="hero-value-lines">
                  <p>
                    <span className="value-tag">BUILD</span> Satu integrasi.
                    Banyak kemungkinan.
                  </p>
                  <p>
                    <span className="value-tag violet">SWITCH</span> Ganti
                    model, bukan seluruh aplikasimu.
                  </p>
                </div>
                <span className="hero-caption mono">
                  OPENAI-COMPATIBLE <i /> MULTI-PROVIDER <i /> BUILT FOR
                  DEVELOPERS
                </span>
              </div>
              <div className="hero-side">
                <div className="orb-caption mono">
                  <span className="signal" /> INTELLIGENCE, INTERCONNECTED.
                  <span>01 → ∞</span>
                </div>
                <div className="hero-actions">
                  <Link className="button button-primary" href="/dashboard">
                    Explore models <Arrow diagonal />
                  </Link>
                  <Link
                    className="button button-outline"
                    href="/dashboard/docs"
                  >
                    Read the docs <Arrow />
                  </Link>
                </div>
                <p className="landing-service-status">
                  Gateway inference belum dikonfigurasi.
                </p>
              </div>
            </div>
            <div className="hero-bottom">
              <div>
                <strong>1 key</strong>
                <span>ONE WAY TO CONNECT</span>
              </div>
              <div>
                <strong>6 families</strong>
                <span>A CURATED MODEL CATALOG</span>
              </div>
              <div>
                <strong>Your stack</strong>
                <span>NO NEED TO START OVER</span>
              </div>
              <a
                href="#models"
                className="scroll-cue"
                aria-label="Scroll ke model"
              >
                <span>DISCOVER THE POSSIBILITIES</span>
                <Arrow />
              </a>
            </div>
          </div>
        </section>

        <section
          className="provider-belt page-shell"
          aria-label="Keluarga provider dalam katalog"
        >
          <span className="mono belt-label">
            GREAT MINDS.
            <br />
            IN GOOD COMPANY.
          </span>
          <div className="provider-window">
            <div className="provider-track">
              {[0, 1].map((copy) => (
                <div
                  className="provider-names"
                  key={copy}
                  aria-hidden={copy === 1 ? true : undefined}
                >
                  {[
                    "OpenAI",
                    "Anthropic",
                    "Google",
                    "DeepSeek",
                    "Mistral",
                    "Meta",
                  ].map((provider) => (
                    <div key={provider}>
                      <ProviderIcon provider={provider} />
                      <span>{provider}</span>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="model-section section-shell" id="models">
          <div className="section-heading" data-reveal>
            <div>
              <span className="eyebrow">
                <span /> THE MODEL CATALOG
              </span>
              <h2>
                Frontier thinking.
                <br />
                <em>One connection.</em>
              </h2>
            </div>
            <div className="section-aside">
              <p>
                Coding, reasoning, atau multimodal.
                <br />
                Pilih model terbaik untuk setiap ide,
                <br />
                tanpa memulai integrasi dari nol.
              </p>
            </div>
          </div>
          <div className="catalog-toolbar">
            <div className="category-tabs" aria-label="Filter kategori model">
              {categories.map((item) => (
                <button
                  key={item}
                  className={category === item ? "active" : ""}
                  onClick={() => {
                    setCategory(item);
                    setSelected(null);
                  }}
                  aria-pressed={category === item}
                >
                  {item}
                  {item === "All models" && <span>06</span>}
                </button>
              ))}
            </div>
            <label className="model-search">
              <svg
                viewBox="0 0 20 20"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.4"
                aria-hidden="true"
              >
                <circle cx="8.5" cy="8.5" r="5.5" />
                <path d="m13 13 4 4" />
              </svg>
              <input
                ref={searchInput}
                type="search"
                placeholder="Find a model…"
                aria-label="Cari model"
                value={query}
                onChange={(event) => {
                  setQuery(event.target.value);
                  setSelected(null);
                }}
              />
              <kbd>/</kbd>
            </label>
          </div>
          <div className="model-grid" key={`${category}-${query}-${expanded}`}>
            {visibleModels.map((model) => (
              <ModelCard
                key={model.id}
                model={model}
                index={models.indexOf(model)}
                selected={selected?.id === model.id}
                onSelect={() => selectModel(model)}
              />
            ))}
          </div>
          {visibleModels.length === 0 && (
            <div className="empty-models" role="status">
              <span>No match. Yet.</span>
              <p>Coba nama provider atau kata kunci lain.</p>
              <button
                onClick={() => {
                  setQuery("");
                  setCategory("All models");
                }}
              >
                Reset pencarian <Arrow />
              </button>
            </div>
          )}
          {selected && (
            <div className="model-detail" id="model-detail" ref={detail}>
              <div>
                <span className="eyebrow">
                  A CLOSER LOOK / {selected.provider.toUpperCase()}
                </span>
                <h3>{selected.name}</h3>
                <p>{selected.detail}</p>
              </div>
              <div>
                <span className="mono micro">MODEL ID</span>
                <div className="model-id">
                  <code>{selected.id}</code>
                  <button
                    aria-label="Salin model ID"
                    onClick={() => copy(selected.id, "Model ID disalin.")}
                  >
                    <CopyIcon />
                  </button>
                </div>
                <span className="detail-disclaimer">
                  Ketersediaan inference menunggu konfigurasi gateway.
                </span>
              </div>
              <button
                className="close-detail"
                aria-label="Tutup detail model"
                onClick={() => setSelected(null)}
              >
                ×
              </button>
            </div>
          )}
          <div className="catalog-footer">
            <span className="mono">A CURATED CATALOG. NOT AN ENDORSEMENT.</span>
            <button
              onClick={() => {
                setExpanded(!expanded);
                setCategory("All models");
                setQuery("");
                setSelected(null);
              }}
              className="text-button"
            >
              {expanded ? "Show featured models" : "Explore all 6 models"}
              <Arrow diagonal />
            </button>
          </div>
        </section>

        <section id="why-aivon" className="why-section">
          <div className="section-shell">
            <div className="why-statement" data-reveal>
              <span className="eyebrow">
                <span>02</span> / STAY IN YOUR FLOW
              </span>
              <h2>
                Build your product. <br />
                <em>Not more integrations.</em>
              </h2>
              <p>
                Enam provider bukan berarti enam kali pekerjaan.
                <br />
                AIVON menyederhanakan titik mulainya.
              </p>
            </div>
            <div className="workbench" data-reveal>
              <div className="usecases">
                <div className="mono usecases-heading">
                  WHAT ARE YOU WORKING ON?
                </div>
                {routes.map((item, index) => (
                  <button
                    key={item.title}
                    className={`usecase ${route === index ? "active" : ""}`}
                    onClick={() => setRoute(index)}
                    aria-pressed={route === index}
                  >
                    <span className="usecase-number">0{index + 1}</span>
                    <div>
                      <span className="mono micro">{item.subtitle}</span>
                      <h3>{item.title}</h3>
                      {route === index && <p>{item.description}</p>}
                    </div>
                    <Arrow diagonal />
                  </button>
                ))}
              </div>
              <div className="routing-board">
                <div className="board-heading mono">
                  <span>ONE REQUEST. THE RIGHT DIRECTION.</span>
                  <span className="board-status">
                    <i /> ROUTE MAP
                  </span>
                </div>
                <div className="route-visual" key={route}>
                  <div className="request-node">
                    <span className="mono micro">YOUR APP</span>
                    <strong>{activeRoute.symbol}</strong>
                    <span>{activeRoute.use}</span>
                  </div>
                  <div className="route-wire wire-input">
                    <i />
                  </div>
                  <div className="aivon-node">
                    <Mark />
                    <span className="mono">AIVON</span>
                    <i />
                  </div>
                  <svg
                    className="route-branches"
                    viewBox="0 0 150 180"
                    fill="none"
                    aria-hidden="true"
                  >
                    <path
                      d="M0 90H35Q55 90 55 70V38Q55 20 75 20H150M0 90H35Q55 90 55 110V142Q55 160 75 160H150"
                      stroke="#b3bba4"
                    />
                    <path
                      className="route-traveler"
                      d="M0 90H35Q55 90 55 70V38Q55 20 75 20H150"
                      stroke="#667b4e"
                      strokeWidth="2"
                      strokeDasharray="7 150"
                    />
                    <circle
                      className="route-packet packet-primary"
                      r="4"
                      fill="#934aff"
                    />
                    <circle
                      className="route-packet packet-alternate"
                      r="3"
                      fill="#40b4c7"
                    />
                  </svg>
                  <div className="route-destinations">
                    <div className="route-destination" key={`${route}-primary`}>
                      <ProviderIcon provider={activeRoute.primary} />
                      <div>
                        <span className="mono micro">PRIMARY</span>
                        <strong>{activeRoute.primary}</strong>
                      </div>
                      <i />
                    </div>
                    <div
                      className="route-destination secondary"
                      key={`${route}-secondary`}
                    >
                      <ProviderIcon provider={activeRoute.secondary} />
                      <div>
                        <span className="mono micro">ALTERNATIVE</span>
                        <strong>{activeRoute.secondary}</strong>
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  className="request-cycle mono"
                  key={`cycle-${route}`}
                  aria-label="Rencana alur integrasi gateway"
                >
                  <span>
                    <b>01</b> REQUEST
                  </span>
                  <Arrow />
                  <span>
                    <b>02</b> MATCH
                  </span>
                  <Arrow />
                  <span>
                    <b>03</b> ROUTE
                  </span>
                </div>
                <div className="board-bottom mono">
                  <span>
                    <i /> ONE FAMILIAR REQUEST FORMAT
                  </span>
                  <span>GATEWAY NOT CONFIGURED</span>
                </div>
              </div>
            </div>
            <div className="principles">
              <div data-reveal>
                <span className="principle-icon">[ 01 ]</span>
                <h3>Less setup. More momentum.</h3>
                <p>
                  Format API yang familiar. Tidak harus belajar ulang setiap
                  kali ingin mencoba model lain.
                </p>
              </div>
              <div data-reveal>
                <span className="principle-icon">[ 02 ]</span>
                <h3>Different model. Same flow.</h3>
                <p>
                  Ubah pilihan model, bukan seluruh aplikasimu. Satu cara
                  terhubung, banyak cara membangun.
                </p>
              </div>
              <div data-reveal>
                <span className="principle-icon">[ 03 ]</span>
                <h3>Your stack. Your call.</h3>
                <p>
                  Gunakan bahasa dan tools pilihanmu. Gateway mengikuti caramu
                  bekerja, bukan sebaliknya.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="developer-section section-shell" id="developers">
          <div className="developer-copy" data-reveal>
            <span className="eyebrow">
              <span>03</span> / FROM HERE TO YOUR FIRST REQUEST
            </span>
            <h2>
              Familiar code.
              <br />
              <em>Unfamiliar potential.</em>
            </h2>
            <p>
              Sudah pakai format OpenAI?
              <br />
              Kamu sudah tahu sebagian besar caranya.
            </p>
            <div className="integration-steps">
              <div>
                <span>01</span>
                <p>
                  Set your endpoint.
                  <small>
                    Base URL tersedia setelah gateway dikonfigurasi.
                  </small>
                </p>
              </div>
              <div>
                <span>02</span>
                <p>
                  Pick your model.
                  <small>Pilih model yang sesuai dengan kebutuhanmu.</small>
                </p>
              </div>
              <div>
                <span>03</span>
                <p>
                  Build something worth building.
                  <small>Sisanya, milik imajinasimu.</small>
                </p>
              </div>
            </div>
            <a className="text-button" href="#integration-guide">
              Read the integration notes <Arrow diagonal />
            </a>
          </div>
          <div className="code-section" data-reveal>
            <div className="code-window">
              <div className="code-header">
                <div className="code-lights">
                  <i />
                  <i />
                  <i />
                </div>
                <span className="mono">
                  hello-aivon.{language === "JavaScript" ? "js" : "py"}
                </span>
                <span className="mono">QUICKSTART</span>
              </div>
              <div className="code-toolbar">
                <div>
                  {(Object.keys(snippets) as (keyof typeof snippets)[]).map(
                    (item) => (
                      <button
                        key={item}
                        onClick={() => setLanguage(item)}
                        className={language === item ? "active" : ""}
                        aria-pressed={language === item}
                      >
                        {item}
                      </button>
                    ),
                  )}
                </div>
                <button
                  className="copy-code"
                  onClick={() =>
                    copy(snippets[language], `${language} code copied.`)
                  }
                  aria-label="Salin contoh kode"
                >
                  <CopyIcon />
                  <span>Copy</span>
                </button>
              </div>
              <pre key={language}>
                <code>
                  {snippets[language].split("\n").map((line, index) => (
                    <span
                      className={`code-line ${line.includes("model") ? "highlight-line" : ""}`}
                      key={`${language}-${index}`}
                    >
                      <span className="line-number" aria-hidden="true">
                        {String(index + 1).padStart(2, "0")}
                      </span>
                      <span
                        className={
                          line.startsWith("import") ||
                          line.startsWith("from") ||
                          line.startsWith("const")
                            ? "code-keyword"
                            : ""
                        }
                      >
                        {line || " "}
                      </span>
                    </span>
                  ))}
                </code>
              </pre>
              <div className="code-note mono">
                <span>
                  <i /> ONE LINE TO SWITCH MODELS.
                </span>
                <span>THAT’S THE POINT.</span>
              </div>
            </div>
            <details className="integration-guide" id="integration-guide">
              <summary>
                Before your first request <span>+</span>
              </summary>
              <div>
                <p>
                  Gateway inference belum dikonfigurasi. Kode ini menunjukkan
                  format integrasi untuk endpoint yang nantinya diaktifkan.
                </p>
                <ol>
                  <li>
                    Pasang SDK OpenAI untuk JavaScript atau Python di project
                    server-mu.
                  </li>
                  <li>
                    Set <code>AIVON_BASE_URL</code> dan{" "}
                    <code>AIVON_API_KEY</code> pada environment server. Jangan
                    letakkan API key di browser.
                  </li>
                  <li>
                    Konfirmasi model ID dan dukungan gateway sebelum menjalankan
                    request. Akun dan API key dapat dikelola di dashboard;
                    inference dan pembayaran belum terhubung.
                  </li>
                </ol>
              </div>
            </details>
          </div>
        </section>

        <section className="faq-section section-shell">
          <div data-reveal>
            <span className="eyebrow">
              <span>04</span> / THE SMALL PRINT, SIMPLIFIED
            </span>
            <h2>
              A little clarity.
              <br />
              <em>A lot less guessing.</em>
            </h2>
          </div>
          <div className="faq-list">
            <details>
              <summary>
                Apa sebenarnya AIVON?<span>+</span>
              </summary>
              <p>
                AIVON adalah brand layanan gateway untuk menghubungkan aplikasi
                dengan berbagai keluarga model AI melalui satu format integrasi.
                AIVON bukan pembuat model-model tersebut.
              </p>
            </details>
            <details>
              <summary>
                Apakah saya harus mengubah aplikasi saya?<span>+</span>
              </summary>
              <p>
                Jika aplikasimu memakai format OpenAI, integrasi umumnya dimulai
                dari pengaturan base URL, API key, dan model ID. Tetap periksa
                fitur dan format input yang didukung model pilihanmu.
              </p>
            </details>
            <details>
              <summary>
                Bagaimana dengan harga dan ketersediaan model?<span>+</span>
              </summary>
              <p>
                Harga input dan output ditampilkan terpisah dalam USD per 1M
                token di Models & pricing. Tarif yang belum ditetapkan tidak
                dianggap gratis. Multiplier tetap tersedia untuk perhitungan
                kredit. Akun dan API key dapat dibuat, tetapi inference dan
                pembayaran belum dikonfigurasi.
              </p>
            </details>
            <details>
              <summary>
                Apakah AIVON terafiliasi dengan provider?<span>+</span>
              </summary>
              <p>
                AIVON adalah brand gateway independen. Nama model dan provider
                digunakan untuk menjelaskan ekosistem integrasi, bukan sebagai
                klaim afiliasi atau endorsement.
              </p>
            </details>
          </div>
        </section>

        <section className="closing page-shell" data-reveal>
          <div className="closing-inner">
            <div className="closing-top mono">
              <span>LESS FRICTION. MORE BUILDING.</span>
              <span>YOUR NEXT CHAPTER STARTS HERE ↗</span>
            </div>
            <div className="closing-content">
              <h2>
                Make room
                <br />
                for <em>what’s next.</em>
              </h2>
              <div>
                <p>
                  Ide berikutnya tidak akan membangun dirinya sendiri.
                  <br />
                  Temukan modelmu. Mulai dari sana.
                </p>
                <Link className="button button-light" href="/register">
                  Daftar akun AIVON <Arrow diagonal />
                </Link>
              </div>
            </div>
            <Mark className="closing-mark" />
          </div>
        </section>
      </main>
      <footer className="footer page-shell">
        <div className="footer-top">
          <a href="#" className="wordmark" aria-label="AIVON kembali ke atas">
            <Mark />
            <span>aivon</span>
            <sup>®</sup>
          </a>
          <span>
            Independent minds.
            <br />
            One common ground.
          </span>
          <div>
            <a href="#models">Models</a>
            <a href="#why-aivon">Why Aivon</a>
            <a href="#developers">
              Developers <Arrow diagonal />
            </a>
          </div>
          <a className="back-to-top" href="#" aria-label="Kembali ke atas">
            <Arrow />
          </a>
        </div>
        <div className="footer-word" aria-hidden="true">
          AIVON<span>®</span>
        </div>
        <div className="footer-bottom mono">
          <span>© 2026 AIVON. ALL POSSIBILITIES RESERVED.</span>
          <span>DESIGNED WITH INTENT. BUILT FOR BUILDERS.</span>
          <button
            disabled={reduced}
            onClick={() => setPaused(!paused)}
            aria-pressed={paused}
          >
            {paused ? "ENABLE MOTION" : "PAUSE MOTION"}
            <span>{paused ? "▷" : "Ⅱ"}</span>
          </button>
        </div>
      </footer>
      <button
        className="motion-dock"
        disabled={reduced}
        onClick={() => setPaused(!paused)}
        aria-label={paused ? "Aktifkan semua animasi" : "Jeda semua animasi"}
        aria-pressed={paused}
        title={
          reduced
            ? "Reduced motion mengikuti pengaturan perangkat"
            : "Kontrol animasi halaman"
        }
      >
        <i aria-hidden="true" />
        <i aria-hidden="true" />
        <i aria-hidden="true" />
        <span>
          {reduced ? "REDUCED MOTION" : paused ? "MOTION OFF" : "MOTION ON"}
        </span>
      </button>
      <div className={`toast ${toast ? "toast-visible" : ""}`} role="status">
        {toast}
      </div>
    </div>
  );
}
