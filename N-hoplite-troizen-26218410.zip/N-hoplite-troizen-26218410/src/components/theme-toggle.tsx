"use client";

import { useEffect, useRef, useState } from "react";
import { storedTheme, themeStorageKey, type Theme } from "@/lib/theme";

export default function ThemeToggle() {
  const [theme, setTheme] = useState<Theme | null>(null);
  const preference = useRef<Theme | null>(null);

  useEffect(() => {
    const media = matchMedia("(prefers-color-scheme: dark)");
    preference.current = storedTheme();
    function sync() {
      const next = preference.current ?? (media.matches ? "dark" : "light");
      document.documentElement.dataset.theme = next;
      setTheme(next);
    }
    function storage(event: StorageEvent) {
      if (event.key !== themeStorageKey && event.key !== null) return;
      preference.current = storedTheme();
      sync();
    }
    sync();
    media.addEventListener("change", sync);
    window.addEventListener("storage", storage);
    return () => {
      media.removeEventListener("change", sync);
      window.removeEventListener("storage", storage);
    };
  }, []);

  function toggle() {
    const next = theme === "dark" ? "light" : "dark";
    preference.current = next;
    document.documentElement.dataset.theme = next;
    setTheme(next);
    try {
      localStorage.setItem(themeStorageKey, next);
    } catch {
      /* Keep the current-page choice when storage is unavailable. */
    }
  }

  return (
    <button
      className="theme-toggle"
      type="button"
      role="switch"
      aria-label="Mode hitam"
      aria-checked={theme === "dark"}
      disabled={theme === null}
      onClick={toggle}
      title={theme === "dark" ? "Gunakan mode putih" : "Gunakan mode hitam"}
    >
      <svg
        className="theme-sun"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.6"
        aria-hidden="true"
      >
        <circle cx="12" cy="12" r="3.7" />
        <path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5" />
      </svg>
      <svg
        className="theme-moon"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.6"
        aria-hidden="true"
      >
        <path d="M20 14.6A8.5 8.5 0 0 1 9.4 4a8.5 8.5 0 1 0 10.6 10.6Z" />
      </svg>
    </button>
  );
}
