"use client";

import { useEffect, useRef } from "react";

export function ScrollProgress() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    let frame = 0;
    function update() {
      frame = 0;
      const distance = document.documentElement.scrollHeight - innerHeight;
      ref.current?.style.setProperty(
        "--progress",
        String(distance > 0 ? Math.max(0, Math.min(1, scrollY / distance)) : 0),
      );
    }
    function schedule() {
      if (!frame) frame = requestAnimationFrame(update);
    }
    function tabVisibility() {
      document.documentElement.dataset.tabVisible = String(!document.hidden);
    }
    const observer = new ResizeObserver(schedule);
    observer.observe(document.body);
    const visibility = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          (entry.target as HTMLElement).dataset.motionVisible = String(
            entry.isIntersecting,
          );
        });
      },
      { rootMargin: "80px" },
    );
    document
      .querySelectorAll(
        ".hero, .provider-belt, .workbench, .code-window, .closing",
      )
      .forEach((element) => visibility.observe(element));
    window.addEventListener("scroll", schedule, { passive: true });
    window.addEventListener("resize", schedule);
    document.addEventListener("visibilitychange", tabVisibility);
    tabVisibility();
    update();
    return () => {
      cancelAnimationFrame(frame);
      observer.disconnect();
      visibility.disconnect();
      window.removeEventListener("scroll", schedule);
      window.removeEventListener("resize", schedule);
      document.removeEventListener("visibilitychange", tabVisibility);
      delete document.documentElement.dataset.tabVisible;
    };
  }, []);
  return <div ref={ref} className="scroll-progress" aria-hidden="true" />;
}

export function useCardSpotlight(paused: boolean) {
  useEffect(() => {
    if (paused || !matchMedia("(hover: hover) and (pointer: fine)").matches)
      return;
    let frame = 0;
    let active: HTMLElement | null = null;
    let x = 0,
      y = 0;
    function clear() {
      active?.style.removeProperty("--spot-x");
      active?.style.removeProperty("--spot-y");
      active = null;
    }
    function move(event: PointerEvent) {
      const card =
        event.target instanceof Element
          ? event.target.closest<HTMLElement>(".model-card")
          : null;
      if (card !== active) {
        clear();
        active = card;
      }
      if (!card) return;
      x = event.clientX;
      y = event.clientY;
      if (!frame)
        frame = requestAnimationFrame(() => {
          frame = 0;
          if (!active) return;
          const rect = active.getBoundingClientRect();
          active.style.setProperty("--spot-x", `${x - rect.left}px`);
          active.style.setProperty("--spot-y", `${y - rect.top}px`);
        });
    }
    document.addEventListener("pointermove", move, { passive: true });
    document.addEventListener("pointerleave", clear);
    return () => {
      cancelAnimationFrame(frame);
      clear();
      document.removeEventListener("pointermove", move);
      document.removeEventListener("pointerleave", clear);
    };
  }, [paused]);
}
