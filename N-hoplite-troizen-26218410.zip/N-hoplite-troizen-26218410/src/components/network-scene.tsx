"use client";

import { useEffect, useRef } from "react";

export default function NetworkScene({ paused }: { paused: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const pausedRef = useRef(paused);
  useEffect(() => {
    pausedRef.current = paused;
  }, [paused]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const context = canvas?.getContext("2d");
    if (!canvas || !context) return;
    let width = 0;
    let height = 0;
    let time = 0;
    let last = 0;
    let frame = 0;
    let visible = true;
    let dirty = true;
    let dark = document.documentElement.dataset.theme === "dark";
    const pointer = { x: 0, y: 0 };
    const smooth = { x: 0, y: 0 };
    const random = (seed: number) => {
      const x = Math.sin(seed * 127.1 + 311.7) * 43758.5453;
      return x - Math.floor(x);
    };
    const particles = Array.from({ length: 780 }, (_, index) => ({
      theta: random(index + 1) * Math.PI * 2,
      phi: Math.acos(2 * random(index + 800) - 1),
      size: 0.7 + random(index + 1600) * 1.3,
      color: index % 13 === 0 ? "violet" : index % 19 === 0 ? "cyan" : "gray",
    }));

    function draw() {
      if (!context) return;
      context.clearRect(0, 0, width, height);
      const mobile = width < 650;
      const centerX = width * (mobile ? 0.77 : 0.8) + smooth.x * 15;
      const centerY = height * (mobile ? 0.3 : 0.41) + smooth.y * 15;
      const radius = Math.min(width * (mobile ? 0.48 : 0.205), height * 0.43);
      const angle = time * 0.16 + smooth.x * 0.3;

      // Project a rotating point cloud into perspective, without requiring a GPU.
      const projected = particles
        .map((particle) => {
          const x = Math.sin(particle.phi) * Math.cos(particle.theta);
          const y = Math.cos(particle.phi);
          const z = Math.sin(particle.phi) * Math.sin(particle.theta);
          const rx = x * Math.cos(angle) - z * Math.sin(angle);
          const rz = x * Math.sin(angle) + z * Math.cos(angle);
          const tilt = -0.3 + smooth.y * 0.1;
          const ry = y * Math.cos(tilt) - rz * Math.sin(tilt);
          const depth = y * Math.sin(tilt) + rz * Math.cos(tilt);
          const perspective = 3 / (3 - depth * 0.7);
          return {
            x: centerX + rx * radius * perspective,
            y: centerY + ry * radius * perspective,
            depth,
            size: particle.size * perspective,
            color: particle.color,
          };
        })
        .sort((a, b) => a.depth - b.depth);
      for (const point of projected) {
        const opacity = (point.depth + 1.5) / 3.3;
        context.fillStyle =
          point.color === "violet"
            ? `rgba(123,62,244,${opacity * 0.85})`
            : point.color === "cyan"
              ? `rgba(51,172,192,${opacity * 0.75})`
              : `rgba(${dark ? "181,169,207" : "89,92,112"},${opacity * 0.55})`;
        context.fillRect(point.x, point.y, point.size, point.size);
      }

      for (let band = 0; band < 27; band++) {
        context.beginPath();
        for (let step = 0; step <= 90; step++) {
          const t = step / 90;
          const x = width * (0.13 + t * 0.94);
          const y =
            height * 0.92 -
            Math.pow(t, 0.85) * height * 0.91 +
            Math.sin(t * 6 + band * 0.14 + time * 0.055) * height * 0.13 +
            band * 3.6;
          if (step === 0) context.moveTo(x, y);
          else context.lineTo(x, y);
        }
        context.strokeStyle =
          band % 7 === 0
            ? `rgba(158,114,230,${dark ? ".18" : ".07"})`
            : `rgba(147,150,166,${dark ? ".14" : ".065"})`;
        context.lineWidth = 0.6;
        context.stroke();
        for (let streak = 0; streak < 5; streak++) {
          const t =
            (random(band * 29 + streak + 2700) +
              time * (0.05 + band * 0.0005)) %
            1;
          const t2 = Math.min(t + 0.018, 1);
          const path = (v: number) => ({
            x: width * (0.13 + v * 0.94),
            y:
              height * 0.92 -
              Math.pow(v, 0.85) * height * 0.91 +
              Math.sin(v * 6 + band * 0.14 + time * 0.055) * height * 0.13 +
              band * 3.6,
          });
          const a = path(t),
            b = path(t2);
          context.beginPath();
          context.moveTo(a.x, a.y);
          context.lineTo(b.x, b.y);
          context.strokeStyle =
            band % 5 === 0
              ? "rgba(127,64,243,.7)"
              : band % 9 === 0
                ? "rgba(40,184,204,.45)"
                : dark
                  ? "rgba(180,168,214,.35)"
                  : "rgba(100,104,124,.16)";
          context.lineWidth = 0.8;
          context.stroke();
        }
      }
      for (let ring = 0; ring < 3; ring++) {
        context.save();
        context.translate(centerX, centerY);
        context.rotate(-0.65 + ring * 0.58 + time * 0.012);
        context.beginPath();
        context.ellipse(
          0,
          0,
          radius * (1.17 + ring * 0.09),
          radius * 0.36,
          0,
          0,
          Math.PI * 2,
        );
        context.strokeStyle =
          ring === 1 ? "rgba(129,69,239,.14)" : "rgba(119,122,143,.1)";
        context.lineWidth = 0.7;
        context.stroke();
        const orbitAngle = time * 0.6 + ring * 2.3;
        context.fillStyle = ring === 1 ? "#9256ef" : "#828ba1";
        context.beginPath();
        context.arc(
          Math.cos(orbitAngle) * radius * (1.17 + ring * 0.09),
          Math.sin(orbitAngle) * radius * 0.36,
          3.5,
          0,
          Math.PI * 2,
        );
        context.fill();
        context.restore();
      }
    }
    function resize() {
      if (!canvas || !context) return;
      const rect = canvas.getBoundingClientRect();
      width = rect.width;
      height = rect.height;
      const ratio = Math.min(devicePixelRatio, 1.5);
      canvas.width = width * ratio;
      canvas.height = height * ratio;
      context.setTransform(ratio, 0, 0, ratio, 0, 0);
      dirty = true;
      draw();
    }
    function move(event: PointerEvent) {
      const rect = canvas!.getBoundingClientRect();
      pointer.x = (event.clientX - rect.left) / rect.width - 0.5;
      pointer.y = (event.clientY - rect.top) / rect.height - 0.5;
    }
    function leave() {
      pointer.x = 0;
      pointer.y = 0;
    }
    const parent = canvas.parentElement!;
    parent.addEventListener("pointermove", move);
    parent.addEventListener("pointerleave", leave);
    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(canvas);
    const themeObserver = new MutationObserver(() => {
      dark = document.documentElement.dataset.theme === "dark";
      dirty = true;
      draw();
    });
    themeObserver.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["data-theme"],
    });
    const intersection = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
    });
    intersection.observe(canvas);
    function animate(timestamp: number) {
      frame = requestAnimationFrame(animate);
      if (timestamp - last < 32) return;
      const delta = Math.min((timestamp - last) / 1000, 0.08);
      last = timestamp;
      if (!visible || document.hidden) return;
      if (pausedRef.current && !dirty) return;
      if (!pausedRef.current) {
        time += delta;
        smooth.x += (pointer.x - smooth.x) * 0.045;
        smooth.y += (pointer.y - smooth.y) * 0.045;
      }
      draw();
      dirty = false;
    }
    resize();
    frame = requestAnimationFrame(animate);
    return () => {
      cancelAnimationFrame(frame);
      resizeObserver.disconnect();
      themeObserver.disconnect();
      intersection.disconnect();
      parent.removeEventListener("pointermove", move);
      parent.removeEventListener("pointerleave", leave);
    };
  }, []);
  return (
    <canvas
      ref={canvasRef}
      className="network-canvas"
      role="img"
      aria-label="Jaringan partikel 3D dengan aliran data dan orbit provider"
      data-renderer="canvas-3d"
    />
  );
}
