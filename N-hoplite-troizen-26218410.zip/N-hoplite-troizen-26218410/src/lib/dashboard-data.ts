import { models as landingModels } from "./models";

export const dashboardModels = landingModels.map((model, index) => ({
  ...model,
  context: ["200K", "400K", "1M", "128K", "128K", "128K"][index],
  multiplier: [2.5, 2, 1.5, 0.5, 0.8, 0.6][index],
  inputPricePerMillion: null as number | null,
  outputPricePerMillion: null as number | null,
}));
export type DashboardModel = (typeof dashboardModels)[number];
export type ApiKey = {
  id: string;
  name: string;
  suffix: string;
  status: "active" | "revoked";
  limit: number;
  createdAt: string;
  expiresAt: string | null;
};
export type Notification = {
  id: string;
  title: string;
  body: string;
  read: boolean;
  href: string;
  createdAt: string;
};
export type Profile = {
  name: string;
  email: string;
  workspace: string;
  timezone: string;
  role: string;
  usageAlerts: boolean;
  productUpdates: boolean;
};
export type UsageRecord = {
  id: string;
  timestamp: string;
  modelId: string;
  keyId: string;
  input: number;
  output: number;
  billed: number;
  latency: number;
  status: "success" | "error";
};

export type WorkspaceState = {
  authenticated: boolean;
  profile: Profile;
  keys: ApiKey[];
  notifications: Notification[];
  favorites: string[];
  usage: UsageRecord[];
};

export function emptyWorkspace(): WorkspaceState {
  return {
    authenticated: false,
    profile: {
      name: "Guest",
      email: "",
      workspace: "Guest workspace",
      timezone: "Asia/Jakarta",
      role: "Developer",
      usageAlerts: true,
      productUpdates: false,
    },
    keys: [],
    notifications: [],
    favorites: [],
    usage: [],
  };
}

function validateTokens(input: number, output: number) {
  if (
    ![input, output].every(
      (value) =>
        Number.isSafeInteger(value) && value >= 0 && value <= 1_000_000_000,
    )
  )
    throw new RangeError(
      "Token counts must be whole numbers between 0 and 1B.",
    );
}

export function calculateModelCost(
  model: DashboardModel,
  input: number,
  output: number,
) {
  validateTokens(input, output);
  if (
    model.inputPricePerMillion === null ||
    model.outputPricePerMillion === null
  )
    return null;
  return (
    (input * model.inputPricePerMillion +
      output * model.outputPricePerMillion) /
    1_000_000
  );
}

export function calculateCredits(
  model: DashboardModel,
  input: number,
  output: number,
) {
  validateTokens(input, output);
  return Math.ceil((input + output) * model.multiplier);
}

export const formatNumber = (value: number) =>
  new Intl.NumberFormat("en-US").format(value);
export function formatTokens(value: number) {
  return value >= 1_000_000
    ? `${Number((value / 1_000_000).toFixed(2))}M`
    : value >= 1000
      ? `${Number((value / 1000).toFixed(1))}K`
      : String(value);
}
export function formatDate(value: string, withTime = false) {
  return new Intl.DateTimeFormat("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    ...(withTime ? { hour: "2-digit", minute: "2-digit" } : {}),
    timeZone: "UTC",
  }).format(new Date(value));
}
export function modelById(id: string) {
  return dashboardModels.find((model) => model.id === id) ?? dashboardModels[0];
}
export function usageSummary(records: UsageRecord[]) {
  const successful = records.filter((record) => record.status === "success");
  return {
    requests: records.length,
    tokens: records.reduce((sum, record) => sum + record.billed, 0),
    input: records.reduce((sum, record) => sum + record.input, 0),
    output: records.reduce((sum, record) => sum + record.output, 0),
    success: records.length ? (successful.length / records.length) * 100 : 0,
    latency: successful.length
      ? Math.round(
          successful.reduce((sum, record) => sum + record.latency, 0) /
            successful.length,
        )
      : 0,
  };
}
export function dailyUsage(days: number, records: UsageRecord[] = []) {
  const midnight = new Date();
  midnight.setUTCHours(0, 0, 0, 0);
  return Array.from({ length: days }, (_, index) => {
    const dayAgo = days - index - 1;
    const start = midnight.getTime() - dayAgo * 86400000;
    const rows = records.filter(
      (record) =>
        Date.parse(record.timestamp) >= start &&
        Date.parse(record.timestamp) < start + 86400000,
    );
    return {
      dayAgo,
      label: new Intl.DateTimeFormat("en-GB", {
        day: "numeric",
        month: "short",
        timeZone: "UTC",
      }).format(new Date(midnight.getTime() - dayAgo * 86400000)),
      ...usageSummary(rows),
    };
  });
}

export function downloadText(
  filename: string,
  text: string,
  type = "text/plain",
) {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
export function csvCell(value: string | number) {
  const text = String(value);
  const safe = /^[=+@\-\t\r]/.test(text) ? `'${text}` : text;
  return `"${safe.replaceAll('"', '""')}"`;
}
