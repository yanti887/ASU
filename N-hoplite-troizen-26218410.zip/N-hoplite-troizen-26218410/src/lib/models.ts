export type Model = {
  name: string;
  provider: string;
  id: string;
  category: "Reasoning" | "Coding" | "Multimodal";
  label: string;
  description: string;
  detail: string;
  color: string;
};

export const models: Model[] = [
  {
    name: "Claude Sonnet",
    provider: "Anthropic",
    id: "anthropic/claude-sonnet-4",
    category: "Coding",
    label: "THE BUILDER",
    description: "A thoughtful partner for your next big build.",
    detail:
      "Untuk menulis dan meninjau kode, menyusun dokumen, serta mengembangkan ide dengan konteks yang terstruktur.",
    color: "#b67759",
  },
  {
    name: "GPT",
    provider: "OpenAI",
    id: "openai/gpt-5",
    category: "Reasoning",
    label: "THE ALL-ROUNDER",
    description: "From a blank page to a better answer.",
    detail:
      "Keluarga model serbaguna untuk penalaran, percakapan, dan tugas sehari-hari dalam aplikasi.",
    color: "#607761",
  },
  {
    name: "Gemini Pro",
    provider: "Google",
    id: "google/gemini-2.5-pro",
    category: "Multimodal",
    label: "THE BIG PICTURE",
    description: "A different perspective. A wider possibility.",
    detail:
      "Untuk mengeksplorasi input multimodal dan penalaran. Dukungan format bergantung pada model dan konfigurasi gateway.",
    color: "#688398",
  },
  {
    name: "DeepSeek R1",
    provider: "DeepSeek",
    id: "deepseek/deepseek-r1",
    category: "Reasoning",
    label: "THE DEEP THINKER",
    description: "Make room for the more difficult questions.",
    detail:
      "Model berorientasi penalaran untuk mengeksplorasi masalah logika dan tugas analitis bertahap.",
    color: "#597ab0",
  },
  {
    name: "Mistral Large",
    provider: "Mistral",
    id: "mistralai/mistral-large",
    category: "Coding",
    label: "THE POLYGLOT",
    description: "Built for ideas that cross borders.",
    detail:
      "Pilihan untuk aplikasi multibahasa, pengolahan teks, dan alur kerja pengembangan perangkat lunak.",
    color: "#a97e42",
  },
  {
    name: "Llama",
    provider: "Meta",
    id: "meta-llama/llama-4",
    category: "Multimodal",
    label: "THE OPEN MIND",
    description: "Open up a new way of looking at things.",
    detail:
      "Keluarga model dari ekosistem terbuka. Periksa varian model, lisensi, dan dukungan gateway sebelum integrasi.",
    color: "#637996",
  },
];

export const snippets = {
  JavaScript: `import OpenAI from "openai";\n\nconst aivon = new OpenAI({\n  baseURL: process.env.AIVON_BASE_URL,\n  apiKey: process.env.AIVON_API_KEY,\n});\n\nconst answer = await aivon.chat.completions.create({\n  model: "anthropic/claude-sonnet-4",\n  messages: [{ role: "user", content: "What's next?" }],\n});`,
  Python: `import os\nfrom openai import OpenAI\n\naivon = OpenAI(\n    base_url=os.environ["AIVON_BASE_URL"],\n    api_key=os.environ["AIVON_API_KEY"],\n)\n\nanswer = aivon.chat.completions.create(\n    model="anthropic/claude-sonnet-4",\n    messages=[{"role": "user", "content": "What's next?"}],\n)`,
};
