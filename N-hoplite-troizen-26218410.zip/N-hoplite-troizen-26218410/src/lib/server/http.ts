export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    public retryAfter?: number,
  ) {
    super(message);
  }
}

export function json(value: unknown, status = 200, headers?: HeadersInit) {
  const result = new Headers(headers);
  result.set("Cache-Control", "private, no-store, max-age=0");
  result.set("Vary", "Cookie, Origin");
  result.set("X-Content-Type-Options", "nosniff");
  return Response.json(value, { status, headers: result });
}

export async function respond(operation: () => Response | Promise<Response>) {
  try {
    return await operation();
  } catch (error) {
    if (error instanceof ApiError) {
      return json(
        { error: error.message },
        error.status,
        error.retryAfter
          ? { "Retry-After": String(error.retryAfter) }
          : undefined,
      );
    }
    return json(
      { error: "The workspace is temporarily unavailable. Please try again." },
      503,
    );
  }
}

export function secureRequest(request: Request) {
  return (
    new URL(request.url).protocol === "https:" ||
    request.headers.get("x-forwarded-proto") === "https"
  );
}

export function sameOrigin(request: Request) {
  const rawOrigin = request.headers.get("origin");
  const host = request.headers.get("host");
  if (
    !rawOrigin ||
    !host ||
    request.headers.get("sec-fetch-site") === "cross-site"
  ) {
    throw new ApiError(403, "This request must come from the same site.");
  }
  try {
    const origin = new URL(rawOrigin);
    const protocol = secureRequest(request) ? "https:" : "http:";
    // The actual Host, not a caller-controlled forwarded host, identifies the preview.
    if (
      /[\s,/@\\?#]/.test(host) ||
      origin.origin !== rawOrigin ||
      origin.protocol !== protocol ||
      origin.host !== new URL(`${protocol}//${host}`).host
    ) {
      throw new Error("Origin mismatch");
    }
  } catch {
    throw new ApiError(403, "This request must come from the same site.");
  }
}

export function object(value: unknown, label = "Request") {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new ApiError(400, `${label} must be a JSON object.`);
  }
  return value as Record<string, unknown>;
}

export function text(value: unknown, label: string, min: number, max: number) {
  if (typeof value !== "string")
    throw new ApiError(400, `${label} is required.`);
  const result = value.trim();
  if (
    result.length < min ||
    result.length > max ||
    /[\u0000-\u001f\u007f]/.test(result)
  ) {
    throw new ApiError(
      400,
      `${label} must contain ${min}–${max} characters without control characters.`,
    );
  }
  return result;
}

export async function body(request: Request) {
  const maxBytes = 16 * 1024;
  const length = request.headers.get("content-length");
  if (length && (!/^\d+$/.test(length) || Number(length) > maxBytes)) {
    throw new ApiError(413, "Request body must not exceed 16 KB.");
  }
  if (
    request.headers.get("content-type")?.split(";")[0].trim().toLowerCase() !==
    "application/json"
  ) {
    throw new ApiError(415, "Send this request as application/json.");
  }
  if (!request.body)
    throw new ApiError(400, "A JSON request body is required.");
  const reader = request.body.getReader();
  const chunks: Uint8Array[] = [];
  let size = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > maxBytes) {
        await reader.cancel();
        throw new ApiError(413, "Request body must not exceed 16 KB.");
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  try {
    return object(
      JSON.parse(
        new TextDecoder("utf-8", { fatal: true }).decode(Buffer.concat(chunks)),
      ),
    );
  } catch (error) {
    if (error instanceof ApiError) throw error;
    throw new ApiError(400, "The request contains invalid JSON.");
  }
}
