import { randomBytes, randomUUID } from "node:crypto";
import {
  emptyWorkspace,
  dashboardModels,
  type ApiKey,
  type Notification,
  type Profile,
  type WorkspaceState,
} from "@/lib/dashboard-data";
import { database, transaction } from "./database";
import { digest, rateLimit } from "./auth";
import { ApiError, object, text } from "./http";

export function workspace(id: string | null): WorkspaceState {
  if (!id) return emptyWorkspace();
  const db = database();
  const row = db
    .prepare(
      "SELECT name, email, workspace, timezone, role, usage_alerts, product_updates FROM accounts WHERE id = ?",
    )
    .get(id);
  if (!row) throw new ApiError(401, "Sign in to manage your workspace.");
  const profile: Profile = {
    name: String(row.name),
    email: String(row.email),
    workspace: String(row.workspace),
    timezone: String(row.timezone),
    role: String(row.role),
    usageAlerts: Boolean(row.usage_alerts),
    productUpdates: Boolean(row.product_updates),
  };
  const keys: ApiKey[] = db
    .prepare(
      `SELECT id, name, suffix, status, token_limit, created_at, expires_at
    FROM api_keys WHERE account_id = ? ORDER BY created_at DESC, id`,
    )
    .all(id)
    .map((key) => ({
      id: String(key.id),
      name: String(key.name),
      suffix: String(key.suffix),
      status: key.status === "revoked" ? "revoked" : "active",
      limit: Number(key.token_limit),
      createdAt: String(key.created_at),
      expiresAt: key.expires_at === null ? null : String(key.expires_at),
    }));
  const notifications: Notification[] = db
    .prepare(
      `SELECT id, title, body, is_read, href, created_at
    FROM notifications WHERE account_id = ? ORDER BY created_at DESC, id LIMIT 40`,
    )
    .all(id)
    .map((note) => ({
      id: String(note.id),
      title: String(note.title),
      body: String(note.body),
      read: Boolean(note.is_read),
      href: String(note.href),
      createdAt: String(note.created_at),
    }));
  return {
    ...emptyWorkspace(),
    authenticated: true,
    profile,
    keys,
    notifications,
    favorites: db
      .prepare(
        "SELECT model_id FROM favorites WHERE account_id = ? ORDER BY model_id",
      )
      .all(id)
      .map((row) => String(row.model_id)),
  };
}

function notification(id: string, title: string, message: string) {
  const db = database();
  db.prepare(
    "INSERT INTO notifications (id, account_id, title, body, href, created_at) VALUES (?, ?, ?, ?, ?, ?)",
  ).run(
    randomUUID(),
    id,
    title,
    message,
    "/dashboard/api-keys",
    new Date().toISOString(),
  );
  db.prepare(
    `DELETE FROM notifications WHERE account_id = ? AND id NOT IN
    (SELECT id FROM notifications WHERE account_id = ? ORDER BY created_at DESC, id LIMIT 40)`,
  ).run(id, id);
}

function integer(value: unknown, label: string, maximum: number) {
  if (
    typeof value !== "number" ||
    !Number.isSafeInteger(value) ||
    value < 0 ||
    value > maximum
  ) {
    throw new ApiError(
      400,
      `${label} must be a whole number from 0 to ${maximum}.`,
    );
  }
  return value;
}

function updateProfile(id: string, input: unknown) {
  const profile = object(input, "Profile");
  const name = text(profile.name, "Name", 2, 64);
  const workspaceName = text(profile.workspace, "Workspace name", 2, 64);
  const timezone = text(profile.timezone, "Timezone", 1, 64);
  try {
    new Intl.DateTimeFormat("en", { timeZone: timezone }).format();
  } catch {
    throw new ApiError(400, "Choose a valid timezone.");
  }
  if (
    typeof profile.role !== "string" ||
    !["Developer", "Designer", "Founder", "Viewer"].includes(profile.role)
  ) {
    throw new ApiError(400, "Choose a valid profile role.");
  }
  if (
    typeof profile.usageAlerts !== "boolean" ||
    typeof profile.productUpdates !== "boolean"
  ) {
    throw new ApiError(400, "Preferences must be true or false.");
  }
  const account = database()
    .prepare("SELECT email FROM accounts WHERE id = ?")
    .get(id);
  if (!account) throw new ApiError(401, "Sign in to manage your workspace.");
  if (profile.email !== account.email)
    throw new ApiError(400, "Your sign-in email cannot be changed here.");
  database()
    .prepare(
      `UPDATE accounts SET name = ?, workspace = ?, timezone = ?, role = ?, usage_alerts = ?, product_updates = ?
    WHERE id = ?`,
    )
    .run(
      name,
      workspaceName,
      timezone,
      profile.role,
      Number(profile.usageAlerts),
      Number(profile.productUpdates),
      id,
    );
}

export function mutateWorkspace(id: string, data: Record<string, unknown>) {
  rateLimit([{ bucket: `workspace:${id}`, max: 120, seconds: 60 }]);
  return transaction((db) => {
    let token: string | undefined;
    switch (data.action) {
      case "createKey": {
        const name = text(data.name, "Key name", 1, 48);
        const limit = integer(data.limit, "Token limit", 1_000_000_000);
        const expiryDays = integer(data.expiryDays, "Expiry days", 365);
        const count = db
          .prepare(
            "SELECT COUNT(*) AS count FROM api_keys WHERE account_id = ?",
          )
          .get(id);
        if (Number(count?.count) >= 100)
          throw new ApiError(
            409,
            "This workspace has reached its 100-key limit.",
          );
        token = `aivon_${randomBytes(32).toString("base64url")}`;
        const now = Date.now();
        db.prepare(
          `INSERT INTO api_keys (id, account_id, name, token_hash, suffix, status, token_limit, created_at, expires_at)
          VALUES (?, ?, ?, ?, ?, 'active', ?, ?, ?)`,
        ).run(
          randomUUID(),
          id,
          name,
          digest(token),
          token.slice(-4),
          limit,
          new Date(now).toISOString(),
          expiryDays
            ? new Date(now + expiryDays * 86400000).toISOString()
            : null,
        );
        notification(
          id,
          "API key created",
          `${name} was created. Keep its token private; it cannot be shown again.`,
        );
        break;
      }
      case "revokeKey": {
        const keyId = text(data.id, "Key ID", 1, 64);
        const key = db
          .prepare(
            "SELECT name, status FROM api_keys WHERE id = ? AND account_id = ?",
          )
          .get(keyId, id);
        if (!key)
          throw new ApiError(404, "API key not found in your workspace.");
        if (key.status !== "revoked") {
          db.prepare(
            "UPDATE api_keys SET status = 'revoked' WHERE id = ? AND account_id = ?",
          ).run(keyId, id);
          notification(
            id,
            "API key revoked",
            `${String(key.name)} was revoked.`,
          );
        }
        break;
      }
      case "profile":
        updateProfile(id, data.profile);
        break;
      case "favorite": {
        const modelId = text(data.id, "Model ID", 1, 128);
        if (!dashboardModels.some((model) => model.id === modelId))
          throw new ApiError(400, "Choose a model from the catalog.");
        const removed = db
          .prepare(
            "DELETE FROM favorites WHERE account_id = ? AND model_id = ?",
          )
          .run(id, modelId);
        if (!removed.changes)
          db.prepare(
            "INSERT INTO favorites (account_id, model_id) VALUES (?, ?)",
          ).run(id, modelId);
        break;
      }
      case "markRead": {
        if (data.id === undefined) {
          db.prepare(
            "UPDATE notifications SET is_read = 1 WHERE account_id = ?",
          ).run(id);
        } else {
          const noteId = text(data.id, "Notification ID", 1, 64);
          const changed = db
            .prepare(
              "UPDATE notifications SET is_read = 1 WHERE id = ? AND account_id = ?",
            )
            .run(noteId, id);
          if (!changed.changes)
            throw new ApiError(
              404,
              "Notification not found in your workspace.",
            );
        }
        break;
      }
      default:
        throw new ApiError(400, "Unknown workspace action.");
    }
    return { state: workspace(id), ...(token ? { token } : {}) };
  });
}
