import "./check-runtime.mjs";
import { chmodSync, closeSync, constants, mkdirSync, openSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { DatabaseSync } from "node:sqlite";

const connections = globalThis as typeof globalThis & {
  aivonDatabases?: Map<string, DatabaseSync>;
};

export function database() {
  // Deployment chooses the durable volume path at runtime.
  const path = resolve(
    /* turbopackIgnore: true */ process.env.AIVON_DB_PATH ||
      ".data/aivon.sqlite",
  );
  const cached = connections.aivonDatabases?.get(path);
  if (cached) return cached;

  mkdirSync(dirname(path), { recursive: true, mode: 0o700 });
  const file = openSync(
    /* turbopackIgnore: true */ path,
    constants.O_CREAT | constants.O_RDWR | constants.O_NOFOLLOW,
    0o600,
  );
  closeSync(file);
  chmodSync(path, 0o600);
  const db = new DatabaseSync(path);
  db.exec(`
    PRAGMA busy_timeout = 5000;
    PRAGMA foreign_keys = ON;
    PRAGMA journal_mode = WAL;
    CREATE TABLE IF NOT EXISTS accounts (
      id TEXT PRIMARY KEY,
      email TEXT NOT NULL UNIQUE COLLATE NOCASE,
      password_hash TEXT NOT NULL,
      name TEXT NOT NULL,
      workspace TEXT NOT NULL DEFAULT 'Personal workspace',
      timezone TEXT NOT NULL DEFAULT 'Asia/Jakarta',
      role TEXT NOT NULL DEFAULT 'Developer',
      usage_alerts INTEGER NOT NULL DEFAULT 1 CHECK (usage_alerts IN (0, 1)),
      product_updates INTEGER NOT NULL DEFAULT 0 CHECK (product_updates IN (0, 1)),
      created_at TEXT NOT NULL
    ) STRICT;
    CREATE TABLE IF NOT EXISTS sessions (
      token_hash TEXT PRIMARY KEY,
      account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
      created_at INTEGER NOT NULL,
      expires_at INTEGER NOT NULL
    ) STRICT;
    CREATE INDEX IF NOT EXISTS sessions_account ON sessions(account_id);
    CREATE INDEX IF NOT EXISTS sessions_expiry ON sessions(expires_at);
    CREATE TABLE IF NOT EXISTS api_keys (
      id TEXT PRIMARY KEY,
      account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      token_hash TEXT NOT NULL UNIQUE,
      suffix TEXT NOT NULL,
      status TEXT NOT NULL CHECK (status IN ('active', 'revoked')),
      token_limit INTEGER NOT NULL CHECK (token_limit BETWEEN 0 AND 1000000000),
      created_at TEXT NOT NULL,
      expires_at TEXT
    ) STRICT;
    CREATE INDEX IF NOT EXISTS keys_account ON api_keys(account_id);
    CREATE TABLE IF NOT EXISTS notifications (
      id TEXT PRIMARY KEY,
      account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
      title TEXT NOT NULL,
      body TEXT NOT NULL,
      is_read INTEGER NOT NULL DEFAULT 0 CHECK (is_read IN (0, 1)),
      href TEXT NOT NULL,
      created_at TEXT NOT NULL
    ) STRICT;
    CREATE INDEX IF NOT EXISTS notifications_account ON notifications(account_id);
    CREATE TABLE IF NOT EXISTS favorites (
      account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
      model_id TEXT NOT NULL,
      PRIMARY KEY (account_id, model_id)
    ) STRICT;
    CREATE TABLE IF NOT EXISTS rate_limits (
      bucket TEXT PRIMARY KEY,
      attempts INTEGER NOT NULL,
      resets_at INTEGER NOT NULL
    ) STRICT;
    CREATE INDEX IF NOT EXISTS rate_limits_expiry ON rate_limits(resets_at);
  `);
  connections.aivonDatabases ??= new Map();
  connections.aivonDatabases.set(path, db);
  return db;
}

export function transaction<T>(operation: (db: DatabaseSync) => T): T {
  const db = database();
  db.exec("BEGIN IMMEDIATE");
  try {
    const result = operation(db);
    db.exec("COMMIT");
    return result;
  } catch (error) {
    db.exec("ROLLBACK");
    throw error;
  }
}
