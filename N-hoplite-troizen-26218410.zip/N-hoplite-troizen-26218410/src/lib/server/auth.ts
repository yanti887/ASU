import {
  createHash,
  randomBytes,
  randomUUID,
  scrypt,
  timingSafeEqual,
} from "node:crypto";
import { database, transaction } from "./database";
import { ApiError, secureRequest, text } from "./http";

export const SESSION_COOKIE = "aivon_session";
const sessionSeconds = 7 * 24 * 60 * 60;
const passwordOptions = { N: 131072, r: 8, p: 1, maxmem: 256 * 1024 * 1024 };
const unknownPasswordHash = `scrypt$131072$8$1$${"00".repeat(16)}$${"00".repeat(64)}`;
const work = globalThis as typeof globalThis & {
  aivonPasswordWork?: { active: number; waiting: (() => void)[] };
};

export function digest(value: string) {
  return createHash("sha256").update(value).digest("hex");
}

async function derive(password: string, salt: Buffer) {
  const queue = (work.aivonPasswordWork ??= { active: 0, waiting: [] });
  if (queue.active >= 2) {
    if (queue.waiting.length >= 8)
      throw new ApiError(503, "Sign-in is busy. Please try again shortly.", 2);
    await new Promise<void>((resolve) => queue.waiting.push(resolve));
  } else {
    queue.active++;
  }
  try {
    return await new Promise<Buffer>((resolve, reject) => {
      scrypt(password, salt, 64, passwordOptions, (error, key) => {
        if (error) reject(error);
        else resolve(key);
      });
    });
  } finally {
    const next = queue.waiting.shift();
    if (next) next();
    else queue.active--;
  }
}

async function passwordHash(password: string) {
  const salt = randomBytes(16);
  const key = await derive(password, salt);
  return `scrypt$131072$8$1$${salt.toString("hex")}$${key.toString("hex")}`;
}

async function verifyPassword(password: string, stored: string) {
  if (!/^scrypt\$131072\$8\$1\$[a-f0-9]{32}\$[a-f0-9]{128}$/.test(stored))
    return false;
  const parts = stored.split("$");
  const key = await derive(password, Buffer.from(parts[4], "hex"));
  return timingSafeEqual(key, Buffer.from(parts[5], "hex"));
}

function emailAddress(value: unknown) {
  const email = text(value, "Email", 3, 254).toLowerCase();
  if (
    !/^[^\s@]+@[^\s@.]+(?:\.[^\s@.]+)+$/.test(email) ||
    email.split("@")[0].length > 64
  ) {
    throw new ApiError(400, "Enter a valid email address.");
  }
  return email;
}

function passwordValue(value: unknown) {
  if (
    typeof value !== "string" ||
    value.length < 12 ||
    value.length > 128 ||
    Buffer.byteLength(value) > 512
  ) {
    throw new ApiError(400, "Password must contain 12–128 characters.");
  }
  return value;
}

export function rateLimit(
  limits: { bucket: string; max: number; seconds: number }[],
) {
  transaction((db) => {
    const now = Date.now();
    db.prepare("DELETE FROM rate_limits WHERE resets_at <= ?").run(now);
    for (const { bucket, max, seconds } of limits) {
      const entry = db
        .prepare("SELECT attempts, resets_at FROM rate_limits WHERE bucket = ?")
        .get(bucket);
      if (entry && Number(entry.attempts) >= max) {
        throw new ApiError(
          429,
          "Too many attempts. Please try again later.",
          Math.max(1, Math.ceil((Number(entry.resets_at) - now) / 1000)),
        );
      }
      db.prepare(
        `INSERT INTO rate_limits (bucket, attempts, resets_at) VALUES (?, 1, ?)
        ON CONFLICT(bucket) DO UPDATE SET attempts = attempts + 1`,
      ).run(bucket, now + seconds * 1000);
    }
  });
}

function authLimit(action: "register" | "login", email: string) {
  rateLimit([
    {
      bucket: `auth:${action}:global`,
      max: action === "register" ? 50 : 200,
      seconds: 3600,
    },
    {
      bucket: `auth:${action}:${digest(email)}`,
      max: action === "register" ? 5 : 10,
      seconds: 900,
    },
  ]);
}

function sessionToken(request: Request) {
  const cookies = request.headers.get("cookie")?.split(";") ?? [];
  const values = cookies
    .map((part) => part.trim())
    .filter((part) => part.startsWith(`${SESSION_COOKIE}=`))
    .map((part) => part.slice(SESSION_COOKIE.length + 1));
  // Reject ambiguous duplicate cookie names instead of selecting an arbitrary session.
  if (values.length !== 1) return null;
  const [value] = values;
  return value && /^[A-Za-z0-9_-]{43}$/.test(value) ? value : null;
}

export function accountId(request: Request, required = false) {
  const token = sessionToken(request);
  const row = token
    ? database()
        .prepare(
          `SELECT account_id FROM sessions
    WHERE token_hash = ? AND expires_at > ?`,
        )
        .get(digest(token), Date.now())
    : undefined;
  if (row) return String(row.account_id);
  if (required) throw new ApiError(401, "Sign in to manage your workspace.");
  return null;
}

export function cookie(request: Request, token: string, clear = false) {
  const secure =
    process.env.NODE_ENV === "production" || secureRequest(request);
  return `${SESSION_COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${clear ? 0 : sessionSeconds}${secure ? "; Secure" : ""}`;
}

function newSession(id: string, request: Request) {
  const db = database();
  const oldToken = sessionToken(request);
  if (oldToken)
    db.prepare("DELETE FROM sessions WHERE token_hash = ?").run(
      digest(oldToken),
    );
  const now = Date.now();
  db.prepare("DELETE FROM sessions WHERE expires_at <= ?").run(now);
  db.prepare(
    `DELETE FROM sessions WHERE account_id = ? AND token_hash NOT IN
    (SELECT token_hash FROM sessions WHERE account_id = ? ORDER BY created_at DESC LIMIT 19)`,
  ).run(id, id);
  const token = randomBytes(32).toString("base64url");
  db.prepare(
    "INSERT INTO sessions (token_hash, account_id, created_at, expires_at) VALUES (?, ?, ?, ?)",
  ).run(digest(token), id, now, now + sessionSeconds * 1000);
  return token;
}

export async function register(
  data: Record<string, unknown>,
  request: Request,
) {
  const name = text(data.name, "Name", 2, 64);
  const email = emailAddress(data.email);
  const password = passwordValue(data.password);
  authLimit("register", email);
  if (
    database().prepare("SELECT id FROM accounts WHERE email = ?").get(email)
  ) {
    throw new ApiError(
      409,
      "An account with this email already exists. Sign in instead.",
    );
  }
  const hash = await passwordHash(password);
  return transaction((db) => {
    const id = randomUUID();
    const inserted = db
      .prepare(
        `INSERT INTO accounts (id, email, password_hash, name, created_at)
      VALUES (?, ?, ?, ?, ?) ON CONFLICT(email) DO NOTHING`,
      )
      .run(id, email, hash, name, new Date().toISOString());
    if (!inserted.changes)
      throw new ApiError(
        409,
        "An account with this email already exists. Sign in instead.",
      );
    return { id, token: newSession(id, request) };
  });
}

export async function login(data: Record<string, unknown>, request: Request) {
  const email = emailAddress(data.email);
  const password = passwordValue(data.password);
  authLimit("login", email);
  const row = database()
    .prepare("SELECT id, password_hash FROM accounts WHERE email = ?")
    .get(email);
  const valid = await verifyPassword(
    password,
    row ? String(row.password_hash) : unknownPasswordHash,
  );
  if (!row || !valid)
    throw new ApiError(401, "Email or password is incorrect.");
  const id = String(row.id);
  return transaction(() => ({ id, token: newSession(id, request) }));
}

export function logout(request: Request) {
  const token = sessionToken(request);
  if (token)
    database()
      .prepare("DELETE FROM sessions WHERE token_hash = ?")
      .run(digest(token));
}
