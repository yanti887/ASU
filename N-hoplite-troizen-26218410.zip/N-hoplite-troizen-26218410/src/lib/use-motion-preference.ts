"use client";

import { useEffect, useState } from "react";

const storageKey = "aivon-motion";
export function useMotionPreference() {
  const [manual, setManual] = useState(false);
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    const media = matchMedia("(prefers-reduced-motion: reduce)");
    const syncMedia = () => setReduced(media.matches);
    function syncStored() {
      try {
        setManual(localStorage.getItem(storageKey) === "paused");
      } catch {
        /* Keep the current-page preference without storage. */
      }
    }
    function storage(event: StorageEvent) {
      if (event.key === storageKey || event.key === null) syncStored();
    }
    syncMedia();
    syncStored();
    media.addEventListener("change", syncMedia);
    window.addEventListener("storage", storage);
    return () => {
      media.removeEventListener("change", syncMedia);
      window.removeEventListener("storage", storage);
    };
  }, []);
  const paused = manual || reduced;
  useEffect(() => {
    document.documentElement.dataset.motion = paused ? "paused" : "active";
    const visibility = () => {
      document.documentElement.dataset.tabVisible = String(!document.hidden);
    };
    visibility();
    document.addEventListener("visibilitychange", visibility);
    return () => {
      delete document.documentElement.dataset.motion;
      delete document.documentElement.dataset.tabVisible;
      document.removeEventListener("visibilitychange", visibility);
    };
  }, [paused]);
  function setPaused(value: boolean) {
    setManual(value);
    try {
      localStorage.setItem(storageKey, value ? "paused" : "active");
    } catch {
      /* Motion controls still work for this page. */
    }
  }
  return { paused, reduced, setPaused };
}
